/********************************************************************************
 * Copyright (c) 2025 Contributors to the Eclipse Foundation
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Apache License Version 2.0 which is available at
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * SPDX-License-Identifier: Apache-2.0
 ********************************************************************************/
#ifndef SCORE_MW_COM_IMPL_PLUMBING_I_SKELETON_FIELD_BINDING_FACTORY_H
#define SCORE_MW_COM_IMPL_PLUMBING_I_SKELETON_FIELD_BINDING_FACTORY_H

#include "score/mw/com/impl/field_tags_store.h"
#include "score/mw/com/impl/instance_identifier.h"
#include "score/mw/com/impl/skeleton_base.h"
#include "score/mw/com/impl/skeleton_event_binding.h"

#include <memory>
#include <string_view>

namespace score::mw::com::impl
{

/// \brief Interface for a factory class that dispatches calls to the appropriate binding based on
/// binding information in the deployment configuration.
class ISkeletonFieldBindingFactory
{
  public:
    ISkeletonFieldBindingFactory() noexcept = default;

    virtual ~ISkeletonFieldBindingFactory() noexcept = default;

    ISkeletonFieldBindingFactory(ISkeletonFieldBindingFactory&&) = delete;
    ISkeletonFieldBindingFactory& operator=(ISkeletonFieldBindingFactory&&) = delete;
    ISkeletonFieldBindingFactory(const ISkeletonFieldBindingFactory&) = delete;
    ISkeletonFieldBindingFactory& operator=(const ISkeletonFieldBindingFactory&) = delete;

    /// Creates instances of the event binding of a Skeleton field with a particular data type.
    /// \tparam SampleType Type of the data that is exchanged
    /// \param identifier The instance identifier containing the binding information.
    /// \param parent_binding A reference to the Skeleton which owns this event.
    /// \param field_name The binding unspecific name of the field inside the skeleton denoted by instance identifier.
    /// \param sample_type_size_info The size and alignment information of the SampleType.
    /// \param field_tags_store The field tags store containing the field abilities (notifier, setter, getter).
    /// \return An instance of SkeletonEventBinding or nullptr in case of an error.
    virtual auto CreateEventBinding(const InstanceIdentifier& identifier,
                                    SkeletonBinding& parent_binding,
                                    const std::string_view field_name,
                                    memory::DataTypeSizeInfo sample_type_size_info,
                                    const FieldTagsStore field_tags_store) -> std::unique_ptr<SkeletonEventBinding> = 0;
};

}  // namespace score::mw::com::impl

#endif  // SCORE_MW_COM_IMPL_PLUMBING_I_SKELETON_FIELD_BINDING_FACTORY_H
