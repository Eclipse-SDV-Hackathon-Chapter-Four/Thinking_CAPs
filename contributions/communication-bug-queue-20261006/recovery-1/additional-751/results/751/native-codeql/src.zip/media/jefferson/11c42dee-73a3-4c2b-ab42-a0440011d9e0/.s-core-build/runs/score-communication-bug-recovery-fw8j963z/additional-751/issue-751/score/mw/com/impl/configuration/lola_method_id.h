/********************************************************************************
 * Copyright (c) 2025 Contributors to the Eclipse Foundation
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Apache License Version 2.0 which is available at
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * SPDX-License-Identifier: Apache-2.0
 ********************************************************************************/
#ifndef SCORE_MW_COM_IMPL_CONFIGURATION_LOLA_METHOD_ID_H
#define SCORE_MW_COM_IMPL_CONFIGURATION_LOLA_METHOD_ID_H

#include "score/mw/com/impl/configuration/lola_service_element_id.h"

namespace score::mw::com::impl
{

using LolaMethodId = LolaServiceElementId;

}  // namespace score::mw::com::impl

#endif  // SCORE_MW_COM_IMPL_CONFIGURATION_LOLA_METHOD_ID_H
