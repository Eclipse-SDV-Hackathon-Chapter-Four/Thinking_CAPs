/********************************************************************************
 * Copyright (c) 2025 Contributors to the Eclipse Foundation
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Apache License Version 2.0 which is available at
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * SPDX-License-Identifier: Apache-2.0
 ********************************************************************************/
#ifndef SCORE_MW_COM_IMPL_BINDINGS_LOLA_PROVIDER_EVENT_DATA_CONTROL_LOCAL_VIEW_H
#define SCORE_MW_COM_IMPL_BINDINGS_LOLA_PROVIDER_EVENT_DATA_CONTROL_LOCAL_VIEW_H

#include "score/mw/com/impl/bindings/lola/control_slot_types.h"
#include "score/mw/com/impl/bindings/lola/event_data_control.h"
#include "score/mw/com/impl/bindings/lola/event_slot_status.h"

#include "score/concurrency/atomic_indirector.h"

#include <score/span.hpp>

#include <atomic>

namespace score::mw::com::impl::lola
{

// Suppress The rule AUTOSAR C++14 M3-2-3: "A type, object or function that is used in multiple translation units shall
// be declared in one and only one file."
// This is a forward declaration that does not vioalate this rule.
// coverity[autosar_cpp14_m3_2_3_violation]
template <template <class> class T>
class EventDataControlComposite;

/// \brief View class which provides functionality for interacting with EventDataControl.
///
/// \details EventDataControl contains control information for an event which is stored in shared memory. Accessing the
/// control information directly in shared memory during runtime requires using (dereferencing, copying etc.) OffsetPtrs
/// which can negatively affect performance. Therefore, the data in EventDataControl is created / opened once during
/// Skeleton / Proxy creation, and then is accessed during runtime via EventDataControlLocal.
template <template <class> class AtomicIndirectorType = concurrency::AtomicIndirectorReal>
class ProviderEventDataControlLocalView final
{
    template <template <typename> class T>
    // Suppress "AUTOSAR C++14 A11-3-1", The rule declares: "Friend declarations shall not be used".
    // In order that users do not depend on implementation details, we only expose on user facing classes the bare
    // necessary. Thus, we have friend classes that expose internals for our implementation. Design decision for better
    // encapsulation.
    // coverity[autosar_cpp14_a11_3_1_violation]
    friend class EventDataControlComposite;

  public:
    struct SlotInfo
    {
        SlotIndexType slot_index;
        EventSlotStatus::value_type slot_value;
    };

    using LocalEventControlSlots = score::cpp::span<ControlSlotType>;

    ProviderEventDataControlLocalView(EventDataControl& event_data_control);

    ~ProviderEventDataControlLocalView() noexcept = default;

    ProviderEventDataControlLocalView(const ProviderEventDataControlLocalView&) = delete;
    ProviderEventDataControlLocalView& operator=(const ProviderEventDataControlLocalView&) = delete;
    ProviderEventDataControlLocalView(ProviderEventDataControlLocalView&&) noexcept = delete;
    ProviderEventDataControlLocalView& operator=(ProviderEventDataControlLocalView&& other) noexcept = delete;

    /// \brief Checks for the oldest unused slot and acquires for writing (thread-safe, wait-free)
    ///
    /// \details This method will perform retries (bounded) on data-races. In order to ensure that _always_
    /// a slot is found, it needs to be ensured that:
    /// * enough slots are allocated (sum of all possible max allocations by consumer + 1)
    /// * enough retries are performed (currently max number of parallel actions is restricted to 50 (number of
    /// possible transactions (2) * number of parallel actions = number of retries))
    ///
    /// \return reserved slot for writing if found, empty otherwise
    /// \post EventReady() is invoked to withdraw write-ownership
    std::optional<SlotIndexType> AllocateNextSlot() noexcept;

    /// \brief Indicates that a slot is ready for reading - writing has finished. (thread-safe, wait-free)
    /// \pre AllocateNextSlot() was invoked to obtain write-ownership
    void EventReady(const SlotIndexType slot_index, const EventSlotStatus::EventTimeStamp time_stamp) noexcept;

    /// \brief Marks selected slot as invalid, if it was not yet marked as ready
    ///
    /// \details We don't discard elements that are already ready, since it is possible that a user might already
    /// read them. This just might be the case if a SampleAllocateePtr is destroyed after invoking Send().
    ///
    /// \pre AllocateNextSlot() was invoked to obtain write-ownership
    void Discard(const SlotIndexType slot_index);

    std::optional<EventSlotStatus::value_type> TryAllocateSlot(const SlotInfo slot_info) noexcept;

    /// \brief Directly access EventSlotStatus for one specific slot
    EventSlotStatus operator[](const SlotIndexType slot_index) const noexcept;

    /// \brief Marks all Slots which are `InWriting` as `Invalid`.
    /// \details This function shall _only_ be called on skeleton side and _only_ if a previous skeleton instance died.
    void RemoveAllocationsForWriting() noexcept;

    // helper for performance indication (no production usage)
    static void DumpPerformanceCounters();
    static void ResetPerformanceCounters();

  private:
    /// \brief Finds oldest unused slot within control slots, if there is any.
    /// \return if an unused slot is found, returns its index, otherwise, an empty optional is returned.
    std::optional<ProviderEventDataControlLocalView::SlotInfo> FindOldestUnusedSlot() const noexcept;

    /// \brief Logs performance metrics for slot allocation attempts.
    void LogPerformanceMetrics(std::uint64_t retry_counter) noexcept;

    /// \brief Sets the slot value for the given slot index.
    ///
    /// This is a helper function which is used by EventDataControlComposite to reset the value of a slot in case of a
    /// failed multi-slot allocation.
    void SetSlotValue(const SlotInfo slot_info) noexcept;

    LocalEventControlSlots state_slots_;

    // helper variables to calculated performance indicators
    static inline std::atomic_uint_fast64_t num_alloc_misses{0U};
    static inline std::atomic_uint_fast64_t num_alloc_retries{0U};
};

}  // namespace score::mw::com::impl::lola

#endif  // SCORE_MW_COM_IMPL_BINDINGS_LOLA_PROVIDER_EVENT_DATA_CONTROL_LOCAL_VIEW_H
