load("//download/file:repository.bzl", _FILE = "ATTRS", _rule = "file")
load(":repository.bzl", _ATTRS = "ATTRS", _implementation = "implementation")

visibility("//...")

DOC = """Download single files using templated attributes.

Use this tag with the `download_template` module extension to expand attribute templates (for example, versions and triplets) and materialize one or more external repositories from single-file downloads. Each expansion produces a repository that you can reference via `use_repo`.

# Concepts

- Attribute templating: fields like `name`, `output`, and `urls` can contain `{variables}`.
- Triplets: each `triplet` (for example, `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}`.
- Substitutions: provide your own key/value mappings; values may reference other substitutions.
- Built-ins: `download_utils` provides helpful variables such as `{executable.extension}`.

# Examples

## File download expanded by version and triplet

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

download.file(
    name = "shfmt-{version}-{triplet}",
    lock = "//shfmt:lock.json",
    output = "shfmt{executable.extension}",
    substitutions = {
        "version": ["3.11.0"],
        "triplets": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
        ],
    },
    executable = True,
    links = {"shfmt{executable.extension}": "entrypoint"},
    urls = [
        "https://github.com/mvdan/sh/releases/download/v{version}/shfmt_v{version}_{os}_{cpu}",
    ],
)

use_repo(
    download,
    "shfmt-3.11.0-amd64-linux-gnu",
    "shfmt-3.11.0-arm64-linux-gnu",
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock shfmt/lock.json
```

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload shfmt/lock.json
```

# Notes
- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules.
- This tag downloads a single file (not an archive), which is useful for standalone binaries.
"""

ATTRS = _FILE | _ATTRS
ATTRS.pop("integrity")

def implementation(ctx, attrs, data):
    return _implementation(ctx, _rule, attrs, data)

download_template_file = tag_class(
    doc = DOC,
    attrs = ATTRS,
)

file = download_template_file
