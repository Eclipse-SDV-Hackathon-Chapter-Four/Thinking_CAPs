load("@bazel_tools//tools/build_defs/repo:utils.bzl", "read_user_netrc", "use_netrc")
load(":id.bzl", "id")
load(":workspace.bzl", "workspace")

visibility("//download/...")

ATTRS = {
    "urls": attr.string_list(
        doc = """URLs from which to download the artifact.

Provide multiple URLs to enable mirror fallback (they are tried in order until one succeeds). The special token `%workspace%` is expanded to the current workspace root path prior to download.
""",
        allow_empty = False,
        mandatory = True,
    ),
    "integrity": attr.string(
        doc = """Subresource Integrity (SRI) of the downloaded artifact.

If omitted, the calculated integrity is printed to the terminal after download. For reproducible, secure builds, provide an integrity value. Non-HTTPS URLs must specify integrity.
""",
        mandatory = False,
    ),
    "strip_prefix": attr.string(
        doc = "Path prefix to strip from extracted files.",
    ),
    "srcs": attr.string_list(
        doc = """Glob patterns selecting files in the unpacked repository.

Forwarded to the BUILD template as the `{{srcs}}` substitution. The default template exposes `{{srcs}}` via a `:srcs` filegroup target.
""",
        default = ["**"],
    ),
}

def download_and_extract(rctx, *, extension, nested = ()):
    """
    A mixin for `download` repository rules.

    Args:
        rctx: The download repository context.
        nested: A mutually exclusive set of nested archives to unpack
        extension: The extension of the download

    Returns:
        A map of canonical arguments
    """
    netrc = read_user_netrc(rctx)
    auth = use_netrc(netrc, rctx.attr.urls, {})

    extension = extension or rctx.attr.extension

    temp = rctx.path(".extracted")

    root = workspace(rctx)
    urls = [u.replace("%workspace%", root) for u in rctx.attr.urls]
    chksum = rctx.download_and_extract(
        url = [u.replace("%workspace%", root) for u in rctx.attr.urls],
        integrity = rctx.attr.integrity,
        stripPrefix = rctx.attr.strip_prefix if not nested else "",
        auth = auth,
        output = "" if not nested else temp,
        type = extension[0:],
        canonical_id = id(rctx, urls),
    )

    if not nested:
        return {"integrity": chksum.integrity}

    for child in nested:
        archive = temp.get_child(child)

        if not archive.exists:
            continue

        rctx.extract(
            archive = archive,
            stripPrefix = rctx.attr.strip_prefix,
        )

        rctx.delete(temp)

        return {"integrity": chksum.integrity}

    fail("Cannot find any `{}` archive(s) in `{}`: {}".format(", ".join(nested), temp, ", ".join(temp.readdir())))
