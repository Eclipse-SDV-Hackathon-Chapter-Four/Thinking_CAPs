from __future__ import annotations

from concurrent.futures import Executor, ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from mmap import PAGESIZE
from multiprocessing import cpu_count
from typing import Iterable, Iterator, Protocol

from download.template.lock.download import Stream as Downloader
from download.template.lock.integrity import ALGORITHM, SRI, Checksum
from download.template.lock.url import URL


class Upload(Protocol):
    @property
    def download(self) -> URL: ...

    @property
    def upload(self) -> URL: ...

    @property
    def checksum(self) -> Checksum | None: ...


@dataclass(frozen=True)
class Uploaded:
    download: URL
    upload: URL
    sri: SRI

    @property
    def url(self) -> URL:
        return self.upload


class UploadValueError(ValueError):
    pass


def upload(download: URL, checksum: Checksum, upload: URL) -> Uploaded:
    if download == upload:
        raise UploadValueError(f"cannot upload to the same download URL: {download}")

    with (
        Downloader(download, checksum or ALGORITHM) as src,
        upload.open(method="PUT", data=src) as dst,
    ):
        while _ := dst.read(PAGESIZE):
            pass

        return Uploaded(
            download=src.url,
            upload=upload,
            sri=src.sri(),
        )


def serial(uploads: Iterable[Upload], /) -> Iterator[Uploaded]:
    for u in uploads:
        yield upload(u)


def pooled(pool: Executor, uploads: Iterable[Upload], /) -> Iterator[Uploaded]:
    for future in as_completed(
        pool.submit(upload, u.download, u.checksum, u.upload) for u in uploads
    ):
        yield future.result()


def threaded(
    uploads: Iterable[Upload],
    /,
    threads: int = cpu_count(),
) -> Iterator[Uploaded]:
    with ThreadPoolExecutor(max_workers=threads) as pool:
        yield from pooled(pool, uploads)
