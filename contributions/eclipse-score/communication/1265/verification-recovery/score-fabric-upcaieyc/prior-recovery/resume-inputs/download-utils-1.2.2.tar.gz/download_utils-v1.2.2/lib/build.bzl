visibility("//download/...")

ATTRS = {
    "build": attr.label(
        doc = """Template used to generate the repository `BUILD.bazel` file.

Receives a `{{srcs}}` substitution containing the list of files (from `srcs` or `output`, plus any link targets) that the template can expose as targets.
""",
        default = ":BUILD.tmpl.bazel",
    ),
}

def build(rctx):
    """
    A mixin for `download` repository rules that patches files after download.

    Args:
        rctx: The download repository context.

    Returns:
        A map of canonical arguments
    """
    substitutions = {}

    if hasattr(rctx.attr, "srcs"):
        srcs = [s for s in rctx.attr.srcs]
    elif hasattr(rctx.attr, "output"):
        srcs = [rctx.attr.output]
    else:
        fail("No supported attributes")

    if hasattr(rctx.attr, "links"):
        srcs += rctx.attr.links.values()

    substitutions["{{srcs}}"] = repr(srcs)

    rctx.template("BUILD.bazel", rctx.attr.build, substitutions, executable = False)

    return {}
