load("//lib:build.bzl", "build", _BUILD = "ATTRS")
load("//lib:commands.bzl", "commands", _COMMANDS = "ATTRS")
load("//lib:download_and_extract.bzl", "download_and_extract", _DOWNLOAD_AND_EXTRACT = "ATTRS")
load("//lib:links.bzl", "links", _LINKS = "ATTRS")
load("//lib:metadata.bzl", "metadata", _METADATA = "ATTRS")
load("//lib:patch.bzl", "patch", _PATCH = "ATTRS")

visibility("//download/...")

DOC = """Download and unpack the data payload from a Debian (`.deb`) package into an external repository.

This `repository_rule` fetches a `.deb`, locates its embedded data archive (e.g., `data.tar.xz` or `data.tar.zst`), and extracts it. This rule is intended for accessing the packaged files (`usr/bin`, `usr/lib`, etc). It does not expose control metadata (`control.tar.*`). If you need to inspect control metadata, download and extract the `.deb` using `download_archive` instead.

# Examples

Minimal usage:

```py
download_deb = use_repo_rule("@download_utils//download/deb:defs.bzl", "download_deb")
download_deb(
    name = "busybox",
    urls = ["https://snapshot-cloudflare.debian.org/archive/debian/20240210T223313Z/pool/main/b/busybox/busybox-static_1.36.1-6_amd64.deb"],
    integrity = "sha256-vMiq8kFBwoSrVEE+Tcs08RvaiNp6MsboWlXS7p1clO0=",
)
```

Extract a subtree and expose only selected files via the `BUILD` template:

```py
download_deb(
    name = "busybox",
    urls = ["https://.../busybox-static_1.36.1-6_amd64.deb"],
    integrity = "sha256-vMiq8kFBwoSrVEE+Tcs08RvaiNp6MsboWlXS7p1clO0=",
    strip_prefix = "usr/bin",
    srcs = ["busybox"],  # forwarded to the BUILD template as {{srcs}}
)
```

Create links and run hermetic post-extract commands:

```py
download_deb(
    name = "busybox",
    urls = ["https://.../busybox-static_1.36.1-6_amd64.deb"],
    integrity = "sha256-vMiq8kFBwoSrVEE+Tcs08RvaiNp6MsboWlXS7p1clO0=",
    links = {
        "busybox": "entrypoint",
    },
    commands = {
        "Make entrypoint executable": [
            "$(location @coreutils//:entrypoint)", "chmod", "u+x", "entrypoint",
        ],
    },
    tools = ["@coreutils//:entrypoint"],
)
```

# Notes

- This rule extracts only the data archive from the `.deb` (`data.tar.*`). Control metadata is not unpacked.
- Always provide an `integrity` for secure and reproducible builds.
- Prefer hermetic `tools` referenced via `$(location ...)` in commands.
"""

ATTRS = _COMMANDS | _DOWNLOAD_AND_EXTRACT | _PATCH | _BUILD | _LINKS | _METADATA

def implementation(rctx):
    canonical = {a: getattr(rctx.attr, a) for a in ATTRS} | {"name": rctx.name}

    canonical |= download_and_extract(rctx, nested = ("data.tar.xz", "data.tar.zst"), extension = ".deb")
    canonical |= build(rctx)
    canonical |= patch(rctx)
    canonical |= links(rctx)
    canonical |= commands(rctx)

    return metadata(rctx, canonical)

deb = repository_rule(
    doc = DOC,
    implementation = implementation,
    attrs = ATTRS,
)
