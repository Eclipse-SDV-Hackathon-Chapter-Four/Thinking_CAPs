#! /usr/bin/env python3

from __future__ import annotations

from download.template.lock.cli import entry

if __name__ == "__main__":
    entry()
