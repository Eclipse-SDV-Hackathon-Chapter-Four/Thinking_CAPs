load("@bazel_skylib//lib:structs.bzl", "structs")
load("@bazel_skylib//lib:types.bzl", "types")

visibility("//...")

def _string(value, data):
    string = value
    output = ""
    for _ in range(32):
        prefix, found, string = string.partition("{")
        output += prefix
        if not found:
            return output

        variable, found, string = string.partition("}")
        if not found:
            fail("failed to find closing bracket: " + value)

        if variable not in data:
            fail("no substitution available for `%s` in %s: %s" % (variable, value, data))

        output += data[variable]

    fail("too many replacements: " + value)

def _bool(value, data):
    return value

def _int(value, data):
    return value

def _label(value, data):
    return value

def _recurse2(value, data):
    if type(value) == "Label":
        return _label(value, data)
    if types.is_string(value):
        return _string(value, data)
    fail("unknown render type: " + type(value))

def _recurse1(value, data):
    if type(value) == "Label":
        return _label(value, data)
    if types.is_bool(value):
        return _bool(value, data)
    if types.is_int(value):
        return _int(value, data)
    if types.is_string(value):
        return _string(value, data)
    if types.is_list(value):
        return [_recurse2(v, data) for v in value]
    if types.is_dict(value):
        return {_recurse2(k, data): _recurse2(v, data) for k, v in value.items()}
    fail("unknown render type: " + type(value))

def render(value, data):
    if not types.is_dict(data):
        data = structs.to_dict(data)
    if types.is_string(value):
        return _string(value, data)
    if types.is_dict(value):
        return struct(**{k: _recurse1(v, data) for k, v in value.items()})
    fail("unknown render type: " + type(value))
