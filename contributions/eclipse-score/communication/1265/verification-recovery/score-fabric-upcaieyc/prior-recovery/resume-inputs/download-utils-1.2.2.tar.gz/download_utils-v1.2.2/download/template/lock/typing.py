from __future__ import annotations

from typing import Protocol


class SupportsWrite(Protocol):
    def write(self, data: bytes, /) -> int: ...


class SupportsRead(Protocol):
    def read(self, size: int = -1, /) -> bytes: ...


class SupportsClose(Protocol):
    def close(self) -> None: ...


class SupportsReadClose(SupportsRead, SupportsClose):
    pass
