load("@bazel_skylib//lib:structs.bzl", "structs")
load("@bazel_skylib//lib:types.bzl", "types")

visibility("//...")

DOC = """Provide a single templated substitution for `download_template` rules.

Define a `key` whose `value` is selected by evaluating a templated `match` string against a `select` map. The `match` string can reference other substitutions using `{variable}` and values in `select` may also contain `{variable}` placeholders.

# Example

```py
download = use_extension("//download/template:defs.bzl", "download_template")

# Derive a vendor name from the current OS
download.substitution(
    key = "rust.vendor",
    match = "{os}",
    select = {
        "macos": "apple",
        "windows": "pc",
        "//conditions:default": "unknown",
    },
)

# Use the substitution in a templated download
download.archive(
    name = "pkg-{version}-{triplet}",
    urls = ["https://example.com/pkg-{version}-{rust.vendor}-{cpu}.tar.xz"],
    lock = "//pkg:lock.json",
    substitutions = {
        "version": ["1.2.3"],
        "triplet": ["amd64-linux-gnu", "arm64-linux-gnu"],
    },
)
```

Consider `substitutions` to load multiple substitutions from JSON files.
"""

ATTRS = {
    "key": attr.string(
        doc = "The replacement key for the template value.",
        mandatory = True,
    ),
    "match": attr.string(
        doc = "A templated string to match in `select`",
        default = "//conditions:default",
    ),
    "select": attr.string_dict(
        doc = "A dictionary that matches `match` to provide a value. Can use replacements in values.",
        allow_empty = False,
        mandatory = True,
    ),
}

download_template_substitution = tag_class(
    doc = DOC,
    attrs = ATTRS,
)

substitution = download_template_substitution

def _split(value, func):
    key, found, rest = value.partition(".split(")
    if not found:
        return key, func

    quote, rest = rest[0], rest[1:]
    if quote not in ("'", '"'):
        fail("substitution `.split` takes a string first argument: " + value)

    sep, found, rest = rest.partition(quote)
    if not found:
        fail("failed to find closing `.split` first argument quote: " + value)

    _, found, rest = rest.partition(")")
    if not found:
        fail("failed to find closing `.split` parenthesis: " + value)

    _, found, rest = rest.partition("[")
    if not found:
        fail("failed to find opening `.split` bracket: " + value)

    index, found, rest = rest.partition("]")
    if not index.isdigit():
        fail("substitution `.split` must use a numeric index: " + value)
    if not found:
        fail("failed to find closing `.split` bracket: " + value)

    return key, lambda x: x.split(sep)[int(index)]

def _replace(value, substitutions, no_key_error = "No substitution for {key}: {value}"):
    string = value
    output = ""
    for _ in range(16):
        prefix, found, string = string.partition("{")
        output += prefix
        if not found:
            return output

        key, found, string = string.partition("}")
        if not found:
            fail("failed to find closing `}`: " + value)

        func = lambda x: x
        key, func = _split(key, func)

        if key not in substitutions:
            if no_key_error:
                fail(no_key_error.format(key = key, value = value))
            return None

        output += func(substitutions[key])

    fail("too many replacements: " + value)

def _select(key, select, no_match_error = "No match found for `{key}`: {select}"):
    value = getattr(select, key, None)
    if value != None:
        return value

    value = getattr(select, "//conditions:default", None)
    if value != None:
        return value

    if no_match_error == None:
        return None

    fail(no_match_error.format(key = key, select = select))

def resolve(substitution, substitutions = struct(), *, no_match_error = "No match found for `{key}`: {select}", no_key_error = "No substitution for {key}: {value}"):
    if not types.is_dict(substitutions):
        substitutions = structs.to_dict(substitutions)

    match = _replace(substitution.match, substitutions, no_key_error)
    if match == None:
        return None

    value = _select(match, substitution.select, no_match_error)
    if value == None:
        return None

    replaced = _replace(value, substitutions, no_key_error)
    if replaced == None:
        return None

    return struct(key = substitution.key, value = replaced)
