load(":separator.bzl", "SEPARATOR")

visibility("//download/...")

ATTRS = {
    "commands": attr.string_list_dict(
        doc = """Run hermetic post-download commands on the extracted resources.

Provide a dictionary mapping of a progress message to a command list. Commands execute with `PATH` cleared, so reference tools explicitly via `$(location ...)` and list them in `tools`.

# Examples

## Make a script executable

```py
download_archive(
    commands = {
        "Make script executable": [
            "$(location @coreutils//:entrypoint)", "chmod", "u+x", "some-script.sh",
        ],
    },
    tools = ["@coreutils//:entrypoint"],
)
```

## Edit files with a hermetic tool

```py
download_archive(
    commands = {
        "Normalize shebang": [
            "$(location @sed//:entrypoint)", "-i", "1s|/usr/bin/env bash|/bin/bash|", "scripts/setup.sh",
        ],
    },
    tools = ["@sed//:entrypoint"],
)
```

# Guidance
- Keep commands deterministic; avoid network access and non-reproducible inputs.
- Use hermetic tools referenced via `$(location ...)` and list them in `tools`.
- Use `timeout` to bound execution time for long-running steps.
""",
    ),
    "tools": attr.label_list(
        doc = """Hermetic executable labels used by `commands`.

Provide labels to executable targets that `commands` will invoke. Each tool must be referenced in the arguments via `$(location <label>)`.

# Notes
- List every tool you reference via `$(location ...)` in `commands`.
- Prefer hermetically downloaded tools over host system tools.
- Multi-call or wrapper binaries (e.g. `@coreutils//:entrypoint`) are supported and recommended for portability.
""",
        cfg = "exec",
    ),
    "timeout": attr.int(
        doc = "Seconds before a command execution is killed.",
        default = 600,
    ),
}

def commands(rctx):
    """
    A mixin for `download` repository rules to run the post-download commands.

    Args:
        rctx: The download repository context.

    Returns:
        A map of canonical arguments
    """
    if not rctx.attr.commands:
        return {}

    def _workspace(label):
        name, _ = rctx.name.rsplit(SEPARATOR, 1)
        workspace = label.workspace_name
        if not workspace:
            return workspace

        # Bazel 8- (e.g. end-to-end `@coreutils` results in `_main~_repo_rules~coreutils`)
        prefix = name + SEPARATOR
        if workspace.startswith(prefix):
            return workspace.removeprefix(prefix)

        # Bazel 8 (e.g. end-to-end `@coreutils` results in `+_repo_rules4+coreutils`)
        prefix, _ = workspace.rsplit(SEPARATOR, 1)
        prefix += SEPARATOR
        if prefix.startswith(SEPARATOR) and prefix.removeprefix(name).removesuffix(SEPARATOR).isdigit():
            return workspace.removeprefix(prefix)

        # Bazel 9+ (e.g. end-to-end `@coreutils` results in `+toolchain_local_select+coreutils`)
        prefix, _ = workspace.rsplit(SEPARATOR, 1)
        prefix += SEPARATOR
        if prefix.startswith(SEPARATOR) and workspace.startswith(prefix):
            return workspace.removeprefix(prefix)

        fail("Failed to calculate `commands` label workspace for {} within {}".format(label, rctx.name))

    def _label(label):
        workspace = _workspace(label)
        package = label.package
        name = label.name
        if not package and name == workspace:
            return "@{}".format(workspace)
        elif package == name:
            return "//{}".format(package)
        elif workspace:
            return "@{}//{}:{}".format(workspace, package, name)
        else:
            return "//{}:{}".format(package, name)

    tools = {_label(t): rctx.path(t) for t in rctx.attr.tools}

    def _location(arg):
        if not arg.startswith("$(location "):
            return arg

        arg = arg.removeprefix("$(location ")
        arg = arg.removesuffix(")")

        if arg not in tools:
            fail("No hermetic tool provided for {}. Add the tool to the download repository rule `tools. Available tools are: {}".format(arg, ",".join(tools.keys())))

        return tools[arg]

    # Run the commands
    for progress, command in rctx.attr.commands.items():
        rctx.report_progress(progress)

        command = [_location(arg) for arg in command]

        result = rctx.execute(command, timeout = rctx.attr.timeout, environment = {"PATH": ""})
        if result.return_code != 0:
            fail("Failed to {}: {}\n{}".format(progress, " ".join([str(c) for c in command]), result.stderr))

    return {}
