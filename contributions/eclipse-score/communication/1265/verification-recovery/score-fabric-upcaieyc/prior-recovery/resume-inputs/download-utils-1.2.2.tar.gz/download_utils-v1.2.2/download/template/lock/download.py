from __future__ import annotations

from collections.abc import Collection
from concurrent.futures import Executor, ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from mmap import PAGESIZE
from multiprocessing import cpu_count
from os import environ
from types import TracebackType
from typing import Iterable, Iterator, Protocol, TypeAlias, runtime_checkable
from urllib.error import HTTPError

from download.template.lock.integrity import (
    ALGORITHM,
    SRI,
    Algorithm,
    Checksum,
    SRIValueError,
)
from download.template.lock.integrity import Stream as Hash
from download.template.lock.integrity import SupportsChecksum, SupportsSRI
from download.template.lock.typing import SupportsClose, SupportsRead
from download.template.lock.url import URL, SupportsURL


class SupportsReadURLChecksumSRI(
    SupportsRead, SupportsURL, SupportsChecksum, SupportsSRI
):
    pass


@runtime_checkable
class File(Protocol):
    @property
    def url(self) -> URL: ...

    @property
    def sri(self) -> SRI | None: ...


class Proxy:
    def __init__(
        self,
        read: SupportsRead,
        url: SupportsURL,
        checksum: SupportsChecksum,
        sri: SupportsSRI,
        /,
    ):
        self.__read = read
        self.__url = url
        self.__checksum = checksum
        self.__sri = sri

    def read(self, size: int = -1, /) -> bytes:
        return self.__read.read(size)

    @property
    def url(self) -> URL:
        return self.__url.url

    @property
    def checksum(self) -> Checksum:
        return self.__checksum.checksum

    def sri(self) -> SRI:
        return self.__sri.sri()


Download: TypeAlias = str | URL | File


class Stream:
    def __init__(self, download: Download, /, checksum: Checksum = ALGORITHM):
        if isinstance(download, str):
            download = URL(download)

        if isinstance(download, URL):
            self.__checksum = checksum
            self.__url = download
        elif isinstance(download, File):
            self.__checksum = download.sri or checksum
            self.__url = download.url
        else:
            assert False, "unreachable"

        self.__stream: SupportsClose | None = None

    @property
    def url(self) -> URL:
        return self.__url

    @property
    def checksum(self) -> Checksum:
        return self.__checksum

    @property
    def algorithm(self) -> Algorithm:
        if isinstance(self.checksum, SRI):
            return self.checksum.algorithm
        return self.checksum

    @staticmethod
    def __workspace(url: URL) -> URL:
        if url.scheme == "file":
            workspace = environ["BUILD_WORKSPACE_DIRECTORY"]
            return URL(f"{url}".replace("%workspace%", workspace))
        return url

    def __enter__(self) -> SupportsReadURLChecksumSRI:
        assert self.__stream is None, "stream is already open"
        self.__stream = Hash(self.__workspace(self.url).open(), self.algorithm)
        return Proxy(self.__stream, self, self, self.__stream)

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
        /,
    ) -> bool | None:
        assert self.__stream is not None, "stream not open"
        self.__stream.close()
        self.__stream = None


@dataclass(frozen=True)
class Downloaded:
    url: URL
    sri: SRI | None = None


def download(value: Download, /, allowlist: Collection[int] = ()) -> Downloaded:
    try:
        with Stream(value) as stream:
            while _ := stream.read(PAGESIZE):
                pass
            sri = stream.sri()
            if isinstance(stream.checksum, SRI) and stream.checksum != sri:
                raise SRIValueError(
                    f"expected `{stream.checksum}` for `{stream.url}` not `{sri}`"
                )
            return Downloaded(stream.url, sri)
    except HTTPError as e:
        if e.code in allowlist:
            return Downloaded(URL(e.url))
        raise


def serial(
    downloads: Iterable[Download], /, allowlist: Collection[int] = ()
) -> Iterator[Downloaded]:
    for d in downloads:
        yield download(d, allowlist=allowlist)


def pooled(
    pool: Executor, downloads: Iterable[Download], /, allowlist: Collection[int] = ()
) -> Iterator[Downloaded]:
    for future in as_completed(
        pool.submit(download, d, allowlist=allowlist) for d in downloads
    ):
        yield future.result()


def threaded(
    downloads: Iterable[Download],
    /,
    threads: int = cpu_count(),
    allowlist: Collection[int] = (),
) -> Iterator[Downloaded]:
    with ThreadPoolExecutor(max_workers=threads) as pool:
        yield from pooled(pool, downloads, allowlist=allowlist)
