load(":archive.bzl", "archive", _archive = "implementation")
load(":deb.bzl", "deb", _deb = "implementation")
load(":file.bzl", "file", _file = "implementation")
load(":substitution.bzl", "substitution")
load(":substitutions.bzl", "substitutions", _load = "read")

visibility("//...")

DOC = """Templated downloads module extension for archives, single files, and Debian packages.

# Overview

- Use this module extension via `use_extension` to declare templated downloads.
- Tags:
  - `archive`, `file`, `deb`: define artifacts to fetch.
  - `substitution`, `substitutions`: provide values for template variables.
- Attribute templating: fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: a `triplet` like `amd64-linux-gnu` is split into `{cpu}`, `{os}`, and `{libc}`.
- Built-ins: `download_utils` provides helpful variables such as `{rust.archive.basename}`.

# Example

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

# Provide substitutions from JSON files
download.substitutions(
    srcs = ["//download/template:rust.cpu.json"],
)

# Provide a direct substitution
download.substitution(
    key = "version",
    match = "//conditions:default",
    select = {"//conditions:default": "1.2.3"},
)

# Define an archive download expanded by triplet
download.archive(
    name = "pkg-{version}-{triplet}",
    lock = "//pkg:lock.json",
    strip_prefix = "pkg-{version}",
    substitutions = {
        "triplet": ["amd64-linux-gnu", "arm64-linux-gnu"],
    },
    urls = [
        "https://example.com/pkg-{version}-{rust.archive.basename}",
    ],
)

# Make the generated repositories available
use_repo(
    download,
    "pkg-1.2.3-amd64-linux-gnu",
    "pkg-1.2.3-arm64-linux-gnu",
)
```

# Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
  - Run: `bazel run @download_utils//download/template/lock <path/to/lock.json>`
- Optionally mirror binaries:
  - Run: `bazel run @download_utils//download/template/lock:upload <path/to/lock.json>`

# Notes

- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules with the `substitution` and `substitutions` tags.
- For post-processing commands in repository rules, prefer hermetic tools referenced via `$(location ...)`.
"""

TAGS = {
    "archive": archive,
    "file": file,
    "deb": deb,
    "substitution": substitution,
    "substitutions": substitutions,
}

def _substitutions(mctx):
    data = {}

    ctx = struct(read = mctx.read)

    for m in mctx.modules:
        substitutions = [s for t in m.tags.substitutions for s in _load(ctx, t.srcs)]

        for s in m.tags.substitution + substitutions:
            if s.key in data:
                fail("`{}` already defined in `{}`".format(s.key, data[s.key].module))

            data[s.key] = struct(key = s.key, match = s.match, select = struct(**s.select), module = m.name)

    return tuple(data.values())

def _write(ctx, path, content, *, executable = True):
    """
    Enables writing outside the repository bounds.

    `ctx.file` does not allow that, which we need.
    """
    path = ctx.path(path)
    exe = ctx.which("cmd.exe")
    if exe:
        cmd = (exe, "/C", "echo '{}' > {}".format(content, path))
        ctx.execute(cmd, timeout = 10)
        return None

    for exe in ("sh", "bash", "dash", "zsh", "fish"):
        exe = ctx.which("sh")
        if exe:
            cmd = (exe, "-c", "echo '{}' > {}".format(content, path))
            ctx.execute(cmd, timeout = 10)
            return None

    fail("failed to find a executable to write `{}`".format(path))

def implementation(mctx):
    # Collect templating substitution data
    substitutions = _substitutions(mctx)

    # Build a reduced context to pass to repository helpers
    ctx = struct(
        read = mctx.read,
        file = lambda *k, **kw: _write(mctx, *k, **kw),
        path = mctx.path,
    )

    # Create repositories
    direct = []
    reproducible = True
    for module in mctx.modules:
        for rule, tags in (
            (_archive, module.tags.archive),
            (_file, module.tags.file),
            (_deb, module.tags.deb),
        ):
            for attrs in tags:
                names, repro = rule(ctx, attrs, substitutions)
                if not repro:
                    reproducible = False
                if module.is_root:
                    direct += names

    # Done!
    if direct:
        return mctx.extension_metadata(
            root_module_direct_deps = direct,
            root_module_direct_dev_deps = [],
            reproducible = reproducible,
        )
    return mctx.extension_metadata(
        reproducible = reproducible,
    )

download_template = module_extension(
    doc = DOC,
    tag_classes = TAGS,
    implementation = implementation,
)

template = download_template
