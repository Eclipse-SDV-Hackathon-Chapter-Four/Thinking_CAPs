load(":workspace.bzl", "write")

visibility("//...")

ATTRS = {
    "metadata": attr.label_keyed_string_dict(
        doc = """Generate files from templates at specified repository paths.

Provide a label-keyed mapping of templates to output paths: `{"<template_label>": "<output_path>"}`.

- Templates are rendered once during repository creation.
- Substitutions available to templates:
  - `{{integrity}}`: the computed Subresource Integrity (SRI) of the downloaded artifact.

# Example

```py
download_archive(
    name = "pkg",
    urls = ["https://example.com/pkg-1.2.3.tar.xz"],
    integrity = "sha256-AbCdEfGhIjKlMnOpQrStUvWxYz0123456789+/==",
    metadata = {
        "//tools:NOTICE.tmpl": "NOTICE",
        "//tools:INTEGRITY.tmpl": "INTEGRITY.txt",
    },
)
```

# Notes

- Output files are created with `executable = False`.
- Output paths are relative to the repository root.""",
        mandatory = False,
    ),
}

def metadata(rctx, canonical):
    """
    Generate metadata files based on templates passed in.

    Args:
        rctx: The download repository context.
        canonical: The final canonical arguments

    Returns:
        A map of canonical arguments
    """

    if rctx.attr.metadata:
        substitutions = {"{{integrity}}": canonical["integrity"]}
        for template, output in rctx.attr.metadata.items():
            rctx.template(output, template, substitutions, executable = False)

    # TODO(v2): remove this as `WORKSPACE` is no longer needed
    canonical = write(rctx, canonical)

    if hasattr(rctx, "repo_metadata"):
        return rctx.repo_metadata(
            reproducible = not canonical,
            attrs_for_reproducibility = canonical,
        )

    return canonical
