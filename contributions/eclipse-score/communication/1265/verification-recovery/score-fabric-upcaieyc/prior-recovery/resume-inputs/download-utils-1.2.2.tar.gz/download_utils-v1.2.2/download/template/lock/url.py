from __future__ import annotations

from base64 import standard_b64encode as b64encode
from collections.abc import Mapping
from dataclasses import dataclass, field
from netrc import netrc
from pathlib import PurePath
from typing import Any, Literal, Protocol, TypeAlias
from urllib.parse import urlparse, urlunparse
from urllib.request import Request, urlopen

from download.template.lock.typing import SupportsRead, SupportsReadClose


@dataclass(frozen=True)
class Auth:
    headers: Mapping[str, str] = field(default_factory=dict)


Method: TypeAlias = Literal["GET", "PUT", None]

Data: TypeAlias = SupportsRead | None


class URL:
    def __init__(self, value: str | URL) -> None:
        if isinstance(value, URL):
            value = value.href
        self.__parsed = urlparse(value)

    def auth(self) -> Auth:
        nc = netrc()
        authenticator = nc.authenticators(self.hostname)
        if not authenticator:
            return Auth()
        username, _, password = authenticator
        if username == "OAuth":
            return Auth({"Authorization": f"Bearer {password}"})
        combined = f"{username}:{password}"
        base64 = b64encode(combined.encode("utf-8")).decode("ascii")
        return Auth({"Authorization": f"Basic {base64}"})

    def open(self, method: Method = None, data: Data = None) -> SupportsReadClose:
        request = Request(
            self.href, headers=self.auth().headers, method=method, data=data
        )
        return urlopen(request)

    @property
    def scheme(self) -> str:
        assert isinstance(self.__parsed.scheme, str)
        return self.__parsed.scheme

    @property
    def hostname(self) -> str:
        return self.__parsed.hostname or ""

    @property
    def href(self) -> str:
        return urlunparse(self.__parsed)

    @property
    def path(self) -> PurePath:
        return PurePath(self.__parsed.path or "/")

    def __str__(self) -> str:
        return self.href

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__module__}.{self.__class__.__name__}(href='{self.href}')"
        )

    def __hash__(self) -> int:
        return hash(self.__value)

    def __eq__(self, value: Any) -> bool:
        if not isinstance(value, URL):
            return False
        return self.href == value.href

    def format(self, **kw: str) -> URL:
        return URL(self.href.format(**kw))


class SupportsURL(Protocol):
    @property
    def url(self) -> URL: ...
