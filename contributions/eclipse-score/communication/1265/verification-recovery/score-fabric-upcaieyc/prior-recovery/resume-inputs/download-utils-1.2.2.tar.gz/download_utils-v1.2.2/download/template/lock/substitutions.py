from __future__ import annotations

from collections.abc import Mapping
from typing import Iterator


class Substitutions:
    def __init__(self, substitutions: Mapping[str, str]):
        nested = {}

        for key, value in substitutions.items():
            attr, dot, rest = key.partition(".")
            if not dot:
                setattr(self, attr, value)
                continue
            map = nested.setdefault(attr, {})
            map |= {rest: value}

        for attr, map in nested.items():
            setattr(self, attr, Substitutions(map))

    def items(self) -> Iterator[tuple[str, str | Substitutions]]:
        yield from self.__dict__.items()

    def keys(self) -> Iterator[str]:
        for k, _ in self.items():
            yield k

    def values(self) -> Iterator[str]:
        for _, v in self.items():
            yield v

    def __getitem__(self, value: str, /) -> str:
        return self.__dict__[value]

    def __iter__(self) -> Iterator[str]:
        yield from self.keys()

    def __repr__(self) -> str:
        return repr(self.flatten())

    def flatten(self) -> Mapping[str, str]:
        return {k: v for k, v in _recurse(self)}


def _recurse(substitutions: Substitutions) -> Iterator[str, str]:
    for key, value in vars(substitutions).items():
        if isinstance(value, Substitutions):
            for k, v in _recurse(value):
                yield f"{key}.{k}", v
            continue
        yield key, value
