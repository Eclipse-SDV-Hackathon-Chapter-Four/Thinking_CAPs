load("//lib:build.bzl", "build", _BUILD = "ATTRS")
load("//lib:commands.bzl", "commands", _COMMANDS = "ATTRS")
load("//lib:download.bzl", "download", _DOWNLOAD = "ATTRS")
load("//lib:links.bzl", "links", _LINKS = "ATTRS")
load("//lib:metadata.bzl", "metadata", _METADATA = "ATTRS")
load("//lib:patch.bzl", "patch", _PATCH = "ATTRS")

visibility("//download/...")

DOC = """Download a single file into an external repository.

This `repository_rule` downloads one file from one or more URLs, verifies integrity (when provided), and writes it to the given output path. It also supports marking the output as executable, templated `BUILD` generation, links, metadata, patching, and post-download commands.

# Examples

Minimal usage:

```py
download_file = use_repo_rule("@download_utils//download/file:defs.bzl", "download_file")
download_file(
    name = "shfmt-linux-amd64",
    output = "shfmt",
    urls = ["https://github.com/mvdan/sh/releases/download/v3.11.0/shfmt_v3.11.0_linux_amd64"],
)
```

Mark the output executable and expose via a link:

```py
download_file(
    name = "shfmt-linux-amd64",
    output = "shfmt",
    executable = True,
    links = {"shfmt{executable.extension}": "entrypoint"},
    urls = ["https://github.com/mvdan/sh/releases/download/v3.11.0/shfmt_v3.11.0_linux_amd64"],
)
```

Use `integrity` and hermetic post-download `commands`:

```py
download_file(
    name = "tool",
    output = "tool.bin",
    integrity = "sha256-AbCdEfGhIjKlMnOpQrStUvWxYz0123456789+/==",
    urls = ["https://example.com/tool-linux-amd64"],
    commands = {
        "Make binary read-only": [
            "$(location @coreutils//:entrypoint)", "chmod", "a-w", "tool.bin",
        ],
    },
    tools = ["@coreutils//:entrypoint"],
)
```

# Tips

- Always provide an `integrity` for secure and reproducible builds.
- Use `tools` and `$(location …)` in `commands` to ensure hermetic execution.
"""

ATTRS = _COMMANDS | _DOWNLOAD | _PATCH | _BUILD | _LINKS | _METADATA

def implementation(rctx):
    canonical = {a: getattr(rctx.attr, a) for a in ATTRS} | {"name": rctx.name}

    canonical |= download(rctx)
    canonical |= build(rctx)
    canonical |= patch(rctx)
    canonical |= links(rctx)
    canonical |= commands(rctx)

    return metadata(rctx, canonical)

file = repository_rule(
    doc = DOC,
    implementation = implementation,
    attrs = ATTRS,
)
