from __future__ import annotations

import json
from collections.abc import Collection, Iterable, Iterator, Mapping
from contextlib import contextmanager
from dataclasses import dataclass
from multiprocessing import cpu_count
from os import environ, linesep
from pathlib import Path
from shutil import copy, copystat
from tempfile import NamedTemporaryFile
from typing import Any

from download.template.lock.download import threaded as downloads
from download.template.lock.integrity import SRI
from download.template.lock.substitutions import Substitutions
from download.template.lock.typing import SupportsWrite
from download.template.lock.upload import threaded as uploads
from download.template.lock.url import URL


def resolve(value: str) -> Path:
    path = Path(value)

    if path.exists():
        return path

    if path.is_absolute():
        raise FileNotFoundError(f"file not found: {path}")

    try:
        bwd = environ["BUILD_WORKING_DIRECTORY"]
    except KeyError:
        raise FileNotFoundError(f"file not found: {path}")

    path = bwd / path

    if not path.exists():
        raise FileNotFoundError(f"file not found: {path}")

    return path


@dataclass(frozen=True)
class Download:
    url: URL
    sri: SRI | None


@dataclass(frozen=True)
class Mirror:
    download: URL
    upload: URL
    checksum: SRI | None


class File:
    def __init__(
        self,
        path: Path,
        uploads: Iterable[URL | str],
        urls: Iterable[URL | str],
        substitutions: (
            Mapping[Substitutions, SRI | None] | Mapping[str, Mapping[str, str]]
        ),
    ):
        self.__path = path
        self.__uploads = tuple(URL(u) for u in uploads)
        self.__urls = tuple(URL(u) for u in urls)

        def _coerce(k, v):  # type: ignore
            if isinstance(k, str):
                assert isinstance(v, Mapping), "invalid `substitutions` value"
                return Substitutions(v), None if k.startswith("#") else SRI(k)
            return k, v

        self.__substitutions = dict(_coerce(k, v) for k, v in substitutions.items())

    @property
    def path(self) -> Path:
        return self.__path

    @property
    def uploads(self) -> Collection[URL]:
        return self.__uploads

    @property
    def urls(self) -> Collection[URL]:
        return self.__urls

    @property
    def substitutions(self) -> Mapping[Substitutions, SRI | None]:
        return self.__substitutions

    def downloads(self) -> Iterator[Download]:
        for data, sri in self.substitutions.items():
            for url in self.urls:
                yield Download(url.format(**data), sri)

    def mirrors(self) -> Iterator[Mirror]:
        for data, sri in self.substitutions.items():
            for url in self.urls:
                for upload in self.uploads:
                    mirror = Mirror(url.format(**data), upload.format(**data), sri)
                    if mirror.upload != mirror.download:
                        yield mirror

    def items(self) -> Iterator[tuple[URL, Substitutions]]:
        for data in self.substitutions:
            for url in self.urls:
                yield url.format(**data), data

    def keys(self) -> Iterator[URL]:
        for k, _ in self.items():
            yield k

    def values(self) -> Iterator[Substitutions]:
        for _, v in self.items():
            yield v

    def __iter__(self) -> Iterator[URL]:
        yield from self.keys()

    def __getitem__(self, value: URL, /) -> Substitutions:
        for url, substitutions in self.items():
            if value == url:
                return substitutions
        raise KeyError(repr(value))

    def __contains__(self, value: Any) -> bool:
        if not isinstance(value, URL):
            return False
        for url in self:
            if url == value:
                return True
        return False


class JSONValueError:
    pass


def load(path: Path | str) -> File:
    if isinstance(path, str):
        path = resolve(path)

    with path.open() as stream:
        map = json.load(stream)

    if not isinstance(map, Mapping):
        raise JSONValueError(f"a lock file must contain a mapping: {path}")

    urls = map.pop("urls")
    if not isinstance(urls, Collection):
        raise JSONValueError(f"a lock file `urls` must be a list: {path}")
    for url in urls:
        if not isinstance(url, str):
            raise JSONValueError(
                f"a lock file `urls` must be a list of URL strings: {path}"
            )

    uploads = map.pop("uploads", ())
    if not isinstance(uploads, Collection):
        raise JSONValueError(f"a lock file `uploads` must be a list: {path}")
    for upload in uploads:
        if not isinstance(upload, str):
            raise JSONValueError(
                f"a lock file `uploads` must be a list of URL strings: {path}"
            )

    integrities = map.pop("integrities")
    if not isinstance(integrities, Mapping):
        raise JSONValueError(f"a lock file `integrities` must be a map: {path}")
    for integrity, data in integrities.items():
        if not isinstance(integrity, str):
            raise JSONValueError(
                f"a lock file `integrities` keys must be strings: {path}"
            )
        if not isinstance(data, Mapping):
            raise JSONValueError(
                f"a lock file `integrities` value must be a map: {path}"
            )
        for k, v in data.items():
            if not isinstance(k, str):
                raise JSONValueError(
                    f"a lock file `integrities` value must be string map: {path}"
                )
            if not isinstance(v, str):
                raise JSONValueError(
                    f"a lock file `integrities` value must be string map: {path}"
                )

    return File(
        path=path,
        uploads=uploads,
        urls=urls,
        substitutions=integrities,
    )


@contextmanager
def dump(path: Path) -> SupportsWrite:
    with NamedTemporaryFile(
        prefix="download_utils-download.template-lock-file-dump-",
        mode="w",
        encoding="utf8",
    ) as temp:
        yield temp
        temp.flush()
        copystat(path, temp.name)
        copy(temp.name, path)


def lock(file: File, jobs: int = cpu_count(), allowlist: Collection[int] = ()) -> None:
    data = {
        "uploads": tuple(f"{u}" for u in file.uploads),
        "urls": tuple(f"{u}" for u in file.urls),
        "integrities": {
            f"{d.sri}" if d.sri else f"#unlocked[{i:03}]": file[d.url].flatten()
            for i, d in enumerate(
                downloads(
                    (d for d in file.downloads()), threads=jobs, allowlist=allowlist
                )
            )
        },
    }

    with dump(file.path) as stream:
        json.dump(data, stream, sort_keys=True, indent="\t")
        stream.write(linesep)


def upload(file: File, jobs: int = cpu_count()) -> None:
    data = {
        "uploads": tuple(f"{u}" for u in file.uploads),
        "urls": tuple(f"{u}" for u in file.urls),
        "integrities": {
            f"{u.sri}": file[u.download].flatten() | file[u.upload].flatten()
            for u in uploads((m for m in file.mirrors()), threads=jobs)
        },
    }

    with dump(file.path) as stream:
        json.dump(data, stream, sort_keys=True, indent="\t")
        stream.write(linesep)
