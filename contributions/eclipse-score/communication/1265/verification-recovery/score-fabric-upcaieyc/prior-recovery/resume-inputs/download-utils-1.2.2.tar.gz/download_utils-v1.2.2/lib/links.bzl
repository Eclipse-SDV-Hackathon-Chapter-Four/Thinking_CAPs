visibility("//download/...")

ATTRS = {
    "links": attr.string_dict(
        doc = """Create links inside the downloaded repository as `{"<target>": "<link>"}`.

Use links to add entry points or adjust layout after extraction. For each pair, a link named `<link>` is created pointing to `<target>`.

# Example

```py
download_archive(
    name = "pkg",
    links = {
        "etc/test/fixture.txt": "fixture.txt",
        "bin/tool": "tools/tool",
    },
)
```

# Behavior
- Depending on the platform, Bazel may create symbolic or hard links.
- Targets should reference files or directories present after download/extract/patch steps.
""",
    ),
}

def links(rctx):
    """
    A mixin for `download` repository rules that creates links.

    Args:
        rctx: The download repository context.

    Returns:
        A map of canonical arguments
    """
    for target, link in rctx.attr.links.items():
        rctx.symlink(target, link)

    return {}
