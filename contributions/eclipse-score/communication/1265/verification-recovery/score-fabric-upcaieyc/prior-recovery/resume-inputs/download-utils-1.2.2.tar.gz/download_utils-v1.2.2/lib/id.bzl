load("@bazel_tools//tools/build_defs/repo:cache.bzl", "get_default_canonical_id")

visibility("//download/...")

def id(rctx, urls):
    """
    Retrives the default canonical ID for `download` or `download_and_extract`.

    Args:
        rctx: The download repository context.
        urls: The download URLS

    Returns:
        A canonical ID to use
    """
    if rctx.attr.integrity:
        return get_default_canonical_id(rctx, rctx.attr.urls)
    return ""
