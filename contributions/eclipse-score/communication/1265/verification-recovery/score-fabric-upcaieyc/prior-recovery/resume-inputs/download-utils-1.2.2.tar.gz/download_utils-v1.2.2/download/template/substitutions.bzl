load("@bazel_skylib//lib:structs.bzl", "structs")
load("@bazel_skylib//lib:types.bzl", "types")
load(":interpolations.bzl", _interpolations = "interpolations")
load(":substitution.bzl", _resolve = "resolve")

visibility("//...")

DOC = """Provide multiple substitutions for templated downloads from JSON files.

Use this tag with the `download_template` module extension to load one or more JSON files that define substitution values used by templated attributes (for example `{version}`, `{triplet}`, `{cpu}`, `{os}`, `{libc}`).

# Example

```py
download = use_extension("//download/template:defs.bzl", "download_template")
download.substitutions(
    srcs = [
        "//download/template:rust.cpu.json",
        "//download/template:rust.vendor.json",
    ],
)
```

# JSON schema

Each JSON file contains a map from substitution key to either:
- A string value, used as the default:
  ```json
  { "key": "value" }
  ```
- A single-entry map of match -> select, where `select` is a map of cases:
  ```json
  { "key": { "{variable}": { "case1": "value1", "//conditions:default": "fallback" } } }
  ```

# JSON
```json
{
  "rust.vendor": {
    "{os}": {
      "macos": "apple",
      "windows": "pc",
      "//conditions:default": "unknown"
    }
  },
  "rust.os": {
    "//conditions:default": "{os}"
  }
}
```

# Notes
- The match string (for example, `"{os}"`) and `select` values may include other substitutions like `"{cpu}"` or `"{libc}"`.
- If a value is a plain string, it is treated as `select = {"//conditions:default": "<value>"}`.
- Substitutions are resolved iteratively; unresolved values depending on yet-to-be-defined keys are retried up to a recursion limit.
- Provide only one match entry per key; if multiple are needed, split into separate keys.
"""

ATTRS = {
    "srcs": attr.label_list(
        doc = "JSON files to read the substitution data from.",
        allow_empty = False,
        allow_files = [".json"],
    ),
}

download_template_substitutions = tag_class(
    doc = DOC,
    attrs = ATTRS,
)

substitutions = download_template_substitutions

def read(ctx, srcs):
    substitutions = []

    for src in srcs:
        data = ctx.read(src)
        map = json.decode(data)

        if not types.is_dict(map):
            fail("substitution data must be a map: " + type(map))

        if not map:
            fail("no substitutions available: " + str(src))

        for key, value in map.items():
            if not types.is_string(key):
                fail("substitution `key` must be a string: " + type(key))

            if types.is_string(value):
                substitution = struct(
                    key = key,
                    match = "//conditions:default",
                    select = {
                        "//conditions:default": value,
                    },
                )
                substitutions.append(substitution)
                continue

            if not types.is_dict(value):
                fail("substitution `match` must be a map: " + type(value))

            if len(value) != 1:
                fail("substitution `match` map must have a single key: " + type(value))

            for match, select in value.items():
                if not types.is_string(match):
                    fail("substitution `match` value must be a string: " + type(match))

                if not types.is_dict(select):
                    fail("substitution `select` must be a map: " + type(select))

                for k, v in select.items():
                    if not types.is_string(k):
                        fail("substitution `select` key must be a string: " + type(select))
                    if not types.is_string(v):
                        fail("substitution `select` value must be a string: " + type(select))

                substitution = struct(key = key, match = match, select = select)
                substitutions.append(substitution)
                break

    return tuple(substitutions)

def resolve(iterable, substitutions, interpolations, *, no_match_error = "No match found for `{key}`: {select}"):
    if not types.is_dict(substitutions):
        substitutions = structs.to_dict(substitutions)
    if types.is_set(interpolations):
        interpolations = interpolations._values

    for _ in range(10):
        unresolved = []
        for substitution in iterable:
            if substitution.key not in interpolations:
                unresolved.append(substitution)
                continue
            resolved = _resolve(substitution, substitutions, no_key_error = None, no_match_error = no_match_error)
            if resolved == None:
                interpolations |= _interpolations(structs.to_dict(substitution.select))._values
                unresolved.append(substitution)
                continue
            substitutions[resolved.key] = resolved.value
        if not unresolved or unresolved == iterable:
            return struct(**substitutions)
        iterable = unresolved

    fail("hit recursion limit attempting to resolve substitutions: %s" % unresolved)
