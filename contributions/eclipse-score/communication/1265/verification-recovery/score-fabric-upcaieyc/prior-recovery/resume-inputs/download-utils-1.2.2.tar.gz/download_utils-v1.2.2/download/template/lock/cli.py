from __future__ import annotations

from argparse import ArgumentParser, ArgumentTypeError
from functools import wraps
from multiprocessing import cpu_count
from pathlib import Path
from shlex import split
from sys import argv, exit, stderr
from typing import Callable, NoReturn, TypeVar
from urllib.error import HTTPError

from download.template.lock.file import load as file
from download.template.lock.file import lock, upload
from download.template.lock.integrity import SRIValueError


class BazelArgumentParser(ArgumentParser):
    def convert_arg_line_to_args(self, line):
        return split(line)


def parser(exe: Path) -> ArgumentParser:
    return BazelArgumentParser(
        prog=exe.name,
        description="Performs operations on a `@download_utils//download/template` lockfile",
        fromfile_prefix_chars="@",
    )


T = TypeVar("T")


def argument(func: Callable[[str], T]) -> Callable[[str], T]:
    @wraps(func)
    def _wrapped(value: str) -> T:
        try:
            return func(value)
        except ValueError as e:
            raise ArgumentTypeError(str(e))
        except TypeError as e:
            raise ArgumentTypeError(str(e))

    return _wrapped


def arguments(prsr: ArgumentParser) -> None:
    sub = prsr.add_subparsers()

    lk = sub.add_parser(
        "lock",
        help="Updates a lock file with sub-resource integrities. Validates current sub-resource integrities are correct.",
    )
    lk.set_defaults(func=lock)
    lk.add_argument(
        "--allow",
        metavar="STATUS",
        type=int,
        help="HTTP status codes allowed when calculating sub-resource integrities. Useful to pass `--allow 404` when setting up a mirror.",
        dest="allowlist",
        action="extend",
        nargs="*",
        default=[],
    )
    lk.add_argument(
        "--jobs",
        type=int,
        default=cpu_count(),
        help="Number of uploads to run in parallel.",
    )
    lk.add_argument(
        "file",
        help="The `@download_utils//download/template` lockfile.",
        type=argument(file),
        metavar="FILE",
    )

    up = sub.add_parser(
        "upload",
        help="Uploads the files to a mirror.",
    )
    up.set_defaults(func=upload)
    up.add_argument(
        "--jobs",
        type=int,
        default=cpu_count(),
        help="Number of downloads to run in parallel.",
    )
    up.add_argument(
        "file",
        help="The `@download_utils//download/template` lockfile.",
        type=argument(file),
        metavar="FILE",
    )


def main(exe: Path, *args: str) -> int:
    prsr = parser(exe)
    arguments(prsr)

    try:
        parsed = prsr.parse_args(args)
    except FileNotFoundError as e:
        print(f"fatal: {e}", file=stderr)
        return 2

    data = vars(parsed)
    func = data.pop("func")
    assert callable(func)

    try:
        result = func(**data)
        if isinstance(result, int):
            return result
        assert result is None, result
        return 0
    except HTTPError as e:
        print(f"fatal: {e.code}: {e.reason}: {e.url}", file=stderr)
        return 2
    except SRIValueError as e:
        print(f"fatal: {e}", file=stderr)
        return 3
    except KeyboardInterrupt:
        return 130


def entry() -> NoReturn:
    exit(main(Path(argv[0]), *argv[1:]))
