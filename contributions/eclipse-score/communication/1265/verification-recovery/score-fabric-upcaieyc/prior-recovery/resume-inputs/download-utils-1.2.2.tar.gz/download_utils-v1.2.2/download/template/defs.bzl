load(":extension.bzl", _template = "template")

visibility("public")

download_template = _template
