load("@bazel_skylib//lib:structs.bzl", "structs")
load("@bazel_skylib//lib:types.bzl", "types")
load(":interpolations.bzl", _interpolations = "interpolations")
load(":render.bzl", "render")
load(":substitutions.bzl", "resolve")

visibility("//...")

ATTRS = {
    "name": attr.string(
        doc = "The templated name for each download repository. This needs to be unique across all download repositories that the extension creates.",
        mandatory = True,
    ),
    "lock": attr.label(
        doc = "A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads.",
        allow_single_file = [".json"],
        mandatory = True,
    ),
    "substitutions": attr.string_list_dict(
        doc = "Substitution values for the templates. All permutations will result in a repository.",
    ),
    "uploads": attr.string_list(
        doc = "Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`",
    ),
}

def _product(substitutions):
    maps = [{}]
    for key, values in substitutions.items():
        maps = [{key: value} | m for m in maps for value in values]
    return [struct(**m) for m in maps]

def _integrities(ctx, lock):
    lock = ctx.path(lock)
    if not lock.exists:
        return lock, struct()
    map = json.decode(ctx.read(lock))

    if not types.is_dict(map):
        fail("lock file must contain a map: " + type(map))

    urls = map.pop("urls", None)
    if not urls:
        return lock, struct()
    if not types.is_list(urls):
        fail("lock file `urls` must be a list: " + type(urls))
    for url in urls:
        if not types.is_string(url):
            fail("lock file `urls` items must be strings: " + type(url))

    output = {}
    integrities = map.pop("integrities", None)
    if not integrities:
        return lock, struct()
    if not types.is_dict(integrities):
        fail("lock file `integrities` must contain a map: " + type(integrities))
    for integrity, data in integrities.items():
        if not types.is_string(integrity):
            fail("lock file `integrities` keys must be strings: " + type(integrity))
        if not types.is_dict(data):
            fail("lock file `integrities` values must be a map: " + type(data))
        if integrity.startswith("#"):
            continue
        for url in urls:
            output[render(url, data)] = integrity

    return lock, struct(**output)

# https://github.com/bazelbuild/bazel-skylib/pull/578
def _merge(first, *rest):
    map = structs.to_dict(first)
    for r in rest:
        map |= structs.to_dict(r)
    return struct(**map)

def _integrity(integrities, urls):
    for url in urls:
        value = getattr(integrities, url, None)
        if value:
            return value

    return ""

def _filter(resolved, interpolations):
    if types.is_set(interpolations):
        interpolations = interpolations._values
    filtered = {k: v for k, v in structs.to_dict(resolved).items() if k in interpolations}
    missing = [r for r in interpolations if r not in filtered]
    if missing:
        fail("no substitution for: " + ", ".join(["`{%s}`" % m for m in missing]))
    return struct(**filtered)

def _pad(value, char, count):
    s = str(value)
    for _ in range(count):
        if len(s) >= count:
            return s
        s = char + s
    fail("failed to pad")

def implementation(ctx, rule, attrs, data):
    names = []

    map = {k: v for k, v in structs.to_dict(attrs).items()}
    substitutions = map.pop("substitutions")
    lock, integrities = _integrities(ctx, map.pop("lock"))
    map.pop("uploads")

    output = {
        "urls": attrs.urls,
        "uploads": attrs.uploads,
        "integrities": {},
    }
    interpolations = _interpolations(map)

    for i, product in enumerate(_product(substitutions)):
        resolved = resolve(data, product, interpolations)
        merged = _merge(resolved, product)
        rendered = render(map, merged)
        integrity = _integrity(integrities, rendered.urls)
        rule(integrity = integrity, **structs.to_dict(rendered))
        names.append(rendered.name)
        output["integrities"][integrity or "#unlocked[%s]" % _pad(i, "0", 3)] = _filter(merged, interpolations.urls)

    ctx.file(lock, json.encode_indent(output))

    reproducible = not any([not k or k.startswith("#") for k in output["integrities"].keys()])
    if not reproducible:
        print("`download_template` is not reproducible unless `%s` is locked. Run `bazel run @download_utils//download/template/lock %s`" % (attrs.lock, lock))
    return names, reproducible
