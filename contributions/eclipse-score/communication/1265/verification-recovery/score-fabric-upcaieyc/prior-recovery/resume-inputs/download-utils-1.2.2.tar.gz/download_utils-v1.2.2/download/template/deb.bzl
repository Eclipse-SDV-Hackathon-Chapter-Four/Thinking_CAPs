load("//download/deb:repository.bzl", _DEB = "ATTRS", _rule = "deb")
load(":repository.bzl", _ATTRS = "ATTRS", _implementation = "implementation")

visibility("//...")

DOC = """Download and extract Debian packages using templated attributes.

Use this tag with the `download_template` module extension to expand attribute templates (for example, versions and triplets) and materialize one or more external repositories from .deb files. Each expansion produces a repository that you can reference via `use_repo`.

# Concepts

- Attribute templating: Fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: Each `triplet` (for example, `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}`.
- Substitutions: Provide your own key/value mappings; values may reference other substitutions.
- Built-ins: `download_utils` provides helpful variables such as `{rust.archive.basename}`.
- Data archive: This tag extracts the payload from the .deb (the `data.tar.*` archive).

# Examples

## Debian package expanded by version and triplet

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")
download.deb(
    name = "busybox-{version}-{cpu}-{os}",
    srcs = ["busybox"],
    links = {"busybox": "entrypoint"},
    lock = "//busybox:lock.json",
    strip_prefix = "usr/bin",
    substitutions = {
        "version": ["1.36.1"],
        "revision": ["6"],
        "triplet": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
        ],
    },
    uploads = [
        "https://gitlab.arm.com/api/v4/projects/bazel%2Fdownload_utils/packages/generic/busybox-static/{version}/busybox-static_{version}-{revision}_{cpu}.deb",
    ],
    urls = [
        "https://gitlab.arm.com/api/v4/projects/bazel%2Fdownload_utils/packages/generic/busybox-static/{version}/busybox-static_{version}-{revision}_{cpu}.deb",
        "https://snapshot-cloudflare.debian.org/archive/debian/20240210T223313Z/pool/main/b/busybox/busybox-static_{version}-{revision}_{cpu}.deb",
    ],
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock busybox/lock.json
```
- Alternatively, fill integrities from upstream checksum files.

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload busybox/lock.json
```

# Notes

- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules.
- This tag extracts only the data archive inside the .deb (`data.tar.*`).
"""

ATTRS = _DEB | _ATTRS
ATTRS.pop("integrity")

def implementation(ctx, attrs, data):
    return _implementation(ctx, _rule, attrs, data)

download_template_deb = tag_class(
    doc = DOC,
    attrs = ATTRS,
)

deb = download_template_deb
