load("//download/archive:repository.bzl", _ARCHIVE = "ATTRS", _rule = "archive")
load(":repository.bzl", _ATTRS = "ATTRS", _implementation = "implementation")

visibility("//...")

DOC = """Download and extract archives using templated attributes.

Use this tag with the `download_template` module extension to materialize one or more external repositories by expanding attribute templates with substitutions (e.g., `versions` and `triplets`). Each expanded instance produces a repository that can be referenced via `use_repo`.

# Concepts

- Attribute templating: Fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: Each `triplet` (e.g., `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}` for reuse.
- Substitutions: Provide your own key/value mappings, which may reference other substitutions.
- Built-ins: `download_utils` adds helpful variables such as `{rust.archive.basename}`.
- Lock workflow: `bazel mod tidy` creates a lock file with resolved URLs; integrities are added via a helper command.

# Examples

## Archive downloads expanded by `version` and `triplet`

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

download.archive(
    name = "coreutils-{version}-{triplet}",
    srcs = ["entrypoint"],
    links = {
        "coreutils{executable.extension}": "entrypoint",
    },
    lock = "//coreutils:lock.json",
    strip_prefix = "coreutils-{version}-{rust.triplet}",
    substitutions = {
        "version": ["0.1.0"],
        "triplets": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
            "arm64-linux-musl",
            "amd64-linux-musl",
            "amd64-windows-msvc",
            "arm64-macos-darwin",
            "amd64-macos-darwin",
        ],
    },
    urls = [
        "https://github.com/uutils/coreutils/releases/download/{version}/coreutils-{version}-{rust.archive.basename}",
    ],
)

use_repo(
    download,
    "coreutils-0.1.0-amd64-linux-gnu",
    "coreutils-0.1.0-amd64-linux-musl",
    "coreutils-0.1.0-amd64-macos-darwin",
    "coreutils-0.1.0-amd64-windows-msvc",
    "coreutils-0.1.0-arm64-linux-gnu",
    "coreutils-0.1.0-arm64-linux-musl",
    "coreutils-0.1.0-arm64-macos-darwin",
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs are resolved; integrities are initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock coreutils/lock.json
```
- Alternatively, fill integrities from upstream checksum files.

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload coreutils/lock.json
```

# Notes
- The `lock` attribute tracks the expanded URLs and integrities for reproducible downloads.
- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions` calls.
- You can add more substitutions in your own modules.
"""

ATTRS = _ARCHIVE | _ATTRS
ATTRS.pop("integrity")

def implementation(ctx, attrs, data):
    return _implementation(ctx, _rule, attrs, data)

download_template_archive = tag_class(
    doc = DOC,
    attrs = ATTRS,
)

archive = download_template_archive
