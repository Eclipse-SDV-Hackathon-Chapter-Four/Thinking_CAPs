load("//lib:build.bzl", "build", _BUILD = "ATTRS")
load("//lib:commands.bzl", "commands", _COMMANDS = "ATTRS")
load("//lib:download_and_extract.bzl", "download_and_extract", _DOWNLOAD_AND_EXTRACT = "ATTRS")
load("//lib:links.bzl", "links", _LINKS = "ATTRS")
load("//lib:metadata.bzl", "metadata", _METADATA = "ATTRS")
load("//lib:patch.bzl", "patch", _PATCH = "ATTRS")

visibility("//download/...")

DOC = """Download an archive and extract its contents into an external repository.

This `repository_rule` downloads a compressed archive from one or more URLs, verifies integrity (when provided), extracts it (optionally removing a `strip_prefix`), and prepares a usable repository with optional links, metadata, custom `BUILD` template, patches, and post-extract commands.

Supported archive types include `.zip`, `.tar`, `.tar.gz`, `.tar.bz2`, `.tar.xz`, and `.tar.zst`. If the extension cannot be inferred from the URL, set the `extension` attribute.

# Examples

Minimal usage:

```py
download_archive = use_repo_rule("@download_utils//download/archive:defs.bzl", "download_archive")
download_archive(
    name = "my_lib_src",
    urls = ["https://example.com/my_lib-1.2.3.tar.gz"],
)
```

With `integrity` and `strip_prefix`:

```py
download_archive(
    name = "my_lib_src",
    urls = ["https://example.com/my_lib-1.2.3.tar.gz"],
    integrity = "sha256-AbCdEfGhIjKlMnOpQrStUvWxYz0123456789+/==",
    strip_prefix = "my_lib-1.2.3",
    srcs = ["include/**", "src/**"],  # forwarded to the BUILD template as {{srcs}}
)
```

With `links`, hermetic `commands`, and `tools`:

```py
download_archive(
    name = "my_lib_src",
    urls = ["https://example.com/my_lib-1.2.3.tar.gz"],
    integrity = "sha256-AbCdEfGhIjKlMnOpQrStUvWxYz0123456789+/==",
    links = {
        "LICENSE": "third_party/my_lib/LICENSE",
    },
    commands = {
        "Make headers read-only": [
            "$(location @coreutils//:entrypoint)", "chmod", "-R", "a-w", "include",
        ],
    },
    tools = ["@coreutils//:entrypoint"],
)
```

# Tips

- Always provide an `integrity` for secure and reproducible builds.
- Use `tools` and `$(location …)` in `commands` to ensure hermetic, platform-independent execution.
"""

ATTRS = _COMMANDS | _DOWNLOAD_AND_EXTRACT | _PATCH | _BUILD | _LINKS | _METADATA | {
    "extension": attr.string(
        doc = "The extension of the archive when not available from the URL.",
        values = ["", ".zip", ".tar", ".tar.gz", ".tar.bz2", ".tar.xz", ".tar.zst"],
    ),
}

def implementation(rctx):
    canonical = {a: getattr(rctx.attr, a) for a in ATTRS} | {"name": rctx.name}

    canonical |= download_and_extract(rctx, extension = rctx.attr.extension)
    canonical |= build(rctx)
    canonical |= patch(rctx)
    canonical |= links(rctx)
    canonical |= commands(rctx)

    return metadata(rctx, canonical)

archive = repository_rule(
    doc = DOC,
    implementation = implementation,
    attrs = ATTRS,
)
