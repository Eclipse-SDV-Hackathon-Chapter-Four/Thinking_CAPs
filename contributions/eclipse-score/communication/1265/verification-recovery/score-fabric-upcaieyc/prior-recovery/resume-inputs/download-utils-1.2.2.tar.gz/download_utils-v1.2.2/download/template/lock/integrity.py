from __future__ import annotations

import binascii
import hashlib
from base64 import standard_b64decode as b64decode
from base64 import standard_b64encode as b64encode
from types import TracebackType
from typing import Any, Final, Literal, Protocol, TypeAlias, cast

from download.template.lock.typing import SupportsReadClose

Algorithm: TypeAlias = Literal["sha256", "sha512"]

ALGORITHMS: Final = {"sha256", "sha512"}
ALGORITHM: Final[Algorithm] = "sha256"


class Hash(Protocol):
    @property
    def name(self) -> Algorithm: ...

    def digest(self) -> bytes: ...


class SRIValueError(ValueError):
    pass


class SRI:
    def __init__(self, value: str | Hash, /) -> None:
        if isinstance(value, str):
            algorithm, found, hash = value.partition("-")
            if not found:
                raise SRIValueError(
                    f"no sub-resource integrity separator found: {value}"
                )
            try:
                self.__digest = b64decode(hash)
            except binascii.Error as e:
                raise SRIValueError(f"invalid base64 hash: {e}: {value}") from e
        else:
            algorithm = value.name
            self.__digest = value.digest()

        if algorithm not in ALGORITHMS:
            raise SRIValueError(
                f"unsupported sub-resource integrity algorithm '{value}' choose one of {', '.join(repr(a) for a in ALGORITHMS)}"
            )

        self.__algorithm = cast(Algorithm, algorithm)

    @property
    def algorithm(self) -> Algorithm:
        return self.__algorithm

    @property
    def name(self) -> Algorithm:
        return self.algorithm

    def hash(self) -> str:
        return b64encode(self.digest()).decode("utf8")

    def digest(self) -> bytes:
        return self.__digest

    def hexdigest(self) -> str:
        return self.digest().hex()

    def __eq__(self, value: Any) -> bool:
        if not isinstance(value, SRI):
            return False
        return self.algorithm == value.algorithm and self.digest() == value.digest()

    def __hash__(self) -> int:
        return hash((self.algorithm, self.hash))

    def __str__(self) -> str:
        return f"{self.algorithm}-{self.hash()}"


class SupportsSRI:
    def sri(self) -> SRI: ...


Checksum: TypeAlias = Algorithm | SRI


class SupportsChecksum:
    def checksum(self) -> Checksum: ...


class Stream(SupportsReadClose, SupportsSRI):
    def __init__(self, stream: SupportsReadClose, algorithm: Algorithm = ALGORITHM):
        self.__stream = stream
        self.__hash = hashlib.new(algorithm)

    def read(self, size: int = -1, /) -> bytes:
        data = self.__stream.read(size)
        self.__hash.update(data)
        return data

    def close(self) -> None:
        self.__stream.close()

    @property
    def name(self) -> Algorithm:
        return self.__hash.name

    @property
    def algorithm(self) -> Algorithm:
        return self.name

    def digest(self) -> bytes:
        return self.__hash.digest()

    def hexdigest(self) -> str:
        return self.digest().hex()

    def sri(self) -> SRI:
        return SRI(self)

    def __enter__(self) -> "Stream":
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
        /,
    ) -> bool | None:
        self.close()
