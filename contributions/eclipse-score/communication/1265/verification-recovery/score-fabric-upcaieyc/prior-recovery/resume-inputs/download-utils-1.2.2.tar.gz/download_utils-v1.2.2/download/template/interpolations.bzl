load("@bazel_skylib//lib:sets.bzl", "sets")
load("@bazel_skylib//lib:structs.bzl", "structs")
load("@bazel_skylib//lib:types.bzl", "types")

def _string(value):
    interpolations = sets.make()

    for _ in range(0xbadbae):
        _, found, value = value.partition("{")
        if not found:
            break
        if value.startswith("{"):
            continue

        variable, found, value = value.partition("}")
        if not found:
            fail("failed to find closing bracket: " + value)

        sets.insert(interpolations, variable)

    return interpolations

def _nested(value):
    if type(value) == "Label":
        return sets.make()
    if types.is_string(value):
        return _string(value)
    fail("unhandled nested interpolations type: %s (%s)" % (value, type(value)))

def _list(value):
    interpolations = sets.make()
    for v in value:
        interpolations = sets.union(interpolations, _nested(v))
    return interpolations

def _dict(value):
    interpolations = sets.make()
    for k, v in value.items():
        interpolations = sets.union(interpolations, _nested(k))
        interpolations = sets.union(interpolations, _nested(v))
    return interpolations

def _any(value):
    if type(value) == "Label":
        return sets.make()
    if types.is_int(value):
        return sets.make()
    if types.is_bool(value):
        return sets.make()
    if types.is_string(value):
        return _string(value)
    if types.is_list(value):
        return _list(value)
    if types.is_dict(value):
        return _dict(value)
    fail("unhandled interpolations type: %s (%s)" % (type(value), value))

def interpolations(value):
    if not types.is_dict(value):
        value = structs.to_dict(value)
    data = {k: _any(v) for k, v in value.items()}
    all = {}
    for vars in data.values():
        all |= vars._values
    data["_values"] = all
    return struct(**data)
