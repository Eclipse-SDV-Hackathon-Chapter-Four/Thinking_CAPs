# *******************************************************************************
# Copyright (c) 2026 Contributors to the Eclipse Foundation
#
# See the NOTICE file(s) distributed with this work for additional
# information regarding copyright ownership.
#
# This program and the accompanying materials are made available under the
# terms of the Apache License Version 2.0 which is available at
# https://www.apache.org/licenses/LICENSE-2.0
#
# SPDX-License-Identifier: Apache-2.0
# *******************************************************************************

# Configuration file for the Sphinx documentation builder.

project = "S-CORE Crates"
project_url = "https://eclipse-score.github.io/score-crates"
version = "0.1"

extensions = [
    "sphinxcontrib.plantuml",
    "score_sphinx_bundle",
]
