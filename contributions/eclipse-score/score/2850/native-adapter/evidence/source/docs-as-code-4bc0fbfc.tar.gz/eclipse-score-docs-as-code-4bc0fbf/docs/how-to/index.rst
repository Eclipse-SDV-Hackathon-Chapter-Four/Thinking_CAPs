..
   # *******************************************************************************
   # Copyright (c) 2026 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

.. _docs_how-to:

How To
======

Here you find practical guides on how to use docs-as-code.

.. toctree::
   :maxdepth: 1

   get_started
   agentic_software_development
   setup
   write_docs
   faq
   other_modules
   dashboards_and_quality_gates
   source_to_doc_links
   test_to_doc_links
   add_extensions
