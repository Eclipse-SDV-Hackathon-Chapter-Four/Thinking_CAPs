# *******************************************************************************
# Copyright (c) 2025 Contributors to the Eclipse Foundation
#
# See the NOTICE file(s) distributed with this work for additional
# information regarding copyright ownership.
#
# This program and the accompanying materials are made available under the
# terms of the Apache License Version 2.0 which is available at
# https://www.apache.org/licenses/LICENSE-2.0
#
# SPDX-License-Identifier: Apache-2.0
# *******************************************************************************
"""
This 'sphinx-extension' is responsible to allow for functional drawings of UML diagrams

    - Features
    - Logical Interfaces
    - Modules
    - Components
    - Component Interfaces

and all applicable linkages between them.

It provides this functionality by adding classes to `needs_render_context`,
which then can be invoked inside 'needarch' and 'needuml' blocks in rst files.
"""

import hashlib
import time
from collections.abc import Callable
from functools import cache
from pathlib import Path
from typing import Any, cast

from score_draw_uml_funcs.draw_helpers import (
    gen_header,
    gen_interface_element,
    gen_link_text,
    gen_struct_element,
    get_alias,
    get_hierarchy_text,
    get_impl_comp_from_logic_iface,
    get_interface_from_component,
    get_interface_from_int,
    get_module,
)
from sphinx.application import Sphinx
from sphinx_needs.logging import get_logger

CollectResult = tuple[
    str,  # structure_text
    str,  # link_text
    dict[str, str],  # proc_impl_interfaces
    dict[str, list[str]],  # proc_used_interfaces
    dict[str, str],  # impl_comp
    list[str],  # proc_modules
]

logger = get_logger(__file__)


def setup(app: Sphinx) -> dict[str, object]:
    for key, value in draw_uml_function_context.items():
        app.config.needs_render_context.setdefault(key, value)
    return {
        "version": "0.1",
        "parallel_read_safe": True,
        "parallel_write_safe": True,
    }


@cache
def scripts_directory_hash():
    start = time.time()
    all = ""
    for file in Path(".devcontainer/sphinx_conf").glob("**/*.py"):
        with open(file) as f:
            all += f.read()
    hash_object = hashlib.sha256(all.encode("utf-8"))
    directory_hash = hash_object.hexdigest()
    logger.info(
        "calculate directory_hash = "
        + directory_hash
        + " within "
        + str(time.time() - start)
        + " seconds."
    )
    return directory_hash


#       ╭──────────────────────────────────────────────────────────────────────────────╮
#       │                           Actual drawing functions                           │
#       ╰──────────────────────────────────────────────────────────────────────────────╯


def _process_interfaces(
    iface_list: list[str],
    relation: str,
    need: dict[str, str],
    all_needs: dict[str, dict[str, str]],
    proc_dict: dict[str, str] | dict[str, list[str]],
    linkage_text: str,
) -> str:
    """Helper to process either implemented or used interfaces."""

    for iface in iface_list:
        # check for misspelled interface
        if not all_needs.get(iface, []):
            logger.info(f"{need}: {relation} {iface} could not be found")
            continue

        if relation == "implements":
            proc_impl_dict = cast(dict[str, str], proc_dict)
            if not proc_impl_dict.get(iface, []):
                linkage_text += (
                    f"{gen_link_text(need, '-u->', all_needs[iface], 'implements')} \n"
                )
                proc_impl_dict[iface] = need["id"]
        else:  # "uses"
            proc_used_dict = cast(dict[str, list[str]], proc_dict)
            if not proc_used_dict.get(iface, []):
                proc_used_dict[iface] = [need["id"]]
            else:
                proc_used_dict[iface].append(need["id"])

    return linkage_text


def draw_comp_incl_impl_int(
    need: dict[str, str],
    all_needs: dict[str, dict[str, str]],
    proc_impl_interfaces: dict[str, str],
    proc_used_interfaces: dict[str, list[str]],
    white_box_view: bool = False,
) -> tuple[str, str, dict[str, str], dict[str, list[str]]]:
    """This function draws a component including any interfaces which are implemented
    by the component

    :param dict[str,str] need: Component which should be drawn
    :param dict all_needs: Dictionary containing all needs
    :param dict[str,dict] proc_impl_interfaces: Dictionary containing
    all implemented interfaces which were already processed during this cycle
    :param dict[str,dict] proc_used_interfaces: Dictionary containing
    all used interfaces which were already processed during this cycle
    """
    # Draw outer component
    structure_text = f"{gen_struct_element('component', need)}  {{\n"
    linkage_text = ""

    # Draw inner (sub)components recursively if requested
    if white_box_view:
        for need_inc in need.get("consists_of", []):
            curr_need = all_needs.get(need_inc, {})

            # check for misspelled include
            if not curr_need:
                logger.info(f"{need}: include {need_inc} could not be found")
                continue

            if curr_need["type"] != "comp":
                continue

            sub_structure, sub_linkage, proc_impl_interfaces, proc_used_interfaces = (
                draw_comp_incl_impl_int(
                    curr_need, all_needs, proc_impl_interfaces, proc_used_interfaces
                )
            )

            structure_text += sub_structure
            linkage_text += sub_linkage

    # close outer component
    structure_text += f"}} /' {need['title']} '/ \n\n"

    # Find implemented real interfaces inside the module/component
    local_impl_interfaces = get_interface_from_component(need, "implements", all_needs)
    local_used_interfaces = get_interface_from_component(need, "uses", all_needs)

    # Process implemented interfaces
    linkage_text = _process_interfaces(
        local_impl_interfaces,
        "implements",
        need,
        all_needs,
        proc_impl_interfaces,
        linkage_text,
    )

    # Process used interfaces
    linkage_text = _process_interfaces(
        local_used_interfaces,
        "uses",
        need,
        all_needs,
        proc_used_interfaces,
        linkage_text,
    )

    return structure_text, linkage_text, proc_impl_interfaces, proc_used_interfaces


def draw_impl_interface(
    need: dict[str, str],
    all_needs: dict[str, dict[str, str]],
    local_impl_interfaces: set[str],
) -> set[str]:
    # At First Logical Implemented Interfaces outside the Module
    for need_inc in need.get("includes", []):
        curr_need = all_needs.get(need_inc, {})

        # check for misspelled include
        if not curr_need:
            logger.info(f"{need}: include with id {need_inc} could not be found")
            continue

        draw_impl_interface(curr_need, all_needs, local_impl_interfaces)

    # Find implemented logical interface of the components inside the module
    local_impl_interfaces.update(
        get_interface_from_component(need, "implements", all_needs)
    )

    return local_impl_interfaces


def _process_impl_interfaces(
    need: dict[str, str],
    all_needs: dict[str, dict[str, str]],
    proc_impl_interfaces: dict[str, str],
    structure_text: str,
) -> str:
    """Handle implemented interfaces outside the boxes."""
    local_impl_interfaces = draw_impl_interface(need, all_needs, set())
    # Add all interfaces which are implemented by component to global list
    # and provide implementation
    for iface in local_impl_interfaces:
        # check for misspelled implements
        if not all_needs.get(iface, []):
            logger.info(f"{need}: implements {iface} could not be found")
            continue
        if not proc_impl_interfaces.get(iface, []):
            structure_text += gen_interface_element(iface, all_needs, True)
    return structure_text


def _process_used_interfaces(
    need: dict[str, str],
    all_needs: dict[str, dict[str, str]],
    proc_impl_interfaces: dict[str, str],
    proc_used_interfaces: dict[str, list[str]],
    local_impl_interfaces: list[str],
    structure_text: str,
    linkage_text: str,
) -> tuple[str, str]:
    """Handle all interfaces which are used by component."""
    for iface, comps in proc_used_interfaces.items():
        if iface not in proc_impl_interfaces:
            # Add implementing components and modules
            impl_comp_str = get_impl_comp_from_logic_iface(iface, all_needs)
            impl_comp = all_needs.get(impl_comp_str[0], {}) if impl_comp_str else ""

            if impl_comp:
                retval = get_hierarchy_text(impl_comp_str[0], all_needs)
                structure_text += retval[2]  # module open
                structure_text += retval[0]  # rest open
                structure_text += retval[1]  # rest close
                structure_text += retval[3]  # module close
                if iface not in local_impl_interfaces:
                    structure_text += gen_interface_element(iface, all_needs, True)
                # Draw connection between implementing components and interface
                linkage_text += f"{
                    gen_link_text(impl_comp, '-u->', all_needs[iface], 'implements')
                } \n"
            else:
                # Add only interface if component not defined
                print(f"{iface}: No implementing component defined")
                structure_text += gen_interface_element(iface, all_needs, True)

        # Interface can be used by multiple components
        for comp in comps:
            linkage_text += f"{
                gen_link_text(all_needs[comp], '-d[#green]->', all_needs[iface], 'uses')
            } \n"

    return structure_text, linkage_text


def draw_module(
    need: dict[str, str],
    all_needs: dict[str, dict[str, str]],
    proc_impl_interfaces: dict[str, str],
    proc_used_interfaces: dict[str, list[str]],
) -> tuple[str, str, dict[str, str], dict[str, list[str]]]:
    """
    Drawing and parsing function of a component.

    Example:
        input:
            need: component_1
            all_needs: all_needs_dict
            processed_interfaces: set()
        return:
            # Part 1 Structure Text
            component "Component 1" as C1 {
            }
            interface "Component Interface 1" as CI1 {
            real operation 1 ()
            real operation 2 ()
            }

            interface "Logical Interface 1" as LI1 {
            Logical Operation 1
            Logical Operation 2
            }

            interface "Component Interface 3" as CI3 {
            real operation 5 ()
            real operation 6 ()
            }

            # Part 2 Linkage Text
            CI1 --> LI1: implements
            C1 --> CI1: implements
            C1 --> CI3: uses

            # Part 3 processed_interfaces
            {
             'real_interface_1',
             'real_interface_2',
             'logical_interface_1'
            }

            # Part 4 processed_interfaces
            {
             'logical_interface_1',
             'logical_interface_2'
            }

            Note: part 1 and 2 are returned as one text item separated by '\n'.
            They are interpreted and names are shortened here to aid readability.
    Returns:
        Tuple of 4 parts.
        (Structure Text, Linkage Text, Processed (Real Interfaces),
        Processed Logical Interfaces)
    """
    linkage_text = ""
    structure_text = ""

    # Draw all implemented interfaces outside the boxes
    local_impl_interfaces = draw_impl_interface(need, all_needs, set())
    structure_text = _process_impl_interfaces(
        need, all_needs, proc_impl_interfaces, structure_text
    )

    # Draw outer module
    structure_text += f"{gen_struct_element('package', need)}  {{\n"

    # Draw inner components recursively
    for need_inc in need.get("includes", []):
        curr_need = all_needs.get(need_inc, {})
        # check for misspelled include
        if not curr_need:
            logger.info(f"{need}: include with id {need_inc} could not be found")
            continue
        if curr_need["type"] not in ["comp", "mod"]:
            continue
        sub_structure, sub_linkage, proc_impl_interfaces, proc_used_interfaces = (
            draw_comp_incl_impl_int(
                curr_need, all_needs, proc_impl_interfaces, proc_used_interfaces
            )
        )
        structure_text += sub_structure
        linkage_text += sub_linkage

    # close outer component
    structure_text += f"}} /' {need['title']} '/ \n\n"

    # Add all interfaces which are used by component
    structure_text, linkage_text = _process_used_interfaces(
        need,
        all_needs,
        proc_impl_interfaces,
        proc_used_interfaces,
        list(local_impl_interfaces),
        structure_text,
        linkage_text,
    )

    # Remove duplicate links
    linkage_text = "\n".join(set(linkage_text.split("\n"))) + "\n"

    return structure_text, linkage_text, proc_impl_interfaces, proc_used_interfaces


def _resolve_component_for_view(
    need: dict[str, str], all_needs: dict[str, dict[str, str]]
) -> dict[str, str]:
    """Resolve component architecture views to their owning component."""
    if need.get("type") != "comp_arc_sta":
        return need

    component_ref = need.get("belongs_to")
    if isinstance(component_ref, list) and component_ref:
        component_id = component_ref[0]
        if len(component_ref) > 1:
            logger.info(
                f"{need}: component static view has multiple belongs_to targets, "
                f"using only first component: {component_id}"
            )

    else:
        component_id = component_ref
    if not component_id:
        logger.info(f"{need}: missing belongs_to for component static view")
        return need

    component_need = all_needs.get(component_id, {})
    if not component_need:
        logger.info(f"{need}: belongs_to component {component_id} could not be found")
        return need

    if component_need.get("type") != "comp":
        logger.info(f"{need}: belongs_to {component_id} is not a component")
        return need

    return component_need


#       ╭──────────────────────────────────────────────────────────────────────────────╮
#       │                    Classes with hashing to enable caching                    │
#       ╰──────────────────────────────────────────────────────────────────────────────╯


class draw_full_feature:
    def __repr__(self):
        return "draw_full_feature" + " in " + scripts_directory_hash()

    def _collect_interfaces_and_modules(
        self,
        need: dict[str, str],
        all_needs: dict[str, dict[str, str]],
        interfacelist: list[str],
        impl_comp: dict[str, str],
        proc_modules: list[str],
        proc_impl_interfaces: dict[str, str],
        proc_used_interfaces: dict[str, list[str]],
        structure_text: str,
        link_text: str,
    ) -> CollectResult:
        """Process interfaces and load modules for implementation."""
        for iface in interfacelist:
            if all_needs.get(iface):
                if iface:
                    comps = get_impl_comp_from_logic_iface(iface, all_needs)
                    if comps:
                        impl_comp[iface] = comps[0]

                if imcomp := impl_comp.get(iface):
                    module = get_module(imcomp, all_needs)
                    # FIXME: sometimes module is empty, then the following code fails
                    if not module:
                        logger.info(
                            f"FIXME: {need['id']}: "
                            f"Module for interface {iface} -> {imcomp} is empty."
                        )
                        continue

                    if module not in proc_modules:
                        tmp, link_text, proc_impl_interfaces, proc_used_interfaces = (
                            draw_module(
                                all_needs[module],
                                all_needs,
                                proc_impl_interfaces,
                                proc_used_interfaces,
                            )
                        )
                        structure_text += tmp
                        proc_modules.append(module)
            else:
                logger.info(f"{need}: Interface {iface} could not be found")
                continue
        return (
            structure_text,
            link_text,
            proc_impl_interfaces,
            proc_used_interfaces,
            impl_comp,
            proc_modules,
        )

    def _build_links(
        self,
        need: dict[str, str],
        all_needs: dict[str, dict[str, str]],
        interfacelist: list[str],
        impl_comp: dict[str, str],
        link_text: str,
    ) -> str:
        """Add actor-interface and interface-component relations."""
        for iface in interfacelist:
            if imcomp := impl_comp.get(iface):
                # Add relation between Actor and Interfaces
                link_text += f"{
                    gen_link_text(
                        {'id': 'Feature_User'}, '-d->', all_needs[iface], 'use'
                    )
                } \n"

                # Add relation between interface and component
                if imcomp := impl_comp.get(iface):
                    link_text += f"{
                        gen_link_text(
                            all_needs[imcomp],
                            '-u->',
                            all_needs[iface],
                            'implements',
                        )
                    } \n"
                else:
                    logger.info(
                        f"Interface {iface} is not implemented by any component"
                    )
            else:
                logger.info(f"{need}: Interface {iface} could not be found")
                continue
        return link_text

    def __call__(
        self, need: dict[str, str], all_needs: dict[str, dict[str, str]]
    ) -> str:
        interfacelist: list[str] = []
        impl_comp: dict[str, str] = dict()
        # Store all Elements which have already been processed
        proc_impl_interfaces: dict[str, str] = dict()
        proc_used_interfaces: dict[str, list[str]] = dict()
        proc_modules: list[str] = list()

        link_text = ""
        structure_text = (
            f'actor "Feature User" as {get_alias({"id": "Feature_User"})} \n'
        )

        # Define Feature as a package
        # structure_text += f"{gen_struct_element('package', need)} {{\n"

        # Add logical Interfaces / Interface Operations (aka includes)
        for need_inc in need.get("includes", []):
            # Generate list of interfaces since both interfaces
            # and interface operations can be included
            iface = get_interface_from_int(need_inc, all_needs)
            if iface not in interfacelist:
                interfacelist.append(iface)

        # Process interfaces and collect required modules
        (
            structure_text,
            link_text,
            proc_impl_interfaces,
            proc_used_interfaces,
            impl_comp,
            proc_modules,
        ) = self._collect_interfaces_and_modules(
            need,
            all_needs,
            interfacelist,
            impl_comp,
            proc_modules,
            proc_impl_interfaces,
            proc_used_interfaces,
            structure_text,
            link_text,
        )

        # Close Package
        # structure_text += f"}} /' {need['title']}  '/ \n\n"

        # Build all links between actor, interfaces, and components
        link_text = self._build_links(
            need, all_needs, interfacelist, impl_comp, link_text
        )

        # Remove duplicate links
        link_text = "\n".join(set(link_text.split("\n"))) + "\n"

        return gen_header() + structure_text + link_text


class draw_full_module:
    def __repr__(self):
        return "draw_full_module" + " in " + scripts_directory_hash()

    def __call__(
        self, need: dict[str, str], all_needs: dict[str, dict[str, str]]
    ) -> str:
        # Store all Elements which have already been processed
        proc_impl_interfaces: dict[str, str] = dict()
        proc_used_interfaces: dict[str, list[str]] = dict()
        structure_text, linkage_text, proc_impl_interfaces, proc_used_interfaces = (
            draw_module(need, all_needs, proc_impl_interfaces, proc_used_interfaces)
        )

        return gen_header() + structure_text + linkage_text


class draw_full_component:
    def __repr__(self):
        return "draw_full_component" + " in " + scripts_directory_hash()

    def __call__(
        self, need: dict[str, str], all_needs: dict[str, dict[str, str]]
    ) -> str:
        component_need = _resolve_component_for_view(need, all_needs)
        structure_text, linkage_text, proc_impl_interfaces, _ = draw_comp_incl_impl_int(
            component_need, all_needs, dict(), dict(), True
        )

        # Add all interfaces which are implemented by component to global list
        # and provide implementation. Use the interfaces collected during the
        # recursive consists_of walk so component drawings also include
        # interfaces implemented by nested subcomponents.
        for iface in proc_impl_interfaces:
            # check for misspelled implements
            if not all_needs.get(iface, []):
                logger.info(f"{need}: implements {iface} could not be found")
                continue

            structure_text += gen_interface_element(iface, all_needs, True)

        return gen_header() + structure_text + linkage_text


class draw_full_interface:
    def __repr__(self):
        return "draw_full_interface" + " in " + scripts_directory_hash()

    def __call__(
        self, need: dict[str, str], all_needs: dict[str, dict[str, str]]
    ) -> str:
        structure_text = gen_interface_element(need["id"], all_needs, True)

        return structure_text + "\n"


CallableType = Callable[[dict[str, Any], dict[str, dict[str, Any]]], str]

draw_uml_function_context: dict[str, CallableType] = {
    "draw_interface": draw_full_interface(),
    "draw_module": draw_full_module(),
    "draw_component": draw_full_component(),
    "draw_feature": draw_full_feature(),
}
