..
   # *******************************************************************************
   # Copyright (c) 2026 Contributors to the Eclipse Foundation
   #
   # See the NOTICE file(s) distributed with this work for additional
   # information regarding copyright ownership.
   #
   # This program and the accompanying materials are made available under the
   # terms of the Apache License Version 2.0 which is available at
   # https://www.apache.org/licenses/LICENSE-2.0
   #
   # SPDX-License-Identifier: Apache-2.0
   # *******************************************************************************

Getting started
===============

In an existing S-CORE repository, you can build the documentation using Bazel:

.. code-block:: bash

   bazel run //:docs

Open the generated site at ``_build/index.html`` in your browser.

In a new S-CORE repository, see :ref:`setup`.

After the initial setup, continue with :doc:`dashboards_and_quality_gates` to
build a repository dashboard and enforce CI quality gates.

Agentic software development
----------------------------

Docs-as-code also supports an agent-assisted development workflow. Manual and
agent-generated changes still converge on the same deterministic Lane A checks.

For an overview of that workflow, see :doc:`agentic_software_development`.
