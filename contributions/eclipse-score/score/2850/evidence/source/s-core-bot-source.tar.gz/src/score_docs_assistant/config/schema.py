"""AppConfig schema: every key, default, and constraint from contracts/config.md.

All models use `extra="forbid"` so unknown keys at any level are validation errors, and every
constraint is expressed as a pydantic validator so a single `AppConfig(**data)` call collects every
violation (via `ValidationError.errors()`) rather than failing on the first one.
"""

from __future__ import annotations

import ipaddress
import os
import re
from pathlib import Path
from typing import Literal
from urllib.parse import urlsplit

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

_ORIGIN_RE = re.compile(r"^https?://[^/@]+$")


CONTAINER_MARKER = "SCORE_ASSISTANT_CONTAINER"
_DNS_LABEL = re.compile(r"^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$")


def in_container_image() -> bool:
    """The application image sets this marker; configuration alone cannot enable container mode."""
    return os.environ.get(CONTAINER_MARKER) == "1"


def is_loopback_host(host: str) -> bool:
    if host.lower() == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def _validate_origin(origin: str) -> None:
    if "@" in origin:
        raise ValueError(f"{origin!r}: must not contain userinfo")
    if not _ORIGIN_RE.match(origin):
        raise ValueError(f"{origin!r}: must be http(s)://host[:port] with no path or wildcard")


class ServerConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    host: str = "127.0.0.1"
    port: int = Field(default=8080, ge=1, le=65535)
    allowed_hosts: list[str] = Field(default_factory=lambda: ["localhost", "127.0.0.1"])
    allowed_origins: list[str] = Field(
        default_factory=lambda: ["http://127.0.0.1:8080", "http://localhost:8080"]
    )

    @field_validator("host")
    @classmethod
    def _host_is_loopback(cls, v: str) -> str:
        # Inside the application image, 0.0.0.0 is checked against deployment.mode by AppConfig.
        if not is_loopback_host(v) and not (v == "0.0.0.0" and in_container_image()):
            raise ValueError("must be a loopback address (127.0.0.0/8, ::1, or localhost)")
        return v

    @field_validator("allowed_hosts")
    @classmethod
    def _allowed_hosts_non_empty(cls, v: list[str]) -> list[str]:
        if not v:
            raise ValueError("must be non-empty")
        return v

    @field_validator("allowed_origins")
    @classmethod
    def _allowed_origins_valid(cls, v: list[str]) -> list[str]:
        if not v:
            raise ValueError("must be non-empty")
        for origin in v:
            _validate_origin(origin)
        return v


class RuntimeConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    provider: Literal["ollama"] = "ollama"
    base_url: str = "http://127.0.0.1:11434"
    cloud_fallback: Literal[False] = False
    model_profile: str = "local-small"
    generation_model: str = Field(default="qwen3:4b-instruct", min_length=1)
    embedding_model: str = Field(default="nomic-embed-text", min_length=1)
    models_dir: Path | None = None
    context_tokens: int = Field(default=8192, ge=1024, le=131072)
    output_tokens: int = Field(default=900, ge=1)

    @field_validator("base_url")
    @classmethod
    def _base_url_local_http(cls, v: str) -> str:
        parts = urlsplit(v)
        if parts.scheme != "http":
            raise ValueError("scheme must be http")
        if "@" in parts.netloc:
            raise ValueError("must not contain userinfo")
        if parts.path not in ("", "/"):
            raise ValueError("must not contain a path")
        host = parts.hostname
        if host is None:
            raise ValueError("host must be a loopback address")
        # Inside the application image a private service name is checked by AppConfig against
        # deployment.runtime_private_hosts; everywhere else only loopback is accepted.
        if not is_loopback_host(host) and not (in_container_image() and _DNS_LABEL.match(host)):
            raise ValueError("host must be a loopback address")
        return v

    @model_validator(mode="after")
    def _output_within_half_context(self) -> RuntimeConfig:
        if self.output_tokens > self.context_tokens // 2:
            raise ValueError("output_tokens must be at most context_tokens / 2")
        return self


class RetrievalConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    lexical_candidates: int = Field(default=30, ge=1)
    semantic_candidates: int = Field(default=30, ge=1)
    evidence_chunks: int = Field(default=8, ge=1)
    fusion_constant: int = Field(default=60, ge=1)
    max_limit: int = Field(default=20, ge=1, le=100)
    max_per_document: int = Field(default=3, ge=1)
    excerpt_characters: int = Field(default=1200, ge=200, le=10_000)
    max_concurrent_searches: int = Field(default=4, ge=1, le=64)
    semantic_status_ttl_seconds: int = Field(default=30, ge=0, le=3600)

    @model_validator(mode="after")
    def _limit_covers_default(self) -> RetrievalConfig:
        if self.max_limit < self.evidence_chunks:
            raise ValueError("max_limit must be at least evidence_chunks")
        return self


class LimitsConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    question_characters: int = Field(default=4000, ge=1, le=100_000)
    history_characters: int = Field(default=12_000, ge=0, le=1_000_000)
    active_generations: Literal[1] = 1
    queued_generations: int = Field(default=4, ge=0, le=100)
    request_deadline_seconds: int = Field(default=120, ge=1, le=3600)


class PrivacyConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    persist_chats: Literal[False] = False
    log_message_bodies: bool = False
    telemetry: Literal[False] = False


class DiagnosticsConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    runtime_connect_timeout_seconds: float = Field(default=1.0, ge=0.1, le=10)
    runtime_read_timeout_seconds: float = Field(default=3.0, ge=0.1, le=30)
    readiness_cache_seconds: float = Field(default=2.0, ge=0, le=60)
    disk_margin_bytes: int = Field(default=2_147_483_648, ge=0)


class IndexConfig(BaseModel):
    """Chunking, embedding and retention settings (specs/003-snapshot-index/data-model.md)."""

    model_config = ConfigDict(extra="forbid")

    chunk_min_tokens: int = Field(default=350, ge=100)
    chunk_max_tokens: int = Field(default=700, ge=100)
    chunk_overlap_tokens: int = Field(default=75, ge=50, le=100)
    embedding_max_input_tokens: int = Field(default=1800, ge=300)
    embedding_batch_size: int = Field(default=32, ge=1, le=256)
    embedding_timeout_seconds: int = Field(default=120, ge=1, le=600)
    retention_count: int = Field(default=2, ge=2)

    @model_validator(mode="after")
    def _budgets_consistent(self) -> IndexConfig:
        if self.chunk_min_tokens > self.chunk_max_tokens:
            raise ValueError("chunk_min_tokens must not exceed chunk_max_tokens")
        # Leave room for the synthetic embedding prefix (research R3.10).
        if self.chunk_max_tokens > self.embedding_max_input_tokens - 200:
            raise ValueError("chunk_max_tokens must be at most embedding_max_input_tokens - 200")
        return self


class GenerationConfig(BaseModel):
    """Answer generation settings (specs/005-grounded-chat/data-model.md)."""

    model_config = ConfigDict(extra="forbid")

    temperature: float = Field(default=0.1, ge=0.0, le=1.0)
    history_turns: int = Field(default=10, ge=0, le=50)
    history_tokens: int = Field(default=1000, ge=100)
    evidence_tokens: int = Field(default=4500, ge=500)
    evidence_items: int = Field(default=8, ge=1, le=100)
    max_claims: int = Field(default=12, ge=1, le=50)
    max_claim_characters: int = Field(default=1200, ge=100, le=10_000)
    repair_attempts: int = Field(default=1, ge=0, le=1)
    fallback_excerpts: int = Field(default=3, ge=1, le=10)
    repair_min_seconds: float = Field(default=15.0, ge=0.0, le=600.0)


class ComparisonConfig(BaseModel):
    """Snapshot comparison settings (specs/007-version-comparison/data-model.md).

    Output length dominates generation time, so a comparison asks for shorter side answers and a
    short comparison step than chat does (F007 amendment, A-054); chat settings are unchanged.
    """

    model_config = ConfigDict(extra="forbid")

    deadline_seconds: int = Field(default=240, ge=1, le=7200)
    evidence_items_per_side: int = Field(default=5, ge=1, le=20)
    max_differences: int = Field(default=4, ge=1, le=30)
    # Short statements: a real run copied whole excerpts into statements and hit the output limit.
    max_statement_characters: int = Field(default=400, ge=80, le=2000)
    comparison_output_tokens: int = Field(default=600, ge=128, le=4096)
    # 4 claims × 500 characters ≈ 500 tokens + JSON: the token cap leaves a margin.
    side_max_claims: int = Field(default=4, ge=1, le=50)
    side_max_claim_characters: int = Field(default=500, ge=100, le=10_000)
    side_output_tokens: int = Field(default=700, ge=128, le=4096)
    # "always": repair any invalid comparison output once. "if_no_valid_difference": keep the
    # individually valid differences of a structurally valid first output without a repair (the
    # dropped ones are reported). Chosen by measurement (A-054).
    repair: Literal["always", "if_no_valid_difference"] = "if_no_valid_difference"


class BundleConfig(BaseModel):
    """Bundle import caps (spec clarification Q3)."""

    model_config = ConfigDict(extra="forbid")

    max_total_bytes: int = Field(default=2 * 1024**3, ge=1)
    max_entries: int = Field(default=10_000, ge=1)
    disk_margin_bytes: int = Field(default=1024**3, ge=0)


class DeploymentConfig(BaseModel):
    """Native (default) or container deployment (specs/009-portable-deployment research R3)."""

    model_config = ConfigDict(extra="forbid")

    mode: Literal["native", "container"] = "native"
    runtime_private_hosts: list[str] = Field(default_factory=list, max_length=4)

    @field_validator("runtime_private_hosts")
    @classmethod
    def _labels(cls, v: list[str]) -> list[str]:
        for name in v:
            if not _DNS_LABEL.match(name):
                raise ValueError(f"{name!r}: must be a single lowercase DNS label")
        return v


class RefreshConfig(BaseModel):
    """Upstream check and promotion gate for `refresh` (specs/015-scheduled-refresh)."""

    model_config = ConfigDict(extra="forbid")

    # Largest allowed fractional drop of documents, chunks or entities against the active snapshot.
    max_count_drop: float = Field(default=0.20, ge=0.0, lt=1.0)
    check_exports: bool = True


class LoggingConfig(BaseModel):
    """Optional rotating file log (OPS-001): body-free records, at most seven days kept."""

    model_config = ConfigDict(extra="forbid")

    file: Path | None = None
    retention_days: int = Field(default=7, ge=1, le=7)


class AppConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    schema_version: Literal[1] = 1
    profile: Literal["local"] = "local"
    server: ServerConfig = Field(default_factory=ServerConfig)
    data_dir: Path = Path("data")
    runtime: RuntimeConfig = Field(default_factory=RuntimeConfig)
    retrieval: RetrievalConfig = Field(default_factory=RetrievalConfig)
    limits: LimitsConfig = Field(default_factory=LimitsConfig)
    privacy: PrivacyConfig = Field(default_factory=PrivacyConfig)
    diagnostics: DiagnosticsConfig = Field(default_factory=DiagnosticsConfig)
    index: IndexConfig = Field(default_factory=IndexConfig)
    bundles: BundleConfig = Field(default_factory=BundleConfig)
    generation: GenerationConfig = Field(default_factory=GenerationConfig)
    comparison: ComparisonConfig = Field(default_factory=ComparisonConfig)
    deployment: DeploymentConfig = Field(default_factory=DeploymentConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    refresh: RefreshConfig = Field(default_factory=RefreshConfig)

    @model_validator(mode="after")
    def _container_exception(self) -> AppConfig:
        """The only way past the loopback rules: container mode, inside the application image."""
        container = self.deployment.mode == "container"
        if container and not in_container_image():
            raise ValueError(
                f"deployment.mode container requires the application image ({CONTAINER_MARKER}=1)"
            )
        if self.deployment.runtime_private_hosts and not container:
            raise ValueError("deployment.runtime_private_hosts requires deployment.mode container")
        if not is_loopback_host(self.server.host) and not container:
            raise ValueError("server.host 0.0.0.0 requires deployment.mode container")
        host = urlsplit(self.runtime.base_url).hostname or ""
        if not is_loopback_host(host) and host not in self.deployment.runtime_private_hosts:
            raise ValueError(
                f"runtime.base_url host {host!r} must be loopback or listed in "
                "deployment.runtime_private_hosts (container mode)"
            )
        return self

    def runtime_allowed_hosts(self) -> frozenset[str]:
        """Non-loopback runtime hosts the providers may contact (empty natively)."""
        if self.deployment.mode != "container":
            return frozenset()
        return frozenset(self.deployment.runtime_private_hosts)

    @model_validator(mode="after")
    def _evidence_items_within_search_limit(self) -> AppConfig:
        if self.generation.evidence_items > self.retrieval.max_limit:
            raise ValueError("generation.evidence_items must not exceed retrieval.max_limit")
        return self
