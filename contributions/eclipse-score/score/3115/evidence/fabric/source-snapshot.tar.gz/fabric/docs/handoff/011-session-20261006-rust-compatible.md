# Generic Rust workflow and communication #1265 — compatible run stopped

The user authorized a fresh supervised compatible-userspace recovery with `go`
on 2026-10-06. That recovery exhausted its three-fix budget. Native jobs and all
owned private Fabro servers stopped. Do not repair or relaunch under this budget.
Agent supervision and artifact verification do not supply engineering acceptance.

## Delivered work

The generic skill is installed at `.agents/skills/score-rust-workflow/`, linked
from `/home/jefferson/.codex/skills/score-rust-workflow`. It applies across S-CORE
Rust defects, APIs, unsafe/FFI, concurrency, platforms, dependencies and documentation.
Sealed authoring records remain in `specs/011-change-impact-and-freshness/rust-workflow/`.
Its manifest SHA-256 is
`89d006500fb6b2583f682a18c1cd801a98822801839f352e71a7af59cd5010f0`.
Earlier foundation/skill checks are authoring evidence; they are not new native
verification or acceptance. Existing user work and historical handoffs remain intact.

The issue patch assesses the existing pastey 0.2.3 dependency and its provenance,
licenses, alternatives, usage and qualification/adoption obligations. It changes
the Rust README and adds an assessment; production Rust, APIs, dependencies,
compiler pins, locks and native policies are unchanged.
Patch SHA-256:
`eb687c1a36b054315970fdbb2a4833cbb5e9470fb30eb06e67a446ca87951c19`.
Issue #1265 remains open. No PR publication, merge, deployment or accepted fix is claimed.

## Measured result

Native Rust run `01M484ZS5EGJ8E5KH83XXN7PCB` passed all three selected Bazel
targets: 9 concept cases, 8 macro unit cases and 16 doctest cases passed;
two doctest cases were ignored. The raw harness logs establish 33 passed cases.
Subsequent copyright-only runs carry those results through unchanged subject
hashes; they did not rerun Rust tests. Test XML wrappers do not enumerate all 33 cases.

Copyright-only run `01M485PT0BP1SNP9X142HKAJZH` failed on invalid Git paths.
Final run `01M4863C6JY8WNMY9T44H47XV8`, workflow version
`2eca92a572d50dc850930335de77ed159f93bf4cb8fa87f41aeb4d4949a283fe`,
passed preflight but failed verify/export and has failed lifecycle. Failure export
retained the measurements and returned failure. Native models are empty and
recorded native token usage is zero; this does not describe Codex session usage.

The final operator wrapper normalized exactly `//:BUILD` and `//:MODULE.bazel`
to their workspace-relative Git paths. NUL argument receipts confirm only those
two changes. Native checker source, configuration, templates and input scope
were retained. The unmodified target failures remain evidence.

The checker reported 96 missing headers, 107 format findings and one duplicate:
204 findings on 204 files whose bytes match the selected baseline. There are no
unknown finding paths or hash mismatches. Findings remain unreviewed; no agent
suppression, false-positive or acceptance decision is recorded. Native templates
exclude Markdown, so absence of either changed document is not a clean-check claim.
The authored Apache-2.0 SPDX marker was separately inspected as text.

## Exhausted corrections

1. Restore the exact ordinary archive modes of 13 runtime libraries after the
   direct loader preflight refused an omitted execute bit. Source bytes unchanged.
2. Initialize disposable empty-template Git metadata with hooks disabled, an unborn
   HEAD, no index and no commit. Two preparer refusals remain within that incomplete
   setup correction: ordinary empty object directories and a directory matched by
   a test-log glob. All raw refusals remain retained.
3. Apply the explicit two-label argument wrapper using native supported `--run_under`.
   The actual checker then reported the 204 findings. No fourth correction, broad
   copyright cleanup or further run occurred.

Supervisor `/root/rust_issue_supervisor` audited the terminal evidence, 73 bound
files, two Git metadata files, 2,879 candidate hashes, 13 runtime/host-library
hashes and modes, argument receipts, storage binding and three-fix accounting.
Its read-only review is exported, separately from authorized human review.

## Sealed contribution and storage

Current packet:
`/home/jefferson/eclipse_sdv_hackathon_2026/contributions/issues/eclipse-score/communication/1265/verification-recovery/score-fabric-7r64z_kz/`.
Its manifest seals **1,046 subjects**, SHA-256
`6357dce316bbf9e30bb23accd75fdb553a7a87130f040bc4108a815267c0c600`.
The contribution registry and inventory now select this packet. Original 175-
and previous 515-subject packets, nested historical manifests and refusal logs
remain byte-exact. The offline contribution verifier passed for all four issues;
other issue records and submission metadata were preserved. Integrity verification
does not rerun native checks or evaluate acceptance.

Scratch remains bound to
`/media/jefferson/11c42dee-73a3-4c2b-ab42-a0440011d9e0/.s-core-build/runs/score-fabric-7r64z_kz`.
Backing SSD UUID `002B-CE31`, registered ext4 image UUID
`11c42dee-73a3-4c2b-ab42-a0440011d9e0`, measured device 1793.
Use `score_sw_fabric.storage` to validate before any future access. Stop if
disconnected/remounted; never rewrite its guard or silently relocate the run.
Credentials and private server state remain internal. Reference repositories were
not used for builds; the native build used a disposable candidate.

The compatible userspace is a private bwrap namespace binding 13 exact Noble
libraries over read-only host paths, not full container CI. The Canonical image
archive SHA-256 is
`6fb36aacf06bfa77b8b624c63f07c04b85d76ad66d3bd3d9f101462537e770e3`.
Fresh signature verification passed; archive, checksum/signature inputs, 103
copyright/license notices and library bytes are exported. Original host-library
hashes remain unchanged. No global library installation occurred.

Operational deviation: one auxiliary non-build Bazel help query omitted a bound
output root and extracted an installation into its default cache. Its exact cache
delta was not measured. Native build outputs remained SSD-bound. No queues or global
tool-storage configuration were migrated; uncertain cache content was not deleted.
See the exported `execution/auxiliary-help-storage-deviation.json`.

## Pending review and freshness

Measurements apply to selected baseline
`e3d126c2d7569345cf5f790310702eb00cd86b06`. Observed upstream HEAD
`81a540e196421d7613350d77068e9a886eccbac6` is two commits ahead and changes
one C++/Rust FFI header. The documentation patch applies cleanly to the newer
unchanged README. Native verification of that newer baseline remains unperformed.
Compiler qualification, communication adoption, full CI, QNX and offline human
engineering acceptance remain pending. Do not check off human-owned review items.

Next action: offline engineering review of the assessment, native copyright
findings and qualification/freshness obligations. Any later technical recovery
needs explicit new scope and budget; the current three-fix run is stopped.
