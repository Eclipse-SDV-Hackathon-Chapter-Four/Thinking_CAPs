# Feature Specification: Change impact, freshness and bounded AI context

**Feature Branch**: `011-change-impact-and-freshness`
**Created**: 2026-10-03
**Status**: Specified for implementation; human acceptance pending.
**Input**: [Owner v3 brief](../../S_CORE_SW_FABRIC_TOKEN_OPTIMIZATION_SPEC_KIT_CODEX_BRIEF_v3_NO_JEV.md).
Current user instruction explicitly authorizes 011, superseding historical first-session stops.
Existing 012–018 numbers and FAB-001–064 source rows remain unchanged.

## User Scenarios & Testing

Negative-first contract and integration tests are required. Engineering acceptance remains
separate from implementation checks. No provider call is authorized by this feature.

### US1 — Contain machine evidence (P1)
An agent queries normalized findings rather than reading a minified SARIF line. Raw bytes remain
unchanged and checksum-bound. Generic raw reads and broad searches are denied at admission.
AC1: A synthetic single-line 1 MiB SARIF is refused by generic read/grep; bounded rule/file/location
queries preserve exact IDs, paths and lines, pagination and raw digest without raw messages.
AC2: Every tool result is bounded in UTF-8 bytes and conservative token estimate; aggregate
stage budgets persist across server restarts. Exhaustion/repeated queries stop, with guidance.
AC3: Collectors retain full evidence outside the model-facing feedback and supply a summary.

### US2 — Observe token/cost usage (P1)
An operator records provider/runtime usage per call/task/role/model/workflow/increment.
AC4: Missing cache/reasoning/cost fields stay null; inconsistent cache splits are rejected.
Estimates never become reported provider usage. Aggregation preserves unknowns.

### US3 — Compute transitive impact and freshness (P1)
An engineer supplies old/new native artifact indexes and explicit trace relations.
AC5: Removed and new relations, cycles, additions/removals and unknown dependencies remain
visible. Reverse reachability uses both baselines. Unknown/new unlinked dependencies widen
scope or block narrowed execution. Changed baseline vectors invalidate relevant evidence and
decisions without editing history; 005 remains authoritative for trust and human decisions.

### US4 — Classify engineering tasks (P1)
AC6: Reviewed policy inputs yield S0 metadata, S1 local implementation, S2 component feature,
S3 safety/architecture/interface or S4 broad investigation. Unresolved scope is unknown and
blocked, never silently S0. Reasons and policy digest accompany the class.

### US5 — Construct lazy context (P1)
AC7: A baseline-bound manifest derives primary/transitive paths and native IDs from impact and
explicit artifact mapping, preserves required constraints/output schemas and refuses drift.
L0 constraints and required L1 safety/content cannot be trimmed; optional L2 is omitted first.
Observation text is opt-in and retrieved by ID, with a current-first bounded metadata index.
Accounting separately covers L0, L1, observations, tools and Skills using a labelled conservative
UTF-8-byte upper estimate, not an invented provider tokenizer.

### US6 — Select procedural Skills (P2)
AC8: Eight narrow activity Skills have version/content digests, explicit inputs/output/prohibitions
and stop conditions. Selection is deterministic from an explicit reviewed activity mapping;
unknown/missing mappings block. Only selected bodies load; references load explicitly within
selected Skill trees. Modifying any declared Skill file invalidates selection. Runtime rendering
is explicit; Codex installation is never treated as native Fabro Skill support.

### US7 — Govern calls and conditional escalation (P2)
AC9: Class operational limits intersect role/model absolute ceilings and existing 007 admission.
Unknown usage, budget exhaustion, stale context, unconfigured/unknown catalogue models,
missing trigger and human gates refuse calls. S4 requires explicit scoped authorization.
Critic skips/triggers carry deterministic reasons; required human reviewers remain mandatory.
No new model identifier, price, provider grant or automatic premium fallback is invented.

### US8 — Package review and stage results (P2)
AC10: Review packs contain intent, invariants, changed paths, bounded diff summary, verification
summaries and raw evidence refs. Autonomous prompts demand structured stage results and no
execution narration; schema-required engineering rationale remains permitted. Stable instructions
precede dynamic content. Self-reported checks cannot become trusted evidence.

### US9 — Stop stalled work (P2)
AC11: Repeated query/failure, unchanged correction state, no measured reduction, exhausted visits
or budget, unknown usage and human gates have explicit stop reasons. Evidence refresh can
progress by changing evidence without claiming a code correction. Fabro owns loops/run state.

### US10 — Execute bounded modes (P2)
AC12: Full/delta/correction/verification-only/evidence-refresh produce derived execution plans
with the entire supplied mandatory collector/gate set preserved. Verification/refresh omit
implementation agents. No second scheduler or requirements database is introduced.

### US11 — Measure and audit (P1)
AC13: Retain baseline and optimized records for B1 metadata, B2 C++ correction, B3 unit tests,
B4 component feature and B5 safety/architecture. Test deterministic outcome equivalence,
required checks, trace IDs and evidence preservation. Offline context-byte/token estimates are
labelled separately from live uncached usage, cost and wall time. Live savings target is 60–80%
for routine/local changes; absent provider evidence remains unmeasured, never achieved by fixture.
AC14: A self-audit links requirements/tasks/code/tests/contracts/schemas/profiles/ADRs/roadmap
and acceptance. Human review and live operational qualification remain visibly unchecked.

## Functional Requirements

- **FR-001 / FAB-045**: Enforce raw evidence admission and bounded deterministic SARIF/JSON
  queries; retain native identities, unknown locations and raw digests (US1/AC1).
- **FR-002 / FAB-045**: Limit per-result bytes/tokens/results and aggregate stage context;
  persistent duplicate-query detection and explicit omission/stop records (US1/AC2).
- **FR-003 / FAB-045**: Collector summaries accompany complete host evidence; never overwrite
  historical attempts or copy full raw machine outputs into new agent feedback (US1/AC3).
- **FR-004 / FAB-045**: Extend telemetry with nullable cache/reasoning/cost, dimensions and
  unknown-preserving aggregates; verify usage splits (US2/AC4).
- **FR-005 / FAB-043**: Traverse old/new reverse dependencies and conservative unknown/new-link
  scope; invalidate changed baseline-bound evidence/decisions via derived reports (US3/AC5).
- **FR-006 / FAB-044**: Deterministically classify S0–S4 with explicit policy reasons; unknown
  scope blocks narrow context and routing (US4/AC6).
- **FR-007 / FAB-045**: Bind manifest to native index/impact/baseline/mapping digests; deterministic
  ordering and exact scope, fail on stale input (US5/AC7).
- **FR-008 / FAB-045**: L0/L1/L2 disclosure and bounded ID retrieval; never drop required safety,
  constraints or output contract; observations lazy by default (US5/AC7).
- **FR-009 / FAB-045**: Version/digest-bound bounded Skill registry, deterministic selection,
  progressive disclosure and explicit Codex/Fabro rendering (US6/AC8).
- **FR-010 / FAB-045**: Governor narrows existing admission, preserves absolute budgets,
  unknown-usage stop and explicit escalation/critic rules (US7/AC9).
- **FR-011 / FAB-045**: Structured completion and bounded review pack, stable prompt prefixes,
  no execution narration, preserve schema-required rationale (US8/AC10).
- **FR-012 / FAB-045**: Measured progress and bounded stops without a parallel execution engine
  or automatic human acceptance (US9/AC11).
- **FR-013 / FAB-044**: Five derived modes preserve mandatory collectors and offline human review obligations;
  verification/refresh require no implementation agent (US10/AC12).
- **FR-014 / FAB-045**: Five before/after benchmarks separate estimates/replays/live facts;
  equivalent deterministic outcomes and measurable savings target (US11/AC13).
- **FR-015 / FAB-045**: Self-audit and acceptance reconcile every requirement and open task
  across the existing authoritative repository artifacts (US11/AC14).
- **FR-016 / FAB-045**: Runtime admission denies unguarded generic/MCP bypasses. Only a bounded
  repository-owned tool service may deliver evidence/context for optimized stages. Hook/config
  support is source-checked; live activation qualification requires separately measured evidence.
- **FR-017 / FAB-045**: Preserve v1 request/output replay, public CLI commands, native IDs,
  licenses and trust boundaries; optional optimization uses new versioned request contracts.

## Success Criteria

- SC-001: Single-line structured-evidence reproduction exceeds 1 MiB; model-facing result <=
  12,000 UTF-8 bytes, per-result estimate <=5,000 and stage <=12,000; unchanged raw digest.
- SC-002: All adversarial tests pass, including stale baselines/Skills, unknown usage/dependencies,
  traversal/symlink escape, aggregate exhaustion and repeated-query refusal.
- SC-003: Offline representative context estimates reduce by >=60% on B1–B3 and retain all
  mandatory checks/IDs/evidence references; live uncached-token savings remain unmeasured
  until provider observations demonstrate the distinct 60–80% target.
- SC-004: Full relevant regression, Ruff/mypy, foundation and package build pass; all buildable
  requirements map to implementation/test/task artifacts. Human-owned tasks stay open.

## Edge Cases and Authority

Oversized fields are omitted explicitly rather than clipped into false rule/path identities.
Malformed/duplicate-key JSON, missing SARIF runs, unsafe URIs, stale raw artifacts, repeated
pagination, Unicode byte amplification and changed policy bindings refuse or preserve gaps.
Unknown dependencies never shrink obligations. Digest validity establishes byte identity only.
Reference repositories remain read-only. The initial local scope excludes live calls; the explicit US12 continuation below
adds only bounded Flash qualification. Publishing, merge and deployment remain excluded. New scratch uses the shared storage policy; active work stops on disconnection.

## US12 — Scoped native qualification continuation (2026-10-03)

The owner instructed `go` after the T032/T033 handoff, then selected `deepseek flash only`.
This authorizes preparing and executing a bounded disposable qualification experiment, including
Flash-only measurements; it does not ratify the constitution, accept engineering decisions,
change existing global profiles, migrate queues or authorize other providers/fallbacks.

- **FR-018 / FAB-045**: Bind experimental native activation to a host-private, immutable instruction
  file pinned by checksum outside the agent workspace. Restrict it to qualification, exact task,
  stage, current context/governor/role/Skill digests and DeepSeek Flash. Per-provider-request
  admission must bound the entire serialized input, output, total calls and conservative spending
  before transmission; refusal persists and prevents later requests/restarts. Keep observed usage
  and derived price bounds separate. No agent-created boolean or fixture receipt grants authority.
- AC15: Real native runs demonstrate the candidate stage guard blocks before provider transmission;
  source/tool/digest/stop failures are measured, with full native logs retained. The experimental
  positive path uses the same exact guard binding and denies generic tools.
- AC16: Up to ten Flash-only requests at a $0.10 technical ceiling measure B1–B5 paired task
  variants. Fresh provider documentation reconciles stale catalogue prices. Missing required token
  usage stops continuation; absent billed-cost/reasoning data stays null. Development-fixture
  measurements establish token observations only, not real S-CORE engineering readiness.

- AC17: An optional pinned `tool_projection.allowed_tools` selects only registered bounded
  tool names. Provider projection removes declarations already denied by the native guard,
  preserves every message and selected declaration, refuses explicit unavailable tool choices
  and retains both original and transmitted request hashes. Request admission also enforces
  accumulated per-task limits from the exact pinned governor. Native input remains subject to
  the full ceiling before projection. Replay does not assert new live savings.

### Second bounded comparison authorization

The owner's subsequent `go` approves the proposed additional ten-request Flash comparison,
with a separate $0.10 ceiling. Preserve the closed initial experiment and its request cap.
Use the exact original five paired prompts/expected outputs, selecting no provider tools
for both variants because these fixtures explicitly require no tools. Check projected
payloads, native stages, output equivalence and usage before each successor request.
Retain cache hits and total input separately from uncached input. This extension remains
qualification only; T032/T033 and real engineering acceptance remain open.

## US13 — Real issue cleanup and comparison preparation (2026-10-04)

After T032 approval and lifecycle #704 selection, the owner's `go` authorizes the
previously proposed next step: implement the configuration cleanup in a fresh disposable
workspace and prepare its guarded comparison. This continuation covers local implementation,
native checks and no-provider qualification preparation under FR-014/016/018; it does not
reuse either closed request ledger or authorize a new paid experiment. Flash-only remains
the provider constraint for a future separately bounded comparison. T033 stays open.

- AC18: Preserve parsed effective configurations for all three #704 consumers, including
  QM/ASIL-B, permissions, queue sizes, subscriber limits and instance specifiers. Share only
  verified repeated content; generated paths must preserve native unit-test/runfile/image use.
- AC19: Retain a portable patch, exact upstream/source/tool/storage pins, deterministic
  equivalence results, actual native-check outcomes and explicit unavailable prerequisites.
- AC20: Prepare equivalent real-task baseline/optimized inputs with mandatory checks,
  current context/Skill/governor bindings and guarded native conformance. No provider usage,
  savings or engineering acceptance is inferred from local checks or preparation.

## US14 — Fabro/Flash implementation qualification (2026-10-04)

The owner's latest `go`, responding to the explicit Fabro/DeepSeek execution next step,
authorizes a fresh qualification-only experiment for lifecycle #704. Flash produces code
from the pinned original source; the earlier Codex patch is preserved and excluded from
implementation prompts. Cap the experiment at four provider requests, $0.10 conservative
reservations, 24,000 serialized request bytes and 2,000 output tokens per request. No other
provider, automatic fallback, upstream write or engineering acceptance is authorized.
Use a fresh ledger, private native server and shared-storage workspace; retain stage/tool/
transport bindings and actual provider usage. Full native impact/applicability remains an
explicit engineering-acceptance gap, not fabricated by this development experiment.

- AC21: Native Fabro agent stages execute DeepSeek Flash against original #704 sources with
  exact source/Skill/output bindings; deterministic application admits only declared paths
  and operations. Preserve model-produced bytes separately from mechanical formatting.
- AC22: Run parsed-JSON/path equivalence and the affected native checks on the Flash-produced
  implementation. Retain all failures and any single bounded correction separately. Required
  S3 critique remains advisory; human acceptance and T033 qualification are not inferred.
- AC23: Retain native run/stage/hook records, original/transmitted requests, provider usage,
  conservative costs and budget stops. End at a human review gate, close the fresh ledger
  and stop only the experiment's servers. No token-savings comparison is inferred from code
  generation alone.

## US15 — Owner budget exception and JSON-mode retry (2026-10-04)

The owner's explicit temporary exception is recorded in deepseek-budget-exception.md.
The failed US14 experiment remains immutable; a fresh original-source workspace and
private instruction waive only this issue qualification's aggregate spending/call caps
and permit larger technical context/output ceilings. Flash remains the only provider.

- AC24: Default admission stays unchanged. Only a checksum-bound private instruction
  carrying the exact owner statement and #704 task scope admits the exception; scope,
  digest, run, source or tool drift remains denied. Counters and costs never reset.
- AC25: Native Fabro obtains strict JSON-mode code from Flash using original sources,
  applies only declared paths, runs all three JSON/package checks and affected native
  tests, and requests advisory critique before the human review gate. Preserve raw
  replies, formatting, every failure, actual usage and pending native-impact closure.

## US16 — Approved patch and local upstream contribution packet

The owner states “I approve go for the next step” after the exact US15 patch/advisory
handoff, then explicitly selects “Prepare the upstream PR packet locally (recommended)”.
Record that review decision against the immutable patch/evidence manifest. It accepts the
local #704 patch and evidence responses for contribution preparation; it does not establish
005 authenticated authority, upstream acceptance, native-impact closure or B1–B5 savings.

- AC26: Reverify the approved patch/191-file manifest and reviewed T032 subjects. Preserve
  historical evidence and human-owned task markers; record a separate dated owner decision.
- AC27: Recheck upstream baseline/issue/PR overlap, apply exactly the approved patch on a
  fresh shared-storage local branch after hook inspection, and fill the upstream improvement
  PR template. Retain original contribution/template/license sources, validation scope,
  exact command/path/hash bindings and publication prerequisites. No commit, remote write,
  paid call, new increment or engineering-gate answer is implied by this local-only choice.

## US17 — Real-target benchmark preparation

The owner's `go` follows the recommendation to prepare T033's real-target benchmark
plan while deferring PR publication. This authorizes local planning and deterministic
integrity/consistency checks. It does not launch new provider trials or increment 012.

- AC28: Define matched baseline/optimized arms with identical native task/source,
  model/settings, tools, required checks and human gates. Use #704 as an additional
  configuration/build pilot; preserve B1–B5 category definitions and unselected targets.
  Bind planning sources and specify independent semantic oracles, complete-arm token,
  cache/cost/time accounting, failed-trial handling and future admission prerequisites.
- AC29: Record null unmeasured live results and explicit native expected-set/impact
  gaps, preserve reviewed subjects and historical measurements, and reconcile current
  spec/plan/tasks/coverage/acceptance with actual no-provider preparation checks.
  No old ledger, budget exception, pending gate or fixture result becomes live acceptance.

## US18 — Paired P704 packages without provider calls

The owner's next `go` authorizes preparation of the two #704 source/context/Fabro
packages and deterministic equivalence/conformance checks. Publication stays deferred;
no paid trial or native engineering-gate answer is implied.

- AC30: Create fresh storage-bound original-source copies and pin the actual dirty fabric
  worktree used for preparation. Exclude earlier implementations/model replies from agent
  inputs. Bind both contexts to identical task intent, source IDs, allowed paths/tools,
  model/settings, output schema, collector expectations and human review obligations.
- AC31: Prepare native-valid matched graphs and refused stage-admission records. Prove
  equal check/tool/edge/gate obligations; measure bounded source access and worker-source
  initialization locally. Retain source-drift, forbidden-tool and no-instruction refusals.
  Distinguish a local initialization probe from a live native worker binding and graph
  syntax conformance from verified provider/result/collector execution wiring.
- AC32: Preserve approved packets/subjects and prior planning records. Record actual
  context byte estimates separately from null live tokens/cost/time, explicit native
  expected-set/admission/collector gaps, and scoped validation/reconciliation results.

### US19: Protected paired runtime bindings (local execution)

The owner's `go` authorizes implementation and local tests of worker initialization,
structured result application and fresh deterministic collectors. This continuation
adds no provider instruction, publishing authority or engineering acceptance.

- AC33: Bind each worker to an exact run/arm/cwd, full original source manifest and
  archive; refuse cross-arm use, source drift, unsafe archives and reused initialization.
- AC34: Apply only a pinned completed stage response with matching context/native IDs
  and exact candidate scope. Retain raw response and source receipts; refuse replay,
  unbound corrections, malformed output and source mutation outside the write set.
- AC35: Collect new command/XML/configuration/runfile/package evidence in a fresh
  disposable copy bound to the applied candidate. Separate failed/skipped/missing
  results and keep protected local provenance distinct from native engineering trust.
- AC36: Test the bindings without provider calls, preserve reviewed subjects, validate
  the wired graph packages and retain remaining admission/transport unknowns.

## US20 — provider-disabled native API binding qualification

The owner's current `go` authorizes a fresh private Fabro API smoke test and necessary
local fixes, without provider requests or engineering decisions.

- AC37: Pin the native executable/source and frozen fabric implementation; use a new
  bound disposable workspace and internal private server. Exercise exact API run/worker
  identity and original-source initialization; retain refusals and native metadata.
- AC38: Run protected local replay/application and fresh lightweight collectors through
  native command nodes. Verify routing of bound feedback and missing-check/provider
  refusals to an unanswered human gate; distinguish smoke checks from target verification.
- AC39: Retain raw API/stage/command evidence and zero provider requests; cancel owned
  waiting runs and stop only the new server, preserving prior packets and human markers.

## US21 — offline human review outside Fabro execution

The owner directs human decisions to occur offline after complete reports are exported.
This supersedes in-workflow human-node placement in earlier planning and US20 evidence;
review obligations, deterministic admission/refusals and native acceptance remain intact.

- AC40: Current workflows contain no human/wait-for-approval nodes. Every bounded
  completion or refusal path exports available reports and reaches an exit without
  asking a reviewer to unblock Fabro. Missing or failed checks remain explicit.
- AC41: Bind offline reports to run, arm, source/candidate/check/feedback records and
  immutable hashes; provide source changes, commands, raw outcomes, usage, unresolved
  scope and review questions. Workflow completion means report completion only.
- AC42: Exercise both revised graphs through the provider-disabled private API; retain
  terminal projections and reports, verify zero provider requests, stop owned state,
  reconcile controls and preserve human acceptance markers and historical packets.

## US22 — measured P704 native scope review

The owner's `go` authorizes offline review and deterministic source/build/process
impact tracing for the pinned P704 baseline and approved local replay. No human
acceptance, paid model instruction or publication is implied.

- AC43: Reverify prior reports/subject hashes and derive old/new source, label and
  reverse build-dependency scope in fresh storage-bound copies. Preserve added/deleted
  dependencies, query failures and raw source/tool provenance.
- AC44: Trace native declarations/verification/process and CI/platform evidence into
  a proposed expected-check matrix. Distinguish measured build-graph coverage from
  native validated export/applicability and unavailable QNX or tailoring evidence.
- AC45: Retain an offline review report, deterministic results, unresolved decisions
  and exact check statuses; reconcile feature controls and preserve historical
  packets, reviewed source bytes and pending human markers.

## US23 — local provider response and usage capture

The owner's `go` authorizes synthetic loopback transport/capture qualification and
necessary local binding fixes. No live provider request or native engineering
admission is supplied by fixture instructions or successful local execution.

- AC46: Bind an observed meter ticket to the exact retained response bytes and
  configured stage/instruction/task/meter. Refuse changed content with unchanged
  usage, substituted sources, missing response bindings and stale/stopped meters.
- AC47: Exercise real loopback HTTP with completed JSON/SSE synthetic envelopes,
  structured capture/application, usage and reasoning accounting, replay, missing
  usage and truncation refusals. Keep actual bills null and reservations for unknown
  outcomes. Local fixture counts cannot become live DeepSeek or native verification.
- AC48: Retain raw local requests/responses, exact sources, initial/final regression
  results and closed owned endpoints in an offline packet. Preserve historical
  packets and human markers; report actual agent transmission and live behavior
  as unresolved where not exercised.

## US24 — actual native agent consumption with synthetic responses

The owner's `go` authorizes a fresh private pinned Fabro API probe against a loopback
emulator. Only synthetic keys/replies and private fixture instructions are supplied;
no paid execution, native engineering admission or publishing is authorized.

- AC49: Freeze fabric/native transport and prompt sources, bind actual API run/arm/cwd
  identities and original source, and route every agent request through scoped meters
  to a loopback-only emulator. Retain actual requests, responses and stage/hook evidence.
- AC50: Exercise baseline/optimized agent response consumption, byte-bound candidate
  capture, fresh failed/missing checks and feedback in the next actual agent request.
  Verify exact feedback/candidate/source bindings and native output/usage projection.
  Exercise an unknown-usage refusal without uncontrolled continuation or source writes.
- AC51: Export complete offline reports and terminal refusal/completion evidence,
  verify zero paid requests/human visits, stop owned runs/server/endpoints and preserve
  prior packets/human markers. Synthetic token/cost observations cannot become live
  behavior, new model generation, native verification or accepted engineering scope.

## US25 — native bounded correction and operator recovery refusal

The owner's `go` authorizes synthetic local qualification of actual native correction,
replay and restarted-operator behavior. This does not start a paid trial or supply
engineering acceptance. Native checkpoint resume remains a separate unsupported gap.

- AC52: Freeze source/operator/transport bindings and create fresh native workers.
  Apply a synthetic injected service-ID mismatch, collect new failed checks, transmit
  their exact bound feedback to one actual correction agent and apply its observed
  byte-bound response. Collect again; distinguish corrected local oracle from missing
  native XML and pending engineering acceptance.
- AC53: Refuse native correction application without prior failed checks. After the
  bounded correction, launch new operator processes under native command execution
  and refuse duplicate capture/application/collection without source or state drift.
  Persist an explicitly injected interrupted-transaction marker in an exiting child;
  a restarted operator must refuse mutation. Do not label this native checkpoint resume.
- AC54: Retain all native requests/replies/stages, synthetic fault/oracle, both source
  candidates, fresh feedback/checks and refusal/crash provenance. Export offline reports,
  terminate without human nodes, close only owned state, verify zero paid calls and
  preserve prior packets, reviewed bytes and human-owned markers.

## US26 — fresh P704 admission preparation

The owner's `go` authorizes refreshed upstream/provider inputs, bound offline native
scope choices and matched prompt preparation. Earlier approval/budget exception stays
recorded; this work supplies neither missing engineering decisions nor a live instruction.

- AC55: Refresh public issue/main/PR activity and official provider contracts; bind the
  complete proposed CI/check inventory and QNX declaration to prior measured failures.
  Preserve native identities/statuses and distinguish discovery from execution.
- AC56: Prepare equal original-source arm obligations and rendering. Measure complete
  reconstructed request bytes including the retained native wrapper, retain initial
  oversized attempts, and qualify documented SSE usage shape locally without paid calls.
  Keep actual native payload observation, usage, bills and trial savings distinct.
- AC57: Export concrete offline scope alternatives and an unfilled native-owner decision
  record with refused governors. Preserve reviewed subjects/human markers and run current
  repository/trace checks; leave execution refused until missing inputs are bound.

## US27 — actual native payload and pinned parameter qualification

The owner's `go` authorizes no-provider actual payload preflight and the scoped fix
for settings gaps it measures. Human engineering decisions stay offline/unfilled.

- AC58: Execute exact prepared implementation prompts in actual private pinned Fabro
  workflows against a loopback refusal endpoint. Retain raw bodies, stage identities,
  wrapper differences and projected sizes; report/exit without human nodes or upstream.
- AC59: Close measured native thinking/JSON setting gaps through an explicit optional
  pinned Flash profile. Preserve old instructions, messages, limits and admission.
  Refuse partial/expanded controls, wrong provider/model, stale pins and added-byte
  context overruns; qualify actual local HTTP JSON/SSE wire and meter bindings.
- AC60: Export full offline findings, exact pre/post code and current source bindings,
  fresh regression/static/package/trace checks and closed owned state. Preserve prior
  packets and human markers; keep full-stage envelopes and native scope decisions pending.

## US28 — bound dynamic stage envelopes and native size refusals

The owner's `go` authorizes full-input correction/review envelope binding and actual
no-provider measurement. Historical fixture inputs cannot supply current trial evidence.

- AC61: Bind correction/review to exact candidate, complete source inventory, fresh-check
  provenance and feedback in each historical qualification arm. Keep all original and
  candidate content, deleted paths, native identities/statuses and equal obligations.
  Refuse tampering, resealed evidence substitutions and correction without failed checks.
- AC62: Validate and run actual native correction/review capture graphs against a local
  refusal endpoint; retain exact prompts/raw bodies, explicit profile projection and
  whole payload sizes. Oversize stages export refusals/reports and exit without human
  nodes, upstream, candidate application or silently relaxed limits.
- AC63: Export bound offline findings, complete inputs/refusals and closed owned state;
  preserve historical packets/source/reviewed subjects, reconcile controls/package/trace
  checks and keep bounded retrieval, real stage admission and native engineering inputs
  explicit when full-input envelopes do not fit.

## US29 — bound source retrieval through native MCP

The owner's `go` authorizes bounded retrieval implementation and local native
qualification. Historical candidate snapshots remain fixtures; human scope decisions
stay offline and no paid execution or publication follows from this qualification.

- AC64: Pin a correction/review retrieval manifest to exact original/candidate files,
  source inventory, checks and feedback. Revalidate all references on each query;
  expose only source excerpts, retain digest/stage bindings and persist drift,
  scope, duplicate, per-result and aggregate-budget refusals across restart.
- AC65: Register the actual bounded stdio tool in pinned native Fabro. Deliver selected
  candidate/original excerpts into subsequent real native agent requests against a
  loopback-only synthetic endpoint. Meter complete requests, wrapper/tool overhead,
  usage and whole-stage budgets; retain context or output refusals without relaxing
  guards or claiming fixture retrieval proves full correction or live readiness.
- AC66: Export complete prompts, manifest/source/tool bindings, requests/replies,
  native stage reports and fresh regression/static/package/trace checks. Close owned
  state, preserve historical packets and human markers, and distinguish technical
  retrieval from missing native expected-set, roles, QNX and engineering decisions.

## US30 — complete bounded correction and fresh feedback

The owner's `go` authorizes local native qualification of complete bounded correction
output, application, collection and advisory review. Replies remain synthetic; no paid
call, full native verification or engineering acceptance follows.

- AC67: Resolve multi-response capture by verifying every observed provider byte/usage
  pin, completed bounded tool call and exact next-request conversation/result chain.
  Apply only the final complete candidate; refuse ambiguity, truncation, forbidden
  tools, result substitution, missing/stale source manifests and unknown usage.
- AC68: Execute matched actual native workflows using fresh original-source workers,
  injected fixture failure, bounded correction retrieval, complete candidate output,
  source application and new protected checks/feedback. Transmit exact new feedback
  to bounded advisory review; retain failed/missing native obligations and stop a
  truncated final result before candidate mutation. Keep all guards and human decisions
  offline, and distinguish synthetic token counts from measured live output feasibility.
- AC69: Export complete source/candidate/check/feedback/request/reply/runtime reports,
  fresh regression/static/package/trace checks and closed owned state. Preserve prior
  reviewed packets and human markers; report remaining real/native readiness inputs.


## US31 — offline native admission evidence review

The owner's `go` authorizes reviewing the native scope, QNX and reviewer inputs and
preparing concrete offline choices. It supplies no missing person's identity or native
applicability decision. Human decisions remain outside workflow execution.

- AC70: Bind current correction qualification and the proposed native check inventory;
  verify all CI/profile/label identities and the cited ID/status against genuine native
  exports. Distinguish source-backed existence, discovery, historical execution and
  unresolved source-to-Need/work-product applicability.
- AC71: Produce concrete complete-native versus bounded-experiment scope choices,
  exact pilot/deferral references, QNX checksum/access prerequisites and proposed review
  responsibilities. Probe only known local dependency metadata without credential
  disclosure, downloads or SDK execution. Leave unavailable human/role/scope facts
  explicit and distinguish a drafting preference from an accepted decision.
- AC72: Export bound offline decision subjects, review findings and validation; preserve
  historical packets, accepted T032 subjects, human markers and all production/test
  source bytes. Carry existing tests only by unchanged hashes; run current foundation,
  package and trace checks. Keep real instructions/execution refused until inputs bind.


## US32 — Linux dependency loading with QNX execution skipped

The owner's `go` authorizes measuring pinned Linux loading in disposable, storage-bound
copies. No QNX license is available: skip QNX downloads/execution, retain platform
qualification as incomplete, and keep engineering review offline.

- AC73: Preserve seventeen historical packets and reviewed/source subjects; verify the
  exact original archive, inspect hooks/configuration and pin native tool/options.
- AC74: Measure Linux package/analysis dependency loading with QNX network/execution
  excluded. Retain full commands, source/dependency hashes, outcomes and refusals.
  Distinguish cache availability, loading and analysis from compilation/tests or
  accepted scope; do not replace an SDK, relax its digest or silently alter native files.
- AC75: Export bound results, limitations and a concrete next step; close owned tools,
  preserve prior subjects and reconcile controls/frozen/package/trace checks.
  Carry unchanged production tests by source hashes without asserting native acceptance.


## US33 — Public Python metadata and isolated Linux retry

The owner's `go` authorizes preparing the missing public Python index metadata and
retrying pinned Linux loading with QNX downloads/credentials denied. Native source
and lockfiles remain unchanged; native human decisions stay offline.

- AC76: Preserve eighteen prior packets, reviewed/source subjects and native pins;
  fetch only bounded public PyPI index responses with exact URL, status, bytes and
  digest provenance. Validate source/tool/options and deny credential-bearing redirects.
- AC77: Feed real captured metadata through a bounded loopback mirror in an isolated
  native probe; prove QNX and unlisted downloads refuse. Retain exact source/cache/
  mirror/request bindings, outcomes, misses and bounded retries. Do not fabricate
  packages, replace SDKs, change native source/locks or reinterpret native applicability.
- AC78: Export complete offline results and close owned endpoints/processes; verify
  immutable subjects and reconcile controls/frozen/package/trace checks. Distinguish
  successful metadata preparation from native load/analysis/build/test acceptance.

## US34 — Pinned Linux analysis with the complete captured metadata input

The owner's `go` authorizes the prepared 68-package mirror retry and bounded local
diagnosis. QNX remains skipped without a license; all engineering decisions stay offline.

- AC79: Preserve nineteen historical packets and source/reviewed subjects; prepare a
  fresh storage-bound original source copy, exact native tool and writable cache containing
  only registry files bound to the unchanged original lock. Bind all 68 metadata pages.
- AC80: Measure pinned Linux loading/analysis with external networking and QNX denied;
  retain exact commands, input/cache identities, mirror requests and remaining failures.
  Stop repeated unchanged failures and the declared attempt budget; no SDK substitution,
  native source/lock edits, compilation/tests or inferred native scope acceptance.
- AC81: Export bound offline findings, close owned native processes and mirrors,
  preserve historical subjects, and reconcile controls/frozen/package/trace checks.
  Carry unchanged source-bound tests separately from current native measurements.

## US35 — Exact public module preparation and bounded Linux analysis

The owner's `go` authorizes obtaining the missing pinned public module archive/patch
and continuing isolated native analysis. QNX downloads/execution remain skipped.

- AC82: Preserve twenty historical packets and source/reviewed subjects; bind a fresh
  storage workspace, exact source/tool, captured metadata and original registry hashes.
  Acquire only exact declared public module inputs with bounded HTTP provenance,
  credential-free redirects and native integrity checks; refuse mismatched bytes.
- AC83: Feed verified public archive/patch bytes through exact filename-preserving
  loopback routes into pinned isolated Linux analysis. Retain download/cache/extraction
  distinctions, raw results and remaining dependencies; stop the declared bounds and
  repeated unchanged failures. No SDK substitutions or native source/lock modifications.
- AC84: Export complete offline evidence, verify process/mirror closure and subject
  preservation, and reconcile current controls/frozen/package/trace checks. Distinguish
  public input integrity from native analysis/build/test and engineering acceptance.

## US36 — Source-bound Bats dependencies and configured Linux retry

The owner's `go` authorizes preparing the exact Bats core/helper source archives and
retrying configured Linux analysis. QNX execution and downloads remain skipped.

- AC85: Preserve twenty-one historical packets and source/reviewed subjects; bind
  original source/tool, inherited public inputs and genuine Bats declarations through
  native lock/archive hashes. Prepare only bounded exact public source bytes with
  HTTP/cache provenance and integrity checks; refuse SDKs and credential-bearing redirects.
  Cached release-checksum metadata explicitly pinned by the original native lock may
  identify remaining binary dependencies; those binaries stay outside this source stage.
- AC86: Exercise exact verified Bats/source-module routes in isolated pinned Linux
  analysis; retain commands, per-probe inputs, delivery/materialization distinctions,
  failed/missing dependencies and bounded stops. Preserve source/lockfiles and QNX denial.
- AC87: Export complete offline reports and process closure; verify immutable subjects
  and reconcile controls/frozen/package/trace checks. Keep package loading, configured
  analysis, native build/tests and pending engineering decisions separate.

## US37 — Cached Linux Buf tools and configured analysis

The owner's `go` authorizes cache-only use of the three pinned Linux Buf tools and
bounded configured analysis. QNX stays skipped; engineering decisions remain offline.

- AC88: Preserve twenty-two historical packets and reviewed/source subjects; bind a
  fresh storage workspace, original source/tool and inherited inputs. Import only
  original-lock/checksum-bound cached Linux Buf bytes within explicit size limits.
  Preserve native source/locks/licenses; do not fetch remote binaries or SDKs.
- AC89: Measure isolated configured Linux analysis with per-probe input/command/
  operator bindings. Keep transport, materialization and execution distinct; retain
  failures and missing dependencies, and stop bounded unchanged retries.
- AC90: Export complete offline reports, verify process/mirror closure and preserved
  subjects, reconcile controls and repository checks without engineering acceptance.

## US38 — Exact Linux Ferrocene preparation and configured analysis

The owner's resume instruction continues the handoff's exact pinned Linux compiler
preparation. The owner confirms the build image should be 1 TiB and authorizes mounting
it. Use a fresh binding after remount; preserve failed old-device guards and all old
records. No QNX, paid calls, native compilation/tests or engineering acceptance follows.

- AC91: Preserve twenty-three sealed packets, current source/test and T032 subjects;
  bind a fresh storage workspace and verified read-only historical inputs. Measure
  exact release/checksum/source provenance and archive sizes before acquisition,
  record separate finite bounds and preserve payload license/notice bytes.
- AC92: Acquire only the three original-lock-bound x86_64-unknown-linux-gnu Ferrocene,
  coverage-tools and Miri archives with exact hashes. Measure isolated configured
  Linux analysis, input/operator/source bindings, delivery/materialization failures
  and bounded stops without changing native sources or locks.
- AC93: Export a complete offline report, preservation and owned process closure;
  reconcile controls, coverage and required repository checks. Carry unchanged
  source-bound prior tests explicitly; preserve human-owned markers and unresolved
  native/live qualification.

## US39 — Exact Linux Coreutils input and configured analysis

The owner's `go` continues exact Linux Coreutils 0.1.0 preparation from the sealed
US38 handoff. Use a fresh storage-bound source/cache copy; preserve native sources,
locks, all sealed packets and human markers. QNX and paid execution remain excluded.

- AC94: Verify twenty-four historical packets and current/reviewed subjects; bind
  a fresh volume, original source/tool/runtime and inherited inputs. Measure the
  exact original-lock/wrapper-bound Coreutils release/cache/source/size provenance
  and declare separate finite acquisition/analysis bounds before acquiring bytes.
- AC95: Acquire only the selected x86_64-unknown-linux-musl Coreutils 0.1.0 archive
  against its native SHA-256; retain archive inventory/notices and distinguish source
  notices from payload notices. Measure isolated configured Linux analysis and
  exact transport/materialization/failure results without native build/test or
  source/lock edits; stop bounded repeated or out-of-scope dependencies.
- AC96: Export complete offline findings, source/operator/input hashes, immutable
  preservation and owned process closure; reconcile controls/coverage and required
  checks. Carry unchanged source-bound prior tests explicitly, leaving human
  acceptance, full native expected scope and live qualification pending.

## US40 — Exact Linux GCC package and configured analysis

The owner's `go` continues the sealed US39 GCC prerequisite. Bind a fresh writable
SSD workspace and preserve original source/locks, sealed packets and human markers.

- AC97: Verify twenty-five sealed packets and current/reviewed subjects, bind fresh
  storage/source/tool/runtime and inherited inputs; refresh original-lock-bound GCC
  release/source/size/digest provenance and declare finite acquisition limits.
- AC98: Acquire only the exact Linux GCC 12.2.0 release v0.0.4 archive against its
  original lock hash, preserve actual inventory/notices, and separately measure an
  admitted-repository query and configured Linux analysis. Retain exact input/operator
  bindings and bounded missing-input stops without compiler execution or source edits.
- AC99: Export complete offline findings, verify preservation and process closure,
  reconcile controls/coverage/frozen/package/trace checks and carry unchanged source
  tests explicitly. Keep human acceptance and broader native/live qualification pending.

## US41 — Exact Linux jq binary and configured analysis

The owner's `go` continues the sealed US40 jq prerequisite in a fresh SSD workspace.

- AC100: Preserve twenty-six packets and all source/reviewed subjects; bind fresh
  storage/source/tool/runtime and inherited inputs, refresh exact jq release/native
  checksum/source-license provenance and declare finite standalone-binary limits.
- AC101: Acquire only native-bound Linux jq 1.7, verify original SHA-384 integrity,
  separately measure SHA-256, retain ELF/static notice findings and source licenses,
  then measure independent repository loading and configured analysis with exact
  input/operator snapshots and bounded failure stops. Do not execute jq or build/test.
- AC102: Export complete offline findings, preservation and process closure, reconcile
  controls/coverage/frozen/package/trace checks and carry unchanged source tests.
  Keep human markers and broader native/live scope/qualification acceptance pending.

## US42 — Exact Linux BSD tar binary and configured analysis

The owner's `go` continues the sealed US41 BSD tar prerequisite in a fresh SSD workspace.

- AC103: Preserve twenty-seven packets and source/reviewed subjects, bind fresh storage,
  source/tool/runtime and inherited inputs, refresh native checksum/release/source-license
  provenance with historical/canonical URLs distinct, and declare finite binary limits.
- AC104: Acquire only native-bound Linux BSD tar v3.8.1-fix.1 against original SHA-256,
  retain standalone ELF/static notice/source-license findings, then measure independent
  repository loading and configured analysis with exact operator/input snapshots and
  bounded stops. Do not execute the payload, compile/test or alter sources/locks.
- AC105: Export complete offline findings, preservation/process closure and current
  controls/coverage/frozen/package/trace checks with unchanged source-bound prior tests.
  Preserve human markers and pending broader native/live/qualification acceptance.

## US43 — Exact Linux zstd binary and configured analysis

The owner's `go` continues the sealed US42 zstd prerequisite in a fresh SSD workspace.

- AC106: Preserve twenty-eight packets and source/reviewed subjects, bind fresh storage,
  source/tool/runtime and inherited inputs, refresh native checksum/release/source-license
  provenance with historical/canonical URLs distinct, and declare finite binary limits.
- AC107: Acquire only native-bound Linux zstd v1.5.6-bcr1 against original SHA-256,
  retain standalone ELF/static notice/source-license findings, then measure independent
  repository loading and configured analysis with exact operator/input snapshots and
  bounded stops. Do not execute the payload, compile/test or alter sources/locks.
- AC108: Export complete offline findings, preservation/process closure and current
  controls/coverage/frozen/package/trace checks with unchanged source-bound prior tests.
  Preserve human markers and pending broader native/live/qualification acceptance.

## US44 — Exact Debian Linux OCI input and configured analysis

The owner's `go` continues the sealed US43 original-pinned Debian OCI prerequisite.

- AC109: Preserve twenty-nine packets and exact source/reviewed subjects; bind a fresh
  SSD workspace and inherited inputs, verify original OCI wrapper/lock/source/license
  authority, and measure digest-bound platform/config/layer closure before acquisition.
  Keep anonymous registry bearer tokens in memory only with finite metadata limits.
- AC110: Prepare only original image-pin-selected linux/amd64 OCI objects with exact
  descriptor/content/config diff-ID integrity and bounded layer inventory/license
  retention. Measure independent exact repository loading and original configured
  Linux analysis with source-supported anonymous cache/mirror fallback, explicit input/
  operator bindings and bounded failure stops. Never execute an image/container, alter
  native source/locks, build/test, read private credentials/configuration or access QNX.
- AC111: Export complete offline findings and unknowns, verify preservation/process
  closure, reconcile controls/coverage/frozen/package/trace checks and carry unchanged
  source-bound prior tests. Preserve human markers and native/live qualification gaps.

## Current autonomous 011 authority — 2026-10-05

The owner authorizes remaining reversible dependency discovery/preparation, public
source/tool acquisition, fabric fixes, scoped Linux analysis/builds/tests, necessary
disposable test containers, validation/convergence, benchmark preparation and complete
offline reports. Historical stage stops end their bounded probes; a successor gets
fresh finite limits and continues without renewed permission. Preserve native exact
source/locks, warning/test policy, failed/missing evidence, reviewed subjects, sealed
packets and all five existing pilot checks. QNX remains skipped for lack of a license.
No new paid provider request is granted; historical budgets remain closed. T032's
recorded approval is preserved; native engineering and real B1–B5/T033 acceptance
remain offline and pending. This continuation adds no increment, scheduler, publishing,
push, merge, release, deployment, global storage change or synthetic human decision.
When exposed context falls below 20%, stop starting work, close owned operations,
save a verified Markdown/JSON handoff and complete continuation prompt, and conditionally
pause the Goal. Without a percentage meter, state the limitation and checkpoint
conservatively on an explicit low-context warning.

The current native checkpoint establishes equal 94-target structural closures only
within its declared source universe and accounts for three added Starlark loadfiles.
Full closure and engineering applicability remain unresolved because QNX is skipped.
The compatible-runtime checkpoint now executes exact original Ferrocene/LLVM coverage
inside an isolated, checksum-bound Ubuntu runtime library namespace. B2 has an actual
getter/setter allocation witness; B3 has a held-out handler test and a wrong-status
mutation witness. These prepare independent oracles without completing paired trials,
full native applicability or engineering acceptance. The subsequent original and approved candidate native documentation exports pass
with exact original tools and unchanged native values, as recorded in the
[bound export report](evidence/t033-aspect-export/review-report.md). Complete accepted
expected sets and Sphinx-Needs 8.5.0 catalogue compatibility remain unresolved; no
native compiler/policy substitution or inferred acceptance is authorized.

## Producer contract and extended B3 evidence

[Bound report](evidence/t033-producer-contract/review-report.md) measures the actual
docs-as-code8.3.0 / Sphinx-Needs8.5.0 pair against the existing8.2.0/8.3.1 baseline.
Native archive and metamodel bytes are verified; the schema is unchanged but relation,
type and option definitions change. An [explicit profile proposal](evidence/t033-producer-contract/architecture-draft.md)
preserves v1/default/source locks and remains proposed, unimplemented and unaccepted.
Complete immutable consumer source/namespace bindings and real conformance remain open.
Eight original-plus-extended B3 cases pass; summary132/182 lines,39/56 branches,10/12
functions. A wrong-rejection-reason mutant fails exactly one new case; seven pass.
Controlled graph peers do not qualify RPC transport, production graph behavior or full
issue685 coverage. A demonstrated capture gap causes one finite evidence refresh;
raw ZIP/text-format error and corrected capture remain explicit. Existing witnesses
are preserved; no provider requests or human decisions are made.
