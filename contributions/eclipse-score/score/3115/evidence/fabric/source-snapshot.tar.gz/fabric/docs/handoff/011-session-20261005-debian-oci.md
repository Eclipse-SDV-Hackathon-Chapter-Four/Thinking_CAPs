# Increment 011 Debian OCI handoff — 2026-10-05

US44 / AC109–111 / T151–153 is complete and sealed. The mission remains incomplete.
Next action: measure and prepare the exact original-lock-bound score_cpp_policies 0.1.1
source archive/cache/source-license/size provenance under fresh finite bounds, then retry
original configured Linux analysis. Preserve source/locks, warning policy and all five
scoped targets. This handoff starts no background continuation or live provider experiment.

Read [AGENTS.md](../../AGENTS.md), [constitution](../../.specify/memory/constitution.md),
[original handoff](000-to-001.md), [previous zstd handoff](011-session-20261005-zstd.md),
active [spec](../../specs/011-change-impact-and-freshness/spec.md),
[plan](../../specs/011-change-impact-and-freshness/plan.md),
[tasks](../../specs/011-change-impact-and-freshness/tasks.md),
[acceptance](../../specs/011-change-impact-and-freshness/acceptance.md) and
[complete sealed report](../../specs/011-change-impact-and-freshness/evidence/t033-debian-oci/review-report.md).
Preserve all dirty user work, original brief, native source/locks, old handoffs, sealed
packets and exact reviewed T032/lifecycle #704 subjects. Human markers stay unchecked.

## Measured OCI result

Packet: `specs/011-change-impact-and-freshness/evidence/t033-debian-oci`.
Manifest SHA-256 `9fc07a5a00a55ee08410e6f8e55f2549c6ff6c45f86b0352667042af9662f432` seals **200 files**. Large exact objects
remain on their bound SSD paths with hash/size references.

Fresh cache inspection finds all four original-pin-selected objects in the historical
native workspace cache, unlike the preceding absent-index snapshot. Population origin/
time is not inferred; the historical snapshot remains immutable. No anonymous token,
remote metadata or payload request was needed. Empty attempt ledger was materialized
explicitly after cache-only completion, not portrayed as a pre-acquisition journal.
Actual HTTP/token/redirect acquisition code paths are unexercised; metadata bytes are
verified cache content, not fresh live registry observations.

Native OCI index `sha256:f06537653ac770703bc45b4b113475bd402f451e85223f0f2837acbf89ab020a` selects linux/amd64 platform manifest
`sha256:8af0e5095f9964007f5ebd11191dfe52dcb51bf3afa2c07f055fc5451b78ba0e` and config `sha256:d6b3fe87704bf89df3b8ab19d5f3ab0a248bf5b6b76a602da86d611ea9d23ae0`.
Four objects total **28,246,259 bytes**, including one **28,236,225-byte** gzip layer.
Descriptor sizes/content hashes, config linux/amd64 identity and uncompressed diff-ID
`sha256:6143ee9e3de07e6ca35edaf392cf93dea566a5bcd0d3696607ae6c324193d099` match.
Final prepared set is **40 inputs / 585,352,953 bytes**, including 36 inherited inputs
copied by exact hashes without reacquisition. Original tag bookworm-slim is only a hint.

Bounded static inspection measures **77,895,680 expanded bytes / 4,226 members** and
retains **100 regular notice files / 1,261,744 bytes**, plus exact dpkg-status/os-release
metadata. Complete inventory/file types/link targets/offsets and content hashes remain
bound. Links are not followed and no layer filesystem extraction or image/container
execution occurs. Complete merged-filesystem/license/package coverage and qualification
remain unaccepted; wrapper/source licenses and payload notices stay distinct.

The independent alias/platform repository query passes **0 in 3.723 seconds**, consuming
exact prepared caches with zero mirror requests. Two fresh non-symlink directories and
completed markers retain native manifests/config/layer/generated-layout hashes.
Both probes bind original-source-supported `--repo_env=OCI_GET_TOKEN_ALLOW_FAIL=1`.
Carry this flag in successor operator copies: the token endpoint remains outside exact
URL rewrites, namespace external networking is disabled and real home is hidden. The
source permits an empty auth result after refusal, preserving exact cached/local object
integrity. The preceding sealed token refusal is referenced; current native token-attempt
count/detail is unexposed and remains unknown. No fabricated token is served; no native
www-authenticate response file remains. Live native registry authentication is unqualified.

Original five-label configured Linux cquery exits **1 in 10.697 seconds** at unlisted
score_cpp_policies 0.1.1. All **68 metadata / 30 asset writes** complete, totaling
**407,573,883 response-content bytes**, with no interrupted writes in this stage.
Mirror served_bytes is a reservation counter; here it equals completed content, not a
wire-meter claim. Earlier interrupted GCC response records remain immutable. The native
log reports zero action processes and the score_tooling version warning stays enabled.
No configured retry or successor fetch follows the first out-of-scope failure, despite
unused budgets. No native compilation/test, container/image execution or engineering
acceptance follows repository loading.

## Next original-pinned archive

[Readiness](../../specs/011-change-impact-and-freshness/evidence/t033-debian-oci/next-prerequisite.json)
binds original MODULE/lock and original registry source declaration:

- Native URL: `https://github.com/eclipse-score/score_cpp_policies/archive/refs/tags/v0.1.1.tar.gz`.
- Repository: `@@score_cpp_policies+`; module **0.1.1**.
- Blocked dependency: `@@score_cpp_policies+//warnings/gcc/features:all_wall_warnings`.
- Original integrity: `sha256-XdacCUH0TFfHjoItSkXV/0PNPs9aVbmW5Vu/NTZL+hw=`.
- SHA-256: `5dd69c0941f44c57c78e822d4a45d5ff43cd3ecf5a55b996e55bbf35364bfa1c`; strip prefix **score_cpp_policies-0.1.1**.
- Registry declaration: `https://raw.githubusercontent.com/eclipse-score/bazel_registry/main/modules/score_cpp_policies/0.1.1/source.json`.
- Original-lock registry SHA-256: `29d45fbd6f3fae0a21487f5d652dfa0796bd2095d2a19732a5456e5b232754a9`.

Exact inspected historical SHA-256 cache key is absent; no whole-machine absence claim.
Public source/tag/release/license/size metadata, archive inventory/expanded sizes and
combined byte fit remain unqueried/unassessed. Adding this archive would make 41 inputs,
but the OCI-only allowlist does not admit it. No policy archive/source license is fetched
or imported this stage. Measure exact source/license/size/cache provenance and declare
fresh finite metadata/acquisition/archive/notice/storage/probe limits before payload
acquisition. Do not edit native locks/warning policy, substitute tags/host inputs or
remove targets to obtain success. Keep first unchanged/out-of-scope failure stops.

## Storage, tools, preservation and acceptance

Current fresh workspace: `/media/jefferson/11c42dee-73a3-4c2b-ab42-a0440011d9e0/.s-core-build/runs/score-fabric-lwyiyg6e`. Use score-fabric storage / score_sw_fabric.storage
for every successor workspace/cache. Owner confirmed 1 TiB and authorized mounting the
registered ext4 image; mount remains
`/media/jefferson/11c42dee-73a3-4c2b-ab42-a0440011d9e0`, device 1819,
backing SSD UUID 002B-CE31 on exfat. No resize/repair/reformat. Old device-1818 records
stay immutable; independently rebind read-only same-UUID inputs by hashes. Stop on
volume disconnection instead of relocating active work. Do not migrate queues/global
storage or copy credentials/private state. Never write/build in reference repositories;
inspect hooks and use fresh disposable copies for native work.

US44 bounds: 44 inputs (36 inherited plus at most eight exact OCI objects),
256 MiB/object, 1 GiB aggregate/mirror content, sixteen two-MiB metadata responses,
one 64-KiB/30-second in-memory anonymous-token response, eight 120-second payload
requests, 256 MiB expanded layer bytes, 20,000 members, eight-MiB/notice and 32-MiB notice
total, 512 mirror requests, 20 GiB free reserve and three 120-second native attempts.
Zero remote/token requests and two native probes used. Tokens must remain out of SSD/
evidence/logs if a separately bounded future public registry acquisition needs one.
Runtime/home/network/write isolation and exact operator/input bindings remain preserved.

Fresh frozen sync, Specify 1.0.12 version/prerequisites, foundation initial/final,
package build, control whitespace and trace checks pass. Prior **223 scoped tests/Ruff/
mypy over 152 source files** are carried by **310 unchanged source/test hashes**; no
new source checks run. Operators are syntax-checked and archived. Use Python >=3.12:
.venv and retained read-only mirror runtime are 3.12.14; host 3.10 is unsuitable. Verify
3,484 runtime hashes/current volume binding and use PYTHONDONTWRITEBYTECODE=1.
Bazel 8.7.0 SHA-256 `d7606e679b78067c811096fb3d6cf135225b528835ca396e3a4dddf957859544`;
native baseline `7d1d7bec81d96752b5a9a235044d2dfc3ecd259b`; original source archive
`19dbc09f9424ff9d52a9f7ec8b64715c79cba32b4c063e0d41c158d657c5368c`.
Pinned Specify tool path is retained; explicitly set
SPECIFY_FEATURE_DIRECTORY=/home/jefferson/s-core_sw_fabric/specs/011-change-impact-and-freshness.
No extension hooks are registered. Six requirements checklist items are checked; seven
custom reviewer items stay pending/unchanged under owner continuation instructions.

**29 prior packets / 6,496 subjects**, twenty T032 subjects, 740 native original files,
3,484 runtime files and 405 old cache markers remain unchanged. Including this packet:
**30 packets / 6,696 subjects**. Tasks **151/153**, preserving T032/T033 without a mission
percentage. Owned probes reaped/mirrors closed; no private/provider server or background
continuation starts. Preserve exact historical subject-bound engineering decisions.

QNX stays skipped because the owner has no license. Do not request SDK/credentials,
read license-path files or run QNX variants. Human review stays offline outside Fabro
workflows; export complete bound reports without human wait nodes or synthetic decisions.
Full native expected-check scope, transitive impact/work products, reviewer authority,
tool qualification and real B1–B5/T033 measurements/acceptance remain pending. Publication
is deferred; approved local contribution destination stays unchanged. No paid successor
call, scheduler, SDK, native build/test, publishing/merging/release/deployment or human
decision follows this stage. Historical paid exceptions do not authorize fresh spending.
Spec Kit owns fabric development, S-CORE engineering semantics/artifacts, Fabro run state.

[Machine-readable snapshot](011-session-20261005-debian-oci.json) binds subjects and gaps.
Recommended model: **gpt-6.1-sol (high)** for exact source-archive provenance and bounded
native dependency diagnosis; this recommendation does not switch the session.
