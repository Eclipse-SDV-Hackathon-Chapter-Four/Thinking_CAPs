# T033 real S-CORE issue selection

Selected on 2026-10-04: [eclipse-score/lifecycle #704 — Deduplicate `mw_com_config.json` files](https://github.com/eclipse-score/lifecycle/issues/704).

The owner requested a simple open issue with no one currently handling it. Selection
and read-only investigation are complete; implementation and paid execution have not
started. T033 remains pending. The user supplied T032 approval separately.

Subsequent continuation: the owner's `go` authorized local implementation and comparison
preparation. [The completed patch and checks](evidence/lifecycle-704/README.md) supersede
the pre-implementation status above. T033 engineering/live qualification remains pending.

## Public activity checks

GitHub was queried directly on 2026-10-04 UTC. The issue is open, carries `good first issue`
and `cleanup`, has no assignees and zero comments. Its timeline has no linked implementation,
referenced commit or assignment. PR search for #704 returns no matches. All 22 open lifecycle
PRs, including drafts, were checked for configuration filenames or `mw_com_config` in their
returned patches; none overlap. Pages were complete at observation time.

These checks support **no visible active implementation**. Private work, unpushed branches
and future changes are unknown; recheck before starting. No public reservation or assignment
was made. [Structured observations](evidence/t033-issue-selection.json) retain timestamps,
PR head SHAs, configuration hashes and the exact upstream baseline.

Rejected alternatives: lifecycle #570 has active fix [PR #609](https://github.com/eclipse-score/lifecycle/pull/609);
docs-as-code #288 has unresolved maintainer questions about whether the defect still exists;
lifecycle #578 has prior implementation history and a broader documentation scope.

## Small, bounded scope

Inspected upstream `main` at `7d1d7bec81d96752b5a9a235044d2dfc3ecd259b`.
The tree contains three `mw_com_config` JSON files:

- `score/launch_manager/src/daemon/src/control/control_provider_test_mw_com_config.json`
- `score/launch_manager/src/lm_control/src/details/test_lmcontrol_mw_com_config.json`
- `tests/utils/environments/mw_com_config.json`

All three have identical `serviceTypes` definitions. Their service instances and global
settings differ: QM versus ASIL-B, provider permissions, queue sizes, subscriber settings
and instance specifiers. Share the repeated definition and adjust its consumers while
preserving each effective configuration. Do not replace distinct settings with one
unconditional JSON file. The issue permits minimal duplication, so retaining necessary
consumer-specific variants is within its stated acceptance criterion.

This is a bounded configuration/build cleanup with no intended C++ behavior change.
Classification and safety applicability remain to be evaluated deterministically from
the exact impact scope; the `good first issue` label does not establish S0/S1 or acceptance.
The upstream pre-commit configuration was inspected without executing it.

## Concrete next work and validation

1. Recheck issue/PR activity and pin the selected baseline in a disposable workspace
   allocated through the shared storage policy. Keep reference repositories read-only.
2. Inventory every configuration consumer and runfile/image path, including QNX image
   packaging. Choose the smallest reuse mechanism supported by the repository.
3. Compare the parsed effective old/new JSON for every consumer; preserve all settings.
   Run the actual `control_provider_UT` and `ilm_control_UT` targets defined in the inspected
   BUILD files, plus affected integration/configuration checks and native format checks.
   Missing QNX capability remains a recorded gap, not a passing test.
4. Use equivalent baseline/optimized task variants for the real guarded Fabro comparison;
   retain provider usage, uncached input, outputs, raw evidence references, required checks
   and engineering review separately. Apply an explicitly scoped provider budget before
   any new paid call. Previous ten-request experiments are closed and immutable.

This issue can supply one real cleanup case. It does not by itself cover all five B1–B5
scenarios, demonstrate 60–80% live savings or provide human engineering acceptance.
The current selection does not authorize comments, assignment, an upstream PR, publication,
merge, release or deployment.

## Actual Flash run status

The latest owner `go` authorized a fresh four-request Fabro/Flash attempt.
[Its evidence](evidence/lifecycle-704-flash/README.md) records a rejected generator and
invalid BUILD output; qualification failed. The earlier Codex patch is unchanged. T033
remains pending; no upstream write or engineering acceptance occurred.

## Current owner-approved patch and local upstream packet

The later JSON-mode Fabro/Flash retry produced a tested patch with 113 passing native
cases and a separately complete guarded transport proof. The owner approved that exact
[patch/advisory subject](lifecycle-704-owner-review.md), then requested [local upstream PR preparation](evidence/lifecycle-704-upstream-packet/README.md).
This supersedes the earlier failed-attempt status for current local implementation/review.
T033's broader real-target qualification and native/005 acceptance gaps remain pending;
no new paid call or upstream action follows from local-only preparation.
