# Rust API queue execution handoff — 2026-10-06

The user's `go` authorized Linux binding, live runtime qualification and starting the
queue. Native Fabro accepted all 13 issue starts. QNX #1278 is excluded. At
2026-10-06T14:50:20.011954+00:00 the observed native states were `{"runnable": 7, "running": 5, "succeeded": 1}`.
Every actual model observed is `deepseek-v4-flash`, provider `deepseek`, configured by
`deepseek-flash` with empty fallbacks. Each issue has a Flash supervisor; new issue
corrections remain capped at three. #1265 is evidence reuse, with zero new corrections
and no reset of historical exhausted budgets. Fabro success does not imply acceptance.

Fresh native Linux query and score_com_concept-test passed at source
`381d43dec900ab6a9076f3f30e7bfbdee019e26e`, with cached test results disabled. XML counts
one wrapper target; inner Rust case totals are not aggregated. The actual Flash hook
probe allowed a bounded file read and blocked shell. All 13 revised graph validations
and source/control/storage preflights passed; active jobs passed real native preflight.

The first command-only runtime probe failed at shallow snapshot push before any model
call. The subsequent actual probe passed after binding native managed workspace paths
to the selected SSD, disabling clone, and enabling shallow receive in private snapshot
repositories. Native checkpoint commits precede preflight: published checkpoint HEAD,
baseline ancestry and unchanged initial source hashes are now verified. Original
unstarted runs were cancelled/archived with native evidence retained. New version/run
IDs are in the machine handoff and queue inventory; never restart original IDs.

The requested CLI concurrency of one was not applied. Native GET /api/v1/settings
confirmed **five** and the observed active states agree. Current execution retains
five to preserve active progress; earlier single-run claims are historical and corrected.
Fabro owns dispatch/state. There is no second scheduler. Submission order alone does
not establish fulfilled backend/design prerequisites.

- [Sealed execution-launch packet](/home/jefferson/eclipse_sdv_hackathon_2026/contributions/rust-api-queue/score-rust-issue-queue-ycbvxir7-linux-execution/README.md) contains 797 bound
  payloads, raw Linux logs/XML/Bazel events, probes/refusals and native launch projections.
- Packet manifest SHA256: `2f77e0092d99a68c9bf6abfc0de32e132ceff35543917196ce95b4bcdf75a2d4`.
- [Machine handoff](011-session-20261006-rust-api-queue-running.json) records exact
  active run/version IDs, limits, authority, capacity discrepancy and remaining work.
- Original creation packet (322 payloads) remains unchanged and hash-verified.

Active root: `/media/jefferson/11c42dee-73a3-4c2b-ab42-a0440011d9e0/.s-core-build/runs/score-rust-issue-queue-ycbvxir7`.
Server: `http://127.0.0.1:36547`, PID `1847968`, private state internal at
`/home/jefferson/.local/state/s-core/fabro/score-rust-issue-queue-ycbvxir7/rust_api_queue`. Credentials stay in the private native vault and are absent
from exported packets. A new owned rootless Docker runtime remains active; its endpoint,
PID, data root and private state are in root/docker-binding.json. Its data root is this
queue's SSD. Old runtimes/global queues/tool storage were not changed or resumed.

Validate the existing storage binding before every operation. Keep the SSD connected;
stop on disconnection/remount, never relocate active work or resubmit/reinitialize IDs.
Treat ongoing hashes/check results as snapshots tied to their exact subjects. Per-job
exports appear at root/jobs/<issue>/export. Collect terminal native projections and all
actual exports into contributions with complete failures/gaps, then seal them and stop
only these owned runtime processes. Native test failure/unsupported applicability must
not become accepted engineering decisions. No new publication, merge or human acceptance
is authorized. The queue runs independently of the Codex turn in native Fabro.

Next step: collect the queued runs' terminal exports and preserve remaining budgets.
Recommended model: deepseek-flash — user-required for every Fabro agent stage.
