# Rust API queue collected results — 2026-10-06

All 13 native runs are terminal, their available evidence is collected, and only this
queue's owned Docker/private Fabro processes are stopped. This completes collection;
no new issue is fully verified or accepted. Native `succeeded` means the workflow
exported its results, including failures. Human engineering decisions remain offline.

The [sealed results packet](/home/jefferson/eclipse_sdv_hackathon_2026/contributions/rust-api-queue/score-rust-issue-queue-ycbvxir7-results/README.md) contains 1543 hash-bound payloads: four draft
patches (#781, #560, #490, #1261), eight assessment/report packages and #741's comment-only
probe artifact. That probe is not the requested relocation and must not be adopted as
an issue fix. Manifest SHA256: `488325118228875fde470f2ffe0645d98a681d9e736d29c9859f265348f5b7ef`. All payload hashes were verified
again before this handoff; the earlier creation/Linux-launch packets remain unchanged.

All observed agents/corrections/supervisors used `deepseek-v4-flash` (alias
`deepseek-flash`, provider `deepseek`, empty fallbacks). New issues used at most three
correction attempts. Actual used/max/remaining counts are in the machine handoff;
29 total attempts were used and seven slots remain across four issues. #1265 reused
historical evidence with no new fixes/tests and no reset of prior exhausted budgets.
QNX #1278 was excluded. Native dispatch used its observed limit of five, not the ignored
startup request for one; no second scheduler or queue migration was introduced.

All 12 jobs with new final measurements retain failed validations. #1265 has no new
measurement. Across repeated attempts, 129 command-specific Bazel test-result events
were PASSED with cached test results disabled; this is not 129 unique targets or a
claim that complete issue verification passed. Latest measured source maps match all
12 exported final source states. `docs` checks built targets rather than executing
Rust doctests. Native requirement/qualification/acceptance gaps remain explicit.

Written supervisor reviews are missing for #1263, #490, #250, #1261 and #173. #1263's
stage ended without writing its report; the other four supervisor stages failed on
DeepSeek requests. Raw actual stage output/failure and native events are preserved in
`gaps/` and each issue's native records. No replacement review was synthesized.

The operator [runtime findings](/home/jefferson/eclipse_sdv_hackathon_2026/contributions/rust-api-queue/score-rust-issue-queue-ycbvxir7-results/operator-findings.md) bind two execution defects:
the launcher loads the native lint rc twice, and the file-tool guard lacks relocation
operations and blocks native JSON reads needed by #741. Compile failures, invalid
plans, timeouts, provider failures and missing checks/reviews remain failures. No
active controls were changed to hide them or reset budgets. Any new follow-up requires
its own authority and must preserve the issue's remaining allowance.

The packet contains complete native event histories, exact graphs/final states,
source/tool/config/storage/authority bindings, original issue context, changed source,
raw measured logs/Bazel events/test logs, license notices and cleanup proof. Credentials
and private vault/server state remain internal; no result was newly committed/pushed.
The SSD queue root remains `/media/jefferson/11c42dee-73a3-4c2b-ab42-a0440011d9e0/.s-core-build/runs/score-rust-issue-queue-ycbvxir7`; validate its existing binding before later work and
stop on disconnection. Do not restart archived original IDs or rerun admission/start
scripts. The stopped private state remains available for audit, not automatic dispatch.

Next step: review runtime findings and unresolved issue packets before authorizing follow-up.
Recommended model: deepseek-flash — required for any further Fabro agent work.
