"""Exact local worker/result bindings; these APIs never grant provider authority."""

from __future__ import annotations

import fcntl
import hashlib
import os
import tarfile
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from score_sw_fabric.agents.output import validate_result
from score_sw_fabric.optimization.activation import (
    authorize_stage,
    private_file,
    verify_instruction,
)
from score_sw_fabric.optimization.common import (
    OptimizationError,
    canonical,
    checked,
    json_object,
    no_symlinks,
    raw_file,
    record,
    safe_file,
)
from score_sw_fabric.storage import validate_run_root


def file_hash(path: Path) -> str:
    no_symlinks(path)
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(root: Path, *, checkpoint_git: bool = False) -> dict[str, str]:
    """Full source inventory, including unexpected files; links are never source."""
    no_symlinks(root)
    result = {}
    for path in sorted(root.rglob("*")):
        if checkpoint_git and path.relative_to(root).parts[0] == ".git":
            continue
        no_symlinks(path)
        if path.is_file():
            result[path.relative_to(root).as_posix()] = file_hash(path)
        elif not path.is_dir():
            raise OptimizationError("SOURCE_SPECIAL_FILE")
    return result


def write_private(path: Path, value: dict[str, Any]) -> None:
    temporary = path.with_suffix(".pending")
    with temporary.open("xb") as stream:
        os.chmod(temporary, 0o600)
        stream.write(canonical(value))
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


class PairedWorker:
    """Operator-owned binding plus internal state, separate from mutable worker files."""

    def __init__(self, binding: Path, pin: str) -> None:
        data = private_file(binding)
        if hashlib.sha256(data).hexdigest() != pin:
            raise OptimizationError("PAIR_BINDING_DRIFT")
        self.binding = checked(json_object(data), "paired_worker_binding")
        self.path = binding
        self.pin = pin
        self.root = Path(self.binding["workspace"])
        self.worker = Path(self.binding["worker"])
        self.state_path = binding.parent / "worker-state.json"
        if binding.is_relative_to(self.root):
            raise OptimizationError("PRIVATE_STATE_ON_WORK_VOLUME")
        self.validate()

    def validate(self) -> None:
        validate_run_root(self.root)
        if hashlib.sha256(private_file(self.path)).hexdigest() != self.pin:
            raise OptimizationError("PAIR_BINDING_DRIFT")
        no_symlinks(self.worker)
        if not self.worker.is_dir() or self.worker == self.root:
            raise OptimizationError("WORKER_BINDING")
        mode = self.binding["worker_kind"]
        if mode == "local_disposable":
            if not self.worker.is_relative_to(self.root):
                raise OptimizationError("WORKER_BINDING")
        elif mode == "native_fabro":
            server = Path(self.binding["server_root"])
            no_symlinks(server)
            try:
                relative = self.worker.relative_to(server / "storage/scratch")
            except ValueError as exc:
                raise OptimizationError("WORKER_BINDING") from exc
            if (
                self.binding["fabro_source_commit"] != "1b4fb15281ebb724426f9e480dce48d0100ff79b"
                or not server.is_relative_to(self.path.parent.parent)
                or server.is_relative_to(self.root)
                or len(relative.parts) != 5
                or not relative.parts[0].endswith("-" + self.binding["run_id"])
                or relative.parts[1:] != ("petri", "scopes", "invocation-0-scope-0", "work")
            ):
                raise OptimizationError("WORKER_BINDING")
        else:
            raise OptimizationError("WORKER_KIND")
        if self.binding["arm"] not in {"baseline", "optimized"}:
            raise OptimizationError("ARM_BINDING")
        if "native_git" in self.binding:
            self.checkpoint_metadata()

    def checkpoint_metadata(self) -> None:
        """Only the measured native checkpoint directory is outside source scope."""
        metadata = self.binding["native_git"]
        if (
            self.binding["worker_kind"] != "native_fabro"
            or not isinstance(metadata, dict)
            or set(metadata) != {"config_sha256"}
        ):
            raise OptimizationError("NATIVE_METADATA_BINDING")
        directory = self.worker / ".git"
        no_symlinks(directory)
        if not directory.is_dir():
            raise OptimizationError("NATIVE_METADATA_DRIFT")
        for path in directory.rglob("*"):
            no_symlinks(path)
            if not (path.is_file() or path.is_dir()):
                raise OptimizationError("NATIVE_METADATA_DRIFT")
        config = safe_file(self.worker, ".git/config")
        head = safe_file(self.worker, ".git/HEAD")
        if (
            file_hash(config) != metadata["config_sha256"]
            or head.read_text() != f"ref: refs/heads/fabro/run/{self.binding['run_id']}\n"
            or any(not path.name.endswith(".sample") for path in (directory / "hooks").glob("*"))
        ):
            raise OptimizationError("NATIVE_METADATA_DRIFT")

    def source_inventory(self) -> dict[str, str]:
        enabled = "native_git" in self.binding
        if enabled:
            self.checkpoint_metadata()
        return inventory(self.worker, checkpoint_git=enabled)

    def identity(self, context: dict[str, Any], cwd: Path) -> None:
        self.validate()
        expected_run = (
            "petri" if self.binding["worker_kind"] == "native_fabro" else self.binding["run_id"]
        )
        if (
            context.get("run_id") != expected_run
            or context.get("arm") != self.binding["arm"]
            or cwd != self.worker
            or context.get("cwd", str(cwd)) != str(self.worker)
        ):
            raise OptimizationError("WORKER_IDENTITY")

    @contextmanager
    def state(self) -> Iterator[dict[str, Any]]:
        """Serialize mutations; an interrupted transaction stays stopped, never replayable."""
        lock = self.path.parent / "worker.lock"
        no_symlinks(lock)
        fd = os.open(lock, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX)
            self.validate()
            state = json_object(private_file(self.state_path)) if self.state_path.exists() else {}
            if state and (state.get("binding") != self.pin or state.get("stopped")):
                raise OptimizationError("WORKER_STOPPED")
            yield state
        finally:
            os.close(fd)

    def verify_source(self, state: dict[str, Any]) -> None:
        if self.source_inventory() != state.get("source_files"):
            raise OptimizationError("CANDIDATE_SOURCE_DRIFT")

    def initialize(self, context: dict[str, Any], cwd: Path) -> dict[str, Any]:
        self.identity(context, cwd)
        with self.state() as state:
            existing = [
                path
                for path in self.worker.iterdir()
                if "native_git" not in self.binding or path.name != ".git"
            ]
            if state or existing:
                raise OptimizationError("WORKER_NOT_EMPTY")
            archive = Path(self.binding["archive"])
            if file_hash(archive) != self.binding["archive_sha256"]:
                raise OptimizationError("SOURCE_ARCHIVE_DRIFT")
            expected = self.binding["source_files"]
            with tarfile.open(archive) as bundle:
                names: set[str] = set()
                for member in bundle.getmembers():
                    name = member.name.rstrip("/")
                    safe_file(self.worker, name, must_exist=False)
                    if name in names or not (member.isdir() or member.isfile()):
                        raise OptimizationError("UNSAFE_SOURCE_ARCHIVE")
                    names.add(name)
                    if member.isfile() and (
                        name not in expected or member.size > 128 * 1024 * 1024
                    ):
                        raise OptimizationError("SOURCE_ARCHIVE_SCOPE")
                state.update(binding=self.pin, stopped=True)
                write_private(self.state_path, state)
                bundle.extractall(self.worker, filter="data")
            if self.source_inventory() != expected:
                raise OptimizationError("ORIGINAL_SOURCE_DRIFT")
            state.update(source_files=expected, stopped=False, applied=[], checks=[])
            write_private(self.state_path, state)
            return record("paired_source_initialized", binding=self.pin, files=len(expected))

    def apply(
        self, context: dict[str, Any], cwd: Path, receipt: Path, receipt_pin: str
    ) -> dict[str, Any]:
        """Apply a complete pinned reply. The receipt supplies provenance, not acceptance."""
        self.identity(context, cwd)
        data = private_file(receipt)
        if receipt.parent != self.path.parent or hashlib.sha256(data).hexdigest() != receipt_pin:
            raise OptimizationError("RESULT_RECEIPT_DRIFT")
        witness = checked(json_object(data), "paired_response_receipt")
        stage = context.get("node_id")
        if (
            stage not in {"implementation", "correction"}
            or witness.get("stage") != stage
            or witness.get("binding") != self.pin
        ):
            raise OptimizationError("RESULT_IDENTITY")
        raw, ref = raw_file(self.root, witness["response_path"], witness["response_sha256"])
        usage = None
        if witness.get("origin") == "native_provider_observed":
            usage = self.provider_witness(witness, context, raw)
        elif (
            witness.get("origin") != "local_replay"
            or self.binding.get("execution_mode") != "local_only"
        ):
            raise OptimizationError("RESULT_ORIGIN")
        result = decode_response(raw)
        if set(result) != {"agent_result", "candidate_changes"}:
            raise OptimizationError("RESULT_SCOPE")
        agent = validate_result(result["agent_result"])
        writes = self.binding["write_paths"]
        deletes = self.binding["delete_paths"]
        candidate = result["candidate_changes"]
        if (
            not isinstance(candidate, dict)
            or set(candidate) != {"files", "delete_paths"}
            or agent["context_digest"] != self.binding["context_digest"]
            or agent["role_id"] != self.binding["role_id"]
            or agent["native_ids_affected"] != self.binding["native_ids"]
            or sorted(agent["changed_paths"]) != sorted(writes + deletes)
            or candidate["delete_paths"] != deletes
            or not isinstance(candidate["files"], list)
            or len(candidate["files"]) != len(writes)
        ):
            raise OptimizationError("RESULT_SCOPE")
        prepared: dict[str, bytes] = {}
        for item in candidate["files"]:
            if (
                not isinstance(item, dict)
                or set(item) != {"path", "content"}
                or item["path"] not in writes
                or item["path"] in prepared
                or not isinstance(item["content"], str)
                or len(item["content"].encode()) > 50000
                or any(marker not in item["content"] for marker in self.binding["license_markers"])
            ):
                raise OptimizationError("CANDIDATE_CONTENT")
            safe_file(self.worker, item["path"], must_exist=False)
            prepared[item["path"]] = item["content"].encode()
        with self.state() as state:
            self.verify_source(state)
            expected = [] if stage == "implementation" else ["implementation"]
            if state["applied"] != expected:
                raise OptimizationError("RESULT_REPLAY_OR_ORDER")
            if ref["sha256"] in state.get("responses", []):
                raise OptimizationError("RESULT_REPLAY_OR_ORDER")
            if stage == "correction" and (
                not state["checks"] or state["checks"][-1]["status"] != "fail"
            ):
                raise OptimizationError("CORRECTION_WITHOUT_FAILED_CHECKS")
            if stage == "correction":
                previous = state["checks"][-1]
                raw_check, _ = raw_file(
                    self.root, previous["result_path"], previous["result_sha256"]
                )
                prior_check = checked(json_object(raw_check), "paired_fresh_checks")
                if (
                    prior_check["status"] != "fail"
                    or prior_check["binding"] != self.pin
                    or prior_check["candidate"] != state["candidate"]["digest"]
                ):
                    raise OptimizationError("CHECK_RECEIPT_DRIFT")
            for name in deletes:
                if stage == "implementation":
                    safe_file(self.worker, name)
            state["stopped"] = True
            write_private(self.state_path, state)
            for name, content in prepared.items():
                target = safe_file(self.worker, name, must_exist=False)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(content)
            for name in deletes:
                safe_file(self.worker, name, must_exist=False).unlink(missing_ok=True)
            actual = self.source_inventory()
            expected_files = dict(state["source_files"])
            expected_files.update(
                {name: hashlib.sha256(data).hexdigest() for name, data in prepared.items()}
            )
            for name in deletes:
                expected_files.pop(name, None)
            if actual != expected_files:
                raise OptimizationError("CANDIDATE_SOURCE_DRIFT")
            applied = record(
                "paired_candidate_applied",
                binding=self.pin,
                stage=stage,
                response=ref,
                origin=witness["origin"],
                source_digest=file_set_digest(actual),
                engineering_acceptance="pending",
                usage=usage,
                measurement_scope="result application only; no provider request made here",
            )
            state.update(source_files=actual, stopped=False, candidate=applied)
            state["applied"].append(stage)
            state.setdefault("responses", []).append(ref["sha256"])
            write_private(self.state_path, state)
            return applied

    def provider_witness(
        self,
        witness: dict[str, Any],
        context: dict[str, Any],
        raw: bytes,
    ) -> dict[str, Any]:
        """Read a current observed meter ticket; never create an execution instruction."""
        from score_sw_fabric.optimization.provider_boundary import reported_usage

        if (
            self.binding.get("execution_mode") != "qualified_native"
            or self.binding["worker_kind"] != "native_fabro"
        ):
            raise OptimizationError("LIVE_RESULT_NOT_AUTHORIZED")
        source = self.binding.get("result_sources", {}).get(witness.get("stage"))
        if source is None or any(
            witness.get(name) != source.get(name)
            for name in ("instruction", "instruction_sha256", "meter_state", "task")
        ):
            raise OptimizationError("RESULT_ACTIVATION_BINDING")
        instruction_path = Path(witness["instruction"])
        instruction = verify_instruction(instruction_path, witness["instruction_sha256"])
        if (
            instruction["workspace"] != str(self.root)
            or instruction["stage"] != witness["stage"]
            or instruction["bindings"]["context"] != self.binding["context_digest"]
        ):
            raise OptimizationError("RESULT_ACTIVATION_BINDING")
        governor = None
        for filename in instruction["files"]:
            content = private_file(Path(filename))
            if content.startswith(b"{"):
                value = json_object(content)
                if value.get("kind") == "token_governor_decision":
                    governor = checked(value, "token_governor_decision")
        if governor is None:
            raise OptimizationError("RESULT_ACTIVATION_BINDING")
        if governor.get("decision") != "admissible" or governor.get("call_authorized") is not False:
            raise OptimizationError("LIVE_RESULT_NOT_AUTHORIZED")
        authorize_stage(
            instruction_path,
            witness["instruction_sha256"],
            context,
            governor,
            witness["stage"],
            host_cwd=self.worker,
        )
        meter_path = Path(witness["meter_state"])
        if meter_path.parent != instruction_path.parent:
            raise OptimizationError("RESULT_METER_BINDING")
        meter = json_object(private_file(meter_path))
        ticket = witness["ticket"]
        if type(ticket) is not int or not 0 <= ticket < len(meter["records"]):
            raise OptimizationError("RESULT_METER_BINDING")
        entry = meter["records"][ticket]
        usage = reported_usage(raw, stream=raw.startswith(b"data:"))
        details = usage.get("completion_tokens_details") or {}
        if (
            meter.get("stopped")
            or meter.get("instruction_sha256") != witness["instruction_sha256"]
            or entry["ticket"] != ticket
            or entry["status"] != "observed"
            or entry["task"] != witness["task"]
            or entry.get("response_sha256") != hashlib.sha256(raw).hexdigest()
            or type(entry.get("response_bytes")) is not int
            or entry["response_bytes"] != len(raw)
            or not any(task["marker"] == entry["task"] for task in instruction["tasks"])
            or any(usage.get(name) != value for name, value in entry["usage"].items())
            or not isinstance(details, dict)
            or details.get("reasoning_tokens") != entry.get("reasoning_tokens")
            or witness["response_path"]
            != f"provider-records/{witness['instruction_sha256']}/response-{ticket:02d}.raw"
        ):
            raise OptimizationError("RESULT_METER_BINDING")
        if any(
            item["task"] == source["task"] and item["ticket"] > ticket for item in meter["records"]
        ):
            try:
                decode_response(raw)
            except OptimizationError:
                pass  # Earlier completed tool turns are verified below by their successor.
            else:
                raise OptimizationError("OBSERVED_RESULT_AMBIGUOUS")
        preceding = [
            item
            for item in meter["records"]
            if item["task"] == source["task"] and item["ticket"] < ticket
        ]
        if preceding:
            from score_sw_fabric.optimization.tool_capture import verify_tool_link

            protected = json_object(private_file(self.state_path))
            if protected.get("binding") != self.pin or protected.get("stopped"):
                raise OptimizationError("WORKER_STOPPED")
            self.verify_source(protected)
            if not protected.get("checks") or not protected.get("candidate"):
                raise OptimizationError("FRESH_FEEDBACK_MISSING")

            for index, prior in enumerate(preceding):
                prior_raw, prior_ref = raw_file(
                    self.root,
                    f"provider-records/{source['instruction_sha256']}/response-{prior['ticket']:02d}.raw",
                    prior.get("response_sha256"),
                )
                prior_witness = record(
                    "paired_response_receipt",
                    binding=self.pin,
                    stage=witness["stage"],
                    origin="native_provider_observed",
                    response_path=prior_ref["path"],
                    response_sha256=prior_ref["sha256"],
                    ticket=prior["ticket"],
                    **source,
                )
                self.provider_witness(prior_witness, context, prior_raw)
                try:
                    decode_response(prior_raw)
                except OptimizationError:
                    pass
                else:
                    raise OptimizationError("OBSERVED_RESULT_AMBIGUOUS")
                following = preceding[index + 1] if index + 1 < len(preceding) else entry
                try:
                    verify_tool_link(
                        self.root,
                        source,
                        witness["stage"],
                        instruction,
                        prior,
                        following,
                        worker_binding=self.pin,
                        candidate=protected["candidate"]["digest"],
                        check_sha256=protected["checks"][-1]["result_sha256"],
                    )
                except (KeyError, TypeError, AttributeError) as error:
                    raise OptimizationError("TOOL_SOURCE_BINDING") from error
        return usage

    def feedback(self, context: dict[str, Any], cwd: Path) -> dict[str, Any]:
        """Bounded candidate/check references for repair/review; raw logs stay on host."""
        self.identity(context, cwd)
        with self.state() as state:
            self.verify_source(state)
            if not state.get("checks"):
                raise OptimizationError("FRESH_FEEDBACK_MISSING")
            last = state["checks"][-1]
            raw, reference = raw_file(self.root, last["result_path"], last["result_sha256"])
            result = checked(json_object(raw), "paired_fresh_checks")
            if (
                result["candidate"] != state["candidate"]["digest"]
                or result["source_digest"] != file_set_digest(state["source_files"])
                or result["binding"] != self.pin
            ):
                raise OptimizationError("FRESH_FEEDBACK_DRIFT")
            feedback = record(
                "paired_feedback",
                candidate=state["candidate"]["digest"],
                source_digest=result["source_digest"],
                checks=reference,
                status=result["status"],
                command_failures=[
                    item["id"] for item in result["commands"] if item["exit_code"] != 0
                ],
                outputs=[
                    {
                        key: item[key]
                        for key in (
                            "id",
                            "kind",
                            "status",
                            "sha256",
                            "total",
                            "failed",
                            "errors",
                            "skipped",
                        )
                        if key in item
                    }
                    for item in result["outputs"]
                ],
                current_sources={
                    name: state["source_files"][name] for name in self.binding["write_paths"]
                },
                engineering_acceptance="pending",
                native_expected_set="unresolved",
            )
            if len(canonical(feedback)) > 5000:
                raise OptimizationError("FEEDBACK_SIZE")
            return feedback

    def capture_apply(self, context: dict[str, Any], cwd: Path) -> dict[str, Any]:
        """Read the supplied observed meter, then apply; never issue a provider request."""
        self.identity(context, cwd)
        if self.binding.get("execution_mode") != "qualified_native":
            raise OptimizationError("LIVE_RESULT_NOT_AUTHORIZED")
        stage = context.get("node_id")
        if stage not in {"implementation", "correction"}:
            raise OptimizationError("RESULT_IDENTITY")
        raw, reference, witness = self.observed_response(context, cwd)
        decode_response(raw)
        receipt = self.path.parent / (stage + "-observed-receipt.json")
        # Exclusive receipt creation preserves an interrupted operation as a refusal.
        try:
            with receipt.open("xb") as stream:
                os.chmod(receipt, 0o600)
                stream.write(canonical(witness))
        except FileExistsError as exc:
            raise OptimizationError("RESULT_REPLAY_OR_ORDER") from exc
        return self.apply(context, cwd, receipt, file_hash(receipt))

    def observed_response(
        self, context: dict[str, Any], cwd: Path
    ) -> tuple[bytes, dict[str, Any], dict[str, Any]]:
        """Verify all observed tool turns, then select only the final complete response."""
        self.identity(context, cwd)
        if self.binding.get("execution_mode") != "qualified_native":
            raise OptimizationError("LIVE_RESULT_NOT_AUTHORIZED")
        stage = context.get("node_id")
        if not isinstance(stage, str) or stage not in self.binding["result_sources"]:
            raise OptimizationError("RESULT_IDENTITY")
        source = self.binding["result_sources"][stage]
        meter = json_object(private_file(Path(source["meter_state"])))
        entries = [
            entry
            for entry in meter["records"]
            if entry["task"] == source["task"] and entry["status"] == "observed"
        ]
        if not entries:
            raise OptimizationError("OBSERVED_RESULT_MISSING")
        if len(entries) > 1 and (
            meter["requests"] != len(meter["records"])
            or not {"tool_root", "tool_manifest"} <= set(source)
        ):
            raise OptimizationError("OBSERVED_RESULT_AMBIGUOUS")
        if any(
            entry["status"] != "observed"
            for entry in meter["records"]
            if entry["task"] == source["task"]
        ):
            raise OptimizationError("OBSERVED_RESULT_MISSING")
        ticket = entries[-1]["ticket"]
        relative = f"provider-records/{source['instruction_sha256']}/response-{ticket:02d}.raw"
        raw, reference = raw_file(self.root, relative)
        witness = record(
            "paired_response_receipt",
            binding=self.pin,
            stage=stage,
            origin="native_provider_observed",
            response_path=relative,
            response_sha256=reference["sha256"],
            ticket=ticket,
            **source,
        )
        self.provider_witness(witness, context, raw)
        decode_response(raw)
        return raw, reference, witness


def file_set_digest(files: dict[str, str]) -> str:
    return hashlib.sha256(canonical(files)).hexdigest()


def decode_response(raw: bytes) -> dict[str, Any]:
    """Decode complete JSON or SSE envelopes; never salvage partial/tool output."""
    if len(raw) > 2_000_000:
        raise OptimizationError("RESPONSE_SIZE")
    if raw.startswith(b"data:"):
        text = ""
        completed = False
        stopped = False
        for line in raw.splitlines():
            if not line:
                continue
            if completed or not line.startswith(b"data: "):
                raise OptimizationError("INCOMPLETE_RESPONSE")
            if line == b"data: [DONE]":
                completed = True
                continue
            frame = json_object(line[6:])
            if frame.get("model") not in {"deepseek-flash", "deepseek-v4-flash"}:
                raise OptimizationError("INCOMPLETE_RESPONSE")
            choices = frame.get("choices")
            if not isinstance(choices, list) or len(choices) > 1:
                raise OptimizationError("INCOMPLETE_RESPONSE")
            for choice in choices:
                if not isinstance(choice, dict) or choice.get("index") != 0 or stopped:
                    raise OptimizationError("INCOMPLETE_RESPONSE")
                delta = choice.get("delta", {})
                if not isinstance(delta, dict) or delta.get("tool_calls"):
                    raise OptimizationError("UNEXPECTED_RESPONSE_TOOLS")
                fragment = delta.get("content")
                if fragment is not None:
                    if not isinstance(fragment, str):
                        raise OptimizationError("RESPONSE_CONTENT")
                    text += fragment
                finish = choice.get("finish_reason")
                if finish is not None:
                    if finish != "stop":
                        raise OptimizationError("INCOMPLETE_RESPONSE")
                    stopped = True
        if not completed or not stopped:
            raise OptimizationError("INCOMPLETE_RESPONSE")
        return json_object(text.encode())
    envelope = json_object(raw)
    choices = envelope.get("choices")
    if (
        envelope.get("model") not in {"deepseek-flash", "deepseek-v4-flash"}
        or not isinstance(choices, list)
        or len(choices) != 1
        or not isinstance(choices[0], dict)
        or choices[0].get("index") != 0
        or choices[0].get("finish_reason") != "stop"
    ):
        raise OptimizationError("INCOMPLETE_RESPONSE")
    message = choices[0].get("message", {})
    if (
        not isinstance(message, dict)
        or message.get("tool_calls")
        or message.get("role") != "assistant"
    ):
        raise OptimizationError("UNEXPECTED_RESPONSE_TOOLS")
    content = message.get("content")
    if not isinstance(content, str):
        raise OptimizationError("RESPONSE_CONTENT")
    return json_object(content.encode())


def main() -> int:
    """Protected command-node entrypoints; operator paths/pins are never model tools."""
    import argparse
    import sys

    from score_sw_fabric.optimization.paired_collector import collect
    from score_sw_fabric.process_source.reader import InputError

    parser = argparse.ArgumentParser()
    parser.add_argument(
        "operation", choices=["initialize", "apply", "capture_apply", "checks", "feedback"]
    )
    parser.add_argument("--binding", required=True, type=Path)
    parser.add_argument("--pin", required=True)
    parser.add_argument("--stage", choices=["implementation", "correction"])
    parser.add_argument("--subject", type=Path)
    parser.add_argument("--subject-pin")
    parser.add_argument("--routing", action="store_true")
    args = parser.parse_args()
    try:
        worker = PairedWorker(args.binding, args.pin)
        context = {
            "run_id": "petri"
            if worker.binding["worker_kind"] == "native_fabro"
            else worker.binding["run_id"],
            "arm": worker.binding["arm"],
            "node_id": args.stage,
        }
        cwd = Path.cwd()
        if args.operation == "initialize":
            result = worker.initialize(context, cwd)
        elif args.operation == "feedback":
            result = worker.feedback(context, cwd)
        elif args.operation == "capture_apply":
            result = worker.capture_apply(context, cwd)
        elif args.subject is None or args.subject_pin is None:
            raise OptimizationError("SUBJECT_BINDING_REQUIRED")
        elif args.operation == "apply":
            result = worker.apply(context, cwd, args.subject, args.subject_pin)
        else:
            result = collect(worker, context, cwd, args.subject, args.subject_pin)
        emitted = result
        if args.routing:
            if args.operation != "feedback":
                raise OptimizationError("ROUTING_OPERATION")
            emitted = {"outcome": "succeeded", "context_updates": {"paired_feedback": result}}
        print(canonical(emitted).decode())
        return 0 if result.get("status", "pass") == "pass" else 1
    except (InputError, OSError, ValueError, KeyError, TypeError) as exc:
        print(
            canonical(
                {
                    "decision": "refused",
                    "reason": getattr(exc, "code", "INPUT_REJECTED"),
                    "provider_calls": 0,
                }
            ).decode(),
            file=sys.stderr,
        )
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
