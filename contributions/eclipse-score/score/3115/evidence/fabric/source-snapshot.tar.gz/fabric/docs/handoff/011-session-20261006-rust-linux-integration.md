# Rust COM Linux integration — six native cases passed

The user requested integration tests on Linux after the earlier Rust assessment.
This new scope was supervised by `/root/rust_issue_supervisor` and limited to
three corrective fixes. Work is complete for these selected Linux integration
tests. All three fixes were used; no further technical repair or relaunch is
authorized by this run's budget. Owned private servers stopped.

## Fresh native result

Selected communication baseline:
`8368bfb5b182ae6642d963b58ad4bac5dabc02c3`, observed from upstream main.
Three changed upstream files were verified against the earlier e3d126c2 baseline
using Git blob SHA-1 and SHA-256 identities. The contribution still changes only
the Rust README and identifier-pasting assessment. Its existing patch applies
cleanly to this new baseline. Patch SHA-256:
`eb687c1a36b054315970fdbb2a4833cbb5e9470fb30eb06e67a446ca87951c19`.

Both native integration targets passed freshly with cached test results disabled:

- `//score/mw/com/test/basic_rust_api/consumer_sync_apis/integration_test:test_com_api_sync`:
  BigData, mixed primitive and complex struct exchange; three passed.
- `//score/mw/com/test/basic_rust_api/consumer_async_apis/integration_test:test_com_api_async`:
  cancellation, asynchronous receive and streaming; three passed.

Total **six passed, zero failures, errors or skips**. Native XML and raw harness
logs independently match all six expected names. Consumers exited zero after
their completion conditions. Native fixture cleanup deliberately SIGTERMs the
producers and accepts exit 143; producer self-completion is not claimed.

Final Fabro run `01M4889N23QQRPB5CHZB2GVF5M`, workflow version
`5e15cc141483a3a45870e62733791fe34440163d5fed8f140a998902c0beb67a`,
succeeded. All five stages succeeded; 84 events are retained. Native Bazel took
54.797 seconds and the collector 56.441 seconds. The graph has no model, human
approval or automatic retry nodes. Native model lists are empty and recorded
native token usage is zero; this does not describe Codex session usage.

Tests built the real generated Rust APIs and production C++/LoLa runtime into
native Ubuntu 24.04 OCI packages. The pinned S-CORE framework, OCI loader and
Docker SDK ran against an owned rootless Docker 29.8.2 daemon. A runtime
observation confirms Linux amd64 images, native init, 2 GiB shared memory and an
owned framework bridge. Global Docker configuration and daemon were unchanged.

## Recovery and preserved failures

Three runtime fixes were used: shorten an overlong private Unix-socket path;
replace symlinked detached-namespace state with an actual short internal state
directory; pass the existing user DBus session/runtime directory after native
container startup failed at systemd cgroup setup. The last correction resolved
the fixture failure as measured by the successful native cases. No source,
toolchain pin or policy was changed to make tests pass.

The first native run `01M487J7SEV1V42R8QVSX9ZEKA` ended with six fixture errors,
zero assertion failures and zero skips. It did not execute COM assertions. Its
90-subject archive SHA-256 is
`7211e07da19f909495e57baba8fbd56542ef07b042bf0a9a62207e35b3241b50`.
First collector XML discovery lacked Bazel convenience symlinks; actual emitted
XML was independently collected. Final successful execution created the native
symlinks, and its executed collector captured XML/logs. Both raw reports remain.

Post-run packaging detected a draft edit to its bound exporter. The modified
draft was retained separately, and the exact verified launch script restored
from the sealed first archive. The refusal/restoration is recorded; no native
repair or test rerun followed. Do not erase this artifact-preparation deviation.

## Sealed evidence and storage

Current contribution:
`/home/jefferson/eclipse_sdv_hackathon_2026/contributions/issues/eclipse-score/communication/1265/linux-integration/score-rust-linux-integration-xfiuopbb/`.
Manifest seals **1,359 subjects**, SHA-256
`bb7972f22c5bd69db5dc5ade910f8f5e9785890c35738ea857d57daaa691a2c8`.
Registry and inventory select this packet; other issue records and submission
metadata were preserved. Offline contribution verification passed for all four
issues. Integrity verification does not rerun tests or evaluate acceptance.

Scratch:
`/media/jefferson/11c42dee-73a3-4c2b-ab42-a0440011d9e0/.s-core-build/runs/score-rust-linux-integration-xfiuopbb`.
Backing UUID `002B-CE31`, registered ext4 image UUID
`11c42dee-73a3-4c2b-ab42-a0440011d9e0`, measured device 1793.
Validate through `score_sw_fabric.storage` before future access. Stop on unplug
or remount; never rewrite guards or silently relocate this run. Initial storage
discovery briefly used an internal metadata-only root after blkid timed out;
a new external selection succeeded before source/cache/build allocation.

Fresh allocation imported 1,312 verified public download payloads and exact
empty markers; no old build outputs, queue or private state was migrated.
Public native build/image data stays on the SSD. Private Docker state, client
configuration and Fabro credentials stay internal; a default Docker socket bind
exists only inside native command namespaces. Private Docker API absence,
no running owned process-group members, absent socket and stopped Fabro PIDs
were independently measured. No servers remain to resume.

All 53 bound files, seven tools, 2,879 source subjects, 13 runtime libraries and
original host-library hashes passed the supervisor audit. Noble library/archive
provenance, signatures and notices remain retained from verified immutable inputs.
Native OCI descriptors and layer hashes are exported; larger layer bytes remain
in the bound build workspace, outside the portable report packet.

## Historical evidence and pending decisions

The earlier 1,046-subject packet remains byte-exact, SHA-256
`6357dce316bbf9e30bb23accd75fdb553a7a87130f040bc4108a815267c0c600`.
Its 33 passing Rust unit/doctest cases, two ignored cases and 204 copyright
findings apply to e3d126c2, not this newer baseline. They were not rerun or
promoted. Preserve its auxiliary-help default-cache extraction deviation and
unmeasured cache delta. Current-baseline copyright checking remains unperformed.

The generic `.agents/skills/score-rust-workflow/` is implemented and installed
through `/home/jefferson/.codex/skills/score-rust-workflow`; its sealed Spec Kit
records remain under `specs/011-change-impact-and-freshness/rust-workflow/`.
No foundation or existing user source work was changed in this integration scope.

Full repository CI, QNX, sanitizers/coverage, complete layout/ABI proof, compiler
qualification, communication adoption and authorized offline engineering review
remain unperformed or pending. Native BigData placeholders/sample-count checks
do not establish every payload field or C++ layout. Supervisor review and Fabro
success do not supply human acceptance. No publication, merge, issue closure or
accepted-fix/submission-count promotion occurred.

Next action: offline engineering review of the assessment, integration evidence
and qualification obligations. No further native test execution is needed for
the requested focused Linux integration scope.
