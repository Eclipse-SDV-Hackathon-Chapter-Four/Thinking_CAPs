# Versioned optimization contract

New additive command group: `score-fabric optimization`. Query: `evidence --root ROOT --path PATH
--operation summary|findings|count_by_rule|count_by_path|json_summary --rule RULE --file FILE
--line N --offset N --limit N`. Output is a sealed bounded record with raw path/SHA-256/bytes,
exact total, pagination, omitted-field/gap counts and no raw messages. Limit <=30; default 10.
`serve --root ROOT --state PATH` exposes bounded stdio MCP tools; generic shell/read/grep are absent.
`benchmark --output DIR` records five fixture comparisons without provider calls.
`audit --root ROOT` checks 011 spec/task/coverage/implementation artifacts. Exit 0 success,
1 refused/blocked decision, 2 malformed input. No raw input is echoed in diagnostics.

`prepare --request FILE` consumes `optimization_prepare_request`; old/new index references
are checksum-bound and the explicit native-ID/path mapping derives impact, manifest and class.
`context --request FILE` and `govern --request FILE` consume new
`optimized_agent_context_request`/`optimized_agent_admit_request` contracts and validate their
checksum-bound legacy requests before narrowing context/admission. Equivalent entrypoints are
`agent context-optimized` and `agent admit-optimized`. `classify`, `mode` and `skills` consume
the corresponding `optimization_*_request` schemas. They produce records without runtime effects.

The service publishes exact tool input schemas. Finding queries support rule/file/line filters
and offset pagination; `finding_get` returns one row at an offset. Source excerpts require an
explicit path/SHA-256 manifest, at most 250 lines and 3,000 UTF-8 bytes. Observation retrieval
requires an ID and raw-log digest and returns a hint, never accepted evidence. Generic tools
cannot substitute for these operations. A refusal persists a stage stop; restart cannot reset it.

The firewall allows only registered bounded query/retrieval tools for optimized evidence ingress.
Generic read/grep/shell/broad MCP reads are refused rather than pretending native post-hook result
rewriting exists. SOME/IP legacy source reads are narrowed to explicit source/summary paths and
bounded reads; new structured reports use summary records. Existing frozen runs do not change.

Every result has a byte ceiling covering the entire serialized result including references and
metadata. Token estimates are labelled conservative UTF-8-byte upper bounds, not provider usage.
Repeated exact queries and exhausted persistent aggregate budgets refuse further retrieval.
Raw artifact digest bindings also persist across requests and restarts. MCP escaping/envelope
overhead is included in result/stage accounting. Measured shared-storage bindings are checked
before each operation; disconnect or selection drift stops rather than relocating state.
Oversized native identity fields are omitted with explicit counts; identities are never clipped.
Safe path resolution validates every component, including symlinks and output-parent links.

Context/classification/Skill/governor adapters accept sealed records with declared bindings.
Authority comes from 004/005/007 contracts and caller-owned reviewed policy, never from an
optimization record or Skill. Existing admission must be admissible before governor can narrow
it. Missing usage/capability/destination/authority cannot be overridden. Routing uses catalogue
profile IDs supplied by the existing admitted record. Mode plans retain all supplied mandatory
checks and human gates. No plan updates a native gate or launches a model/runtime.

Provider fields remain null for offline fixtures. Offline benchmark estimated-context savings
cannot satisfy live uncached-token/cost acceptance. Runtime configuration is a source-checked
candidate until native activation and hook/service qualification are measured separately.
The pinned native validator accepts the candidate configuration and narrowed agent graph.
Default guard calls without a private qualification instruction refuse every live stage.
Neither a sealed optimization record nor `call_authorized=true` grants execution.
The explicit US12 owner continuation permits a disposable Flash-only experiment, separate
from production engineering authority and default 007 admission.

The private instruction uses `kind=qualification_instruction`, `scope=qualification_only`,
exact owner-message references, workspace/stage/task, current context/governor/role/Skill
bindings, pinned file hashes, run-binding path, Flash aliases, limits, price bounds and
exact task prompts. Its SHA-256 is an operator input to `guard --instruction FILE
--instruction-sha256 SHA`. Private input files must be owned by the operator, without
symbolic ancestors, mode 0600 within private directories and outside the agent workspace.
Private Unix files do not isolate hostile processes sharing the operator account.

For pinned Fabro 1b4fb152, native hook `run_id` is `petri`; tool contexts also omit cwd.
The exact run-specific private host cwd, checked against the process cwd in the CLI,
binds the native API ID. The private run record pins source commit, API run ID, workflow
version and exact native cwd; another cwd, scope, stage or identity refuses. This is
revision-specific measured qualification, not a claim about other Fabro releases.

The loopback transport admits only DeepSeek Flash to its fixed upstream endpoint.
Entire serialized native input and projected provider input each remain <=24,000 bytes,
output <=2,000 tokens, <=10 calls and conservative total reservations <=$0.10. Per-task limits additionally narrow these ceilings to the exact pinned governor;
serialized transmitted input and reserved output accumulate across its requests. A
persistent lock-protected reservation precedes transmission; failed/unknown/in-flight
outcomes stop further requests, including restart. Missing required input/output/cache
usage stops. Optional reasoning usage is retained when explicitly reported; missing
billed cost remains null. Peak source-derived pricing bounds are not actual invoices.
Explicit native run titles prevent unrelated model calls. Only the separate disposable
server holds its one DeepSeek credential; no existing queue or global profile changes.

Optional `tool_projection.allowed_tools` selects registered bounded tool names. The
transport removes only already-denied/unselected function declarations. It preserves all
messages and selected declarations, rejects missing selected tools or unavailable explicit
tool choices and records original/transmitted hashes and sizes. The native guard uses
the same selection. Absence of projection preserves the request byte-for-byte.
The original live measurements predate projection and remain immutable. A separately
authorized second comparison qualifies projection over the same controlled fixture prompts
with equal tool selection; it does not establish real S-CORE engineering acceptance.
The self-audit retains the first result in `development_fixture_live_savings` and the
second in `development_fixture_projection_live_savings`; `live_savings` still denotes
the unmeasured real engineering target, and human acceptance remains pending.

US15 adds an optional `budget_exception` only to private qualification instructions.
Its exact owner statement, current-qualification scope and `qualification:lifecycle-704-`
task/marker prefix are validated before relaxing limits. Aggregate `requests` and
`cost_microusd` may be null only with this exception. Technical ceilings stay finite:
128,000 bytes, 8,192 output tokens, three calls per task. Its explicit operational limits
supersede this qualification's pinned governor ceilings only after that governor's digest,
admissibility and non-authorizing status are verified. Default governor and global policy
remain unchanged. Reservations, usage, costs and persisted stops remain mandatory; an
exception never resets an old ledger or grants engineering acceptance. The user statement
and scope are recorded in ../deepseek-budget-exception.md.

Raw transport artifacts now use `provider-records/<instruction-sha256>/` and exclusive
creation. Distinct instruction ledgers may each use ticket zero without collision.
A duplicate artifact refuses before forwarding; it never replaces old evidence.
The US15 legacy collision and missing envelopes are explicitly retained as limitations.

## Paired runtime binding extension (US19)

A private, checksum-pinned operator binding identifies run, arm, exact worker cwd,
source archive/full file hashes, context/native IDs and candidate write/delete sets.
Mutable execution state remains private on internal storage. This is a local integrity
boundary for the owning user, not isolation from that same user or authenticated native
engineering evidence. The source initializer rejects links, duplicate paths, unsupported
archive entries and unexpected files. Completed response receipts must pin the raw
response and stage identity; application validates the structured `agent_result` and
exact source scope before mutation. One correction requires fresh failed checks.
Collectors execute operator-selected commands in a fresh candidate copy, pin tool
bytes and command plans, monitor storage and retain raw output. Prior XML, model
self-checks or logs are never fresh measurement. Native scope/classification remains
unknown; provider admission is separate and remains closed.

### Measured native API checkpoint metadata (US20)

The pinned native API initializes `.git` before command execution. An explicit
`native_git` binding is valid only for an exact native Fabro worker: its Git config
SHA is pinned, HEAD must name `fabro/run/<run_id>`, metadata links/special files and
active hooks are refused. Only that checked `.git` directory is excluded from the
native source inventory; all other source files remain fully hashed. The native
checkpoint source disables hooks for every Git command. Local disposable workers
cannot claim this exclusion. Runtime checkpoint IDs are not S-CORE baseline IDs or
engineering evidence. This exception neither changes write scope nor admits a provider.

## Offline review placement (US21 owner instruction)

Human engineering decisions occur outside Fabro workflows. Current graph packages
export a hash-bound report and terminate; no human/wait-for-approval node or fabricated
answer is allowed. Deterministic refusal of unauthorized/stale/unknown provider or
engineering inputs remains effective, and refusal routes export available evidence.
A successful terminal run attests only workflow/report completion. Reports retain
failed/missing/skipped/stale outcomes, run/arm/worker bindings, candidate/source hashes,
commands, raw check/feedback evidence, usage/unknowns, unresolved scope and offline
review questions. Human decisions are separate subject-bound records; no model or
workflow may create an accepted decision. Older graphs with human nodes are historical
evidence and superseded for new execution.

## P704 scope review (US22)

Old/new native queries and source sweeps may establish in-repository build edges,
including added/deleted labels and widened target coverage. They do not establish
external consumer closure, accepted tailoring, native engineering verification
applicability or safety adequacy. Preserve declared native IDs/status/version and
exact source/tool hashes. Failed queries/exports remain failed; a proposed check
matrix cannot become a trusted expected set without separately bound authority.

## Observed response byte binding (US23)

The HTTP boundary binds the complete retained response SHA-256 and byte count to
the observed meter entry. Usage-only observations cannot authorize result capture.
The witness must match the configured stage's instruction SHA/path, task and meter
path, exact response path/bytes, usage and reasoning observation. Missing historical
byte bindings are refused; old evidence is never rewritten to create them. A response
observed for accounting can still fail structured result completion or source scope.
Exclusive receipt creation refuses replay/interrupted capture without overwriting it.
Synthetic local fixtures prove only the exercised transport/result boundary; reported
counts and derived cost bounds remain separate from null actual provider bills.

## Native agent usage and feedback observation (US24)

Actual native HTTP/stage evidence may qualify provider transport, structured result
consumption and source-bound feedback transmission against a local emulator. Require
exact request/response, actual run/arm/cwd, candidate/check/source/feedback bindings and
complete native output/context records; do not infer consumption from routed context
alone. Keep fixture replies and historical patch replay explicit. Pre-tool projections
and refusal hooks cannot be described as exercised tool refusals without an actual visit.

Native usage buckets are disjoint: input plus cache-read/cache-write reconstructs
inclusive prompt tokens; output plus reasoning reconstructs inclusive completion tokens.
Preserve provider cache-miss independently from cache-write. Native catalog costs,
fabric conservative bounds and actual provider bills are separate observations.
Default zero native counters after failed transport do not convert unknown usage to
known zero. Workflow report completion leaves failed/missing evidence and acceptance
pending. Distinct digest encodings of the same source inventory must be named explicitly.


Actual native correction qualification must bind both observed stage responses to the
same worker/context, require failed fresh-check provenance before correction, and permit
at most one correction. New checks bind the correction candidate; correcting a synthetic
oracle cannot fill missing native XML or accept engineering scope. Restarted operator
processes must preserve exclusive receipts, application/collection order and interrupted
stop markers. Explicit stop-marker injection is distinct from a crash during application
and from native Fabro checkpoint resume. Every refusal remains part of offline reporting.

Fresh paired admission drafts must retain public-source/provider freshness, exact native
check proposals and unresolved applicability/roles. An accepted prior patch or budget
exception cannot fill missing native decisions. Bind an offline decision to the exact
reviewed matrix before executable worker/stage/meter instruction preparation.

Both arms may share reversible serialization normalization: retain original source
bytes/hashes and full contracts, preserve all ordered JSON values and every validation
constraint, and transmit a full context digest instead of duplicate bookkeeping. Retain
initial oversized attempts. Reconstructed native-wrapper sizes are not actual transmitted
payloads or provider token usage; require observed preflight and unchanged request guards.
Official model alias documentation is not effective runtime observation or permission
to accept previously unrecognized response models.

Optional request_parameters must be selected explicitly in a SHA-bound private Flash
instruction, not inferred from task class or installed skills. Accept only the complete
non-thinking JSON profile: thinking.type=disabled, reasoning_effort=none and
response_format.type=json_object. Partial/expanded controls and other providers/models
are refused. Instructions without the field keep existing behavior. Preserve source
messages, model/output limits, stream and tool-selection constraints. Added projection
bytes count before reservation; the raw request ceiling still applies before projection.

Actual native payload captures, local projection and effective upstream transmission
are separate evidence. Preserve original wrappers/parameters; successful report/exit
after a deliberate local refusal supplies no candidate, provider usage or engineering
acceptance. Qualify every dynamic stage envelope; implementation headroom does not
prove correction/review fit. Native offline scope/role/QNX inputs remain mandatory.

Dynamic correction/review envelope drafts must independently bind exact worker bytes,
candidate/application identity, complete source inventory, check-file SHA/status and
feedback/current-source hashes. Correction requires a failed current candidate/check
binding; review must preserve failed/missing/skipped states. Historical synthetic
inputs qualify protocol only and cannot satisfy current real-trial freshness.

Measure whole stage payloads, including native wrapper/tool projection and candidate
content. Implementation preflight does not prove dynamic-stage fit. Oversize envelopes
export refusal evidence and terminate; complete artifacts, checks and limits remain.
Local capture guards are distinct from production meter reservation and engineering
admission. Bounded source retrieval requires its own actual native delivery, per-result
and aggregate accounting before live use.

### Stage source snapshots (US29)

`optimization serve --stage correction|review --stage-manifest PATH
--stage-manifest-sha256 SHA256` selects a pinned stage_retrieval_manifest. This mode
cannot combine --sources and advertises only get_source_excerpt. Required artifacts
(binding/candidate/checks/feedback) and original/candidate file references contain
path, sha256 and bytes. Candidate files exactly cover the worker write set; original
files match its baseline inventory. All are revalidated before delivery. Excerpts
carry manifest/stage/candidate/check/feedback pins and raw source hashes. Changed
snapshots require a new stage/budget; sealed records create no authority. Existing
250-line, 3,000-byte excerpt, escaped 5,000-byte result and 12,000-byte aggregate
bounds apply. Provider RequestMeter independently limits every complete message
history and total stage requests/input/output. Offline reports retain native missing
or failed evidence and engineering acceptance pending.


### Complete tool exchange and final candidate capture (US30)

A stage with multiple observed replies must preserve every observed request/response,
usage and instruction pin. All prior replies must end in complete bounded tool calls;
an earlier complete candidate or an incomplete tool turn makes final selection invalid.
The following request must contain the unchanged previous message prefix, the exact
completed assistant tool calls and one exact sealed source result per call identifier.
Only instruction-selected get_source_excerpt calls may participate. Resolve the view
within the bound workspace and validate its complete source/check/feedback manifest
against the live protected worker binding, current candidate and latest check SHA.

Capture only the final complete structured reply. Unknown/reserved usage, conflicting
records, substituted conversation/results, stale worker/source/check bindings and
truncated final output refuse before candidate application. Direct application validates
the same witness chain. Exclusive receipts, one-correction scope and interrupted/replay
protection still apply. Fresh post-correction collection binds the new candidate and
source inventory; an advisory review uses the exact new feedback and cannot accept
engineering decisions. Keep command records complete outside conversation; concise
artifact references in native command output may remove duplicated bookkeeping.
Synthetic usage/counts do not measure live full-candidate output-token feasibility.

The pinned native codec may omit null assistant content in a tool-only turn; allow
only this exact absent/null equivalence. Other message/result substitutions refuse.
A direct receipt cannot select an earlier complete reply when a later stage ticket
exists. Namespace each fresh collector directory by its full worker binding SHA so
same-arm repetitions retain separate immutable measurements. Native continuation
following a length-truncated reply remains subject to the same full-request guard;
a stopped meter refuses capture even when the incomplete reply has known usage.


### Offline admission review subjects (US31)

Review byte pins establish provenance only. Verify exact proposed check/profile/label
identities and genuine native ID/status fields without treating unchanged exports as
closed source impact. Keep discovered checks, historical execution and newly collected
results separate. Native scope/role/independence decisions require their own subject-bound
human record; prior local patch approval and model/budget authority do not fill them.

A decision template may prefill exact subject hashes while remaining unreviewed and
unaccepted. Drafting preferences are distinct from applicability acceptance. Copy a
sealed template into a separate decision record before entering a human decision;
never edit the sealed evidence packet. Known-path QNX metadata checks establish neither
archive authenticity nor license eligibility. Native request/candidate qualification
with synthetic bytes creates no real trial instruction, native acceptance or savings.


US32 Linux dependency measurements preserve the pinned source and public dependency
identities and explicit QNX skip. Network isolation and native fetch guards are
operational probe controls, not native applicability waivers. Loading/analysis/cache
results cannot satisfy compilation, execution or human acceptance. No substitute SDK,
unverified checksum, automatic scope acceptance or new live-stage instruction is produced.


US33 metadata mirrors serve exact captured public index bytes bound to URL/digest,
never invented package or SDK content. Explicit downloader controls and network
isolation constrain probes without silently changing native applicability. Missing
metadata, denied downloads and cache drift remain failures. No source/lockfile,
checksum, live instruction, trusted review decision or publication is synthesized.

US34 preserves complete prepared metadata as an immutable native input and distinguishes
metadata delivery, repository availability, archive integrity and extraction. A native
cache hit followed by filename rejection remains failed extraction. A configured archive
route without an observed request or successful extraction remains unqualified. Exact
registry source declarations bound by native lock hashes may identify missing public
archive/patch inputs; their existence does not establish acquired bytes or dependency
closure. QNX skip/download denial and offline acceptance boundaries remain unchanged.

US35 binds exact public module source/archive/patch inputs to unchanged native registry
and lock identities. Captured input manifests are immutable per probe. Byte delivery,
integrity, completed repository markers, package loading and configured analysis are
distinct predicates. Incomplete extraction remains explicit despite successful HTTP.
A direct target query accepts no configured/native verification scope. Additional testing
dependency pins require their actual source bindings; missing inputs and exhausted
stages export reports and terminate with engineering decisions pending offline.

US36 binds Bats source dependencies through the original native module archive and
checksum declarations. Existing release-checksum metadata may bind future tool inputs
only through exact original extension attributes. Cached binary existence and matching
checksums supply neither current input admission nor execution/engineering acceptance.
Mirrors must distinguish attempted status/bytes from completed response writes; retain
old unknown delivery and runtime mismatch records. Corrected Python/tool bindings and
completed native repository markers remain separate from configured analysis/build/tests.

US37 binds cached Linux Buf executables through the original native extension attributes,
checksum-list bytes and wrapper/module source. Cache import, completed HTTP writes, native
repository markers/executable hashes and actual execution remain separate measurements.
An observed compiler archive outside the declared input scope stops the bounded stage;
missing cache payloads/sizes/licenses do not become accepted compiler readiness. Native
source/locks stay unchanged, QNX is skipped and engineering review occurs offline.

US38 treats release-reported size/digest, acquired payload SHA-256, archive inventories/
notices, completed transport, native materialization and configured analysis as separate
predicates. A remounted volume receives fresh read-only input bindings; old workspace
records stay unchanged and no queue is resumed or migrated. Linux compiler acquisition
uses an explicit new bounded stage, not unused US37 attempts or zero-byte missing-input
subtotals. Payload notices never establish accepted licensing/tool qualification.
Unlisted dependencies/QNX remain denied; native scope and engineering acceptance stay
pending offline even if analysis passes.

US39 retains a missing release-asset digest as null and verifies the acquired Linux
Coreutils payload with the checksum bound to original native registry/module/wrapper
bytes. Source-license and actual payload-notice measurements stay separate. Only the
one selected public archive enters a fresh finite allowlist; native source/locks,
historical storage/queues, QNX skip and offline engineering acceptance are unchanged.
Transport, executable hash/mode, repository markers and configured analysis remain
separate predicates; unlisted inputs stop the stage before scope widening.

US40 extends the fresh exact-input allowlist only to the pinned Linux GCC package.
Release metadata/digest, acquired hash, actual payload notices, repository loading and
configured analysis are separate predicates. The inherited native QNX license-path
attribute is source metadata; do not read that path or infer QNX applicability. An
unconfigured package query measures native cache extraction before configured analysis.
Unlisted dependencies stop this stage; successful loading never accepts qualification.

US41 verifies standalone Linux jq bytes against original native SHA-384 integrity.
A separately measured SHA-256 supports exact mirror/cache delivery without inventing
native SHA-256 authority. ELF/static strings/source-license findings do not establish
execution compatibility, complete linked-component licensing or accepted qualification.
Only the selected binary enters the fresh allowlist; unlisted dependencies stop analysis.
Native repository loading and configured analysis remain separate measured predicates.

US42 preserves BSD tar historical native URL/checksum and canonical release URL as
separate provenance fields. Original SHA-256 verifies acquired bytes; builder/source
licenses and static binary findings do not establish complete component licensing,
execution compatibility or qualification. Exact repository loading precedes configured
analysis; unlisted inputs stop the finite stage without source/lock edits or acceptance.

US43 preserves zstd historical native URL/checksum and canonical release URL as
separate provenance fields. Original SHA-256 verifies acquired bytes; builder/source
licenses and static binary findings do not establish complete component licensing,
execution compatibility or qualification. Exact repository loading precedes configured
analysis; unlisted inputs stop the finite stage without source/lock edits or acceptance.

US44 binds OCI objects through the original native image-index digest and exact
linux/amd64 descriptor/config/layer closure, including bounded uncompressed diff-ID
validation. Anonymous acquisition tokens exist in memory only, without SSD/log storage.
Native probes use original-source-supported OCI_GET_TOKEN_ALLOW_FAIL after preserving
local token denial; exact cached/mirrored public objects do not qualify live native
registry authentication. No fabricated token, tag substitution, native source/lock edit,
image/container execution, build/test or engineering acceptance follows.
