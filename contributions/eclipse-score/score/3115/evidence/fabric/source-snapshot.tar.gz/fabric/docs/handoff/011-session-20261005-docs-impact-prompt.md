Continue increment 011 autonomously in /home/jefferson/s-core_sw_fabric.

Resume the existing persistent Goal if supported; create it only if none exists:
complete increment 011 against its specification and acceptance requirements, with
verified evidence and preserved engineering boundaries. Do not mark it complete
while required evidence or acceptance remains missing.

Read AGENTS.md, .specify/memory/constitution.md, active011 spec/plan/tasks/acceptance,
docs/handoff/000-to-001.md and the latest verified checkpoint:

docs/handoff/011-session-20261005-docs-impact.md
docs/handoff/011-session-20261005-docs-impact.json

Verify snapshot, immutable subjects, source/runtime/large payloads and fresh shared
storage identity before continuing. Prefer a newer verified handoff if one exists.
Current prerequisite: compatible disposable Linux execution for exact original
Ferrocene/LLVM coverage tools. The final B3 probe fails at GLIBC2.36/2.38/2.39 and
GLIBCXX3.4.32 versus host glibc2.35. Exact library/dynamic metadata and proposed
unstarted finite successor limits live under:

specs/011-change-impact-and-freshness/evidence/t033-docs-impact/next-prerequisite/

Prepare measured compatible cached/public Linux inputs under a fresh bounded stage;
do not repeat the unchanged host coverage probe, replace native tools, alter global
libraries/storage or weaken original coverage scope. Inspect existing cached OCI
inputs first, but do not assume compatibility. Necessary disposable test containers
are authorized; private daemon state stays internal. Continue successive dependencies
without another go, preserving failed and partial results.

Both original and approved candidate now have equal94-target scoped reverse sets and
134/137 native loadfiles (macro plus two Skylib additions). Full//... closure remains
QNX-blocked; QNX stays skipped. Native source-to-need/work-product denominator and
accepted applicability remain missing. Carry prior113-case native checks per arm,
profiles/runfiles/tar and223 fabric tests/Ruff/mypy only by exact unchanged bindings.
Prepared distributions are98 wheels plus one locked sdist,252,787,423bytes. Exact
LLVM archive1,938,496,864bytes is in the bound task-local native repository cache,
with inventory/license findings. Native filename-preserving streaming transport
operators are retained under packet/operator-scripts/ and the workspace's
`docs-impact-operators/`. Root helpers are snapshots, not a scheduler or authority.
First-probe actual-operator capture is explicitly incomplete; do not synthesize it.
Use fresh envelope/probe names and stop each probe at its first new/unchanged failure.
B1/B2/B3 technical/oracle work and B4/B5 accepted inputs plus paid budgets remain open.

AUTONOMOUS AUTHORITY

I authorize the remaining reversible technical work necessary for 011: dependency
discovery and preparation, public source/tool acquisition, fabric implementation
fixes, scoped Linux native analysis/builds/tests and necessary disposable test
containers, validation, convergence, benchmark preparation and complete offline reports.

This authorization covers successive dependency stages. Do not stop after each
missing dependency or ask me to say “go” again. Historical single-stage stopping
instructions do not require renewed permission for work covered here. Preserve each
stage’s evidence, declare fresh finite limits for its successor, and continue.

Stay within 011. Do not start 012, publish, push, merge, release, deploy, change global
storage, introduce a scheduler or synthesize engineering decisions.

WORKING METHOD

1. Use Spec Kit to track actual remaining obligations. Add tasks only for demonstrated
gaps. Keep spec, plan, tasks, coverage and acceptance consistent. Completing existing
checkboxes alone is insufficient.

2. Follow the native dependency chain from exact source/lock bindings. Measure cache
availability, provenance, integrity, licensing evidence and sizes before acquisition.
Prefer verified cache reuse. Establish finite request, download, storage, archive,
execution and retry limits before each stage.

3. A newly discovered dependency ends that bounded probe, not the overall task. Preserve
the failure, prepare the next admissible stage and continue without renewed permission.
Do not repeat unchanged failures blindly, silently widen sealed limits, remove mandatory
checks or change native policy to obtain success.

4. Use score-fabric storage and score_sw_fabric.storage. The registered build image should
be 1 TiB; mounting it is authorized if needed. Verify writable Linux capabilities and
fresh volume bindings. Stop on disconnection. Preserve historical bindings, sealed
packets, dirty user work and reference repositories. Keep credentials/private state
internal and ephemeral bearer tokens out of SSD evidence and logs.

5. QNX remains skipped because I have no license. Preserve unresolved applicability
honestly. Keep Spec Kit responsible for fabric development, S-CORE for engineering
semantics/artifacts and Fabro for execution/run state.

6. Run appropriate frozen dependency, Ruff, mypy, pytest, foundation, package and native
checks. Reuse unchanged validation only with exact source bindings and explicit carried
evidence labels. Investigate failures and retain unsuccessful evidence. Avoid redundant
testing and rereading unchanged files.

7. Complete real native validation and prepare the remaining B1–B5 qualification work.
Additional paid provider calls require a fresh explicit provider/model/request/spending
budget; closed historical budgets cannot be reused. Finish all independent authorized
work before presenting one consolidated request for genuinely missing authority or inputs.

8. Preserve T032’s recorded approval and human-owned markers. Human engineering acceptance
stays offline. Never infer acceptance from tests, emulator replies, fixtures, agent
assertions or Fabro success. Do not claim 011 complete while mandatory T033 evidence
or acceptance is missing.

CONTEXT HANDOFF — MANDATORY

Monitor remaining context whenever the interface/runtime exposes it. When it falls
BELOW 20%:

- Stop starting new work.
- Safely finish or terminate owned operations; retain partial results and failures.
- Save a verified Markdown/JSON handoff under docs/handoff/, without modifying sealed packets.
- Save a copy-ready continuation prompt under docs/handoff/.
- Include exact current files, hashes, workspace/storage bindings, completed work, open
  obligations, failures, next commands, authority and budgets in the handoff.
- Carry this entire autonomous authority and below-20% rule into the new prompt.
- Pause any active Goal; I explicitly authorize that conditional pause.
- Return the handoff links and continuation prompt, then end the session.

If remaining context percentage is unavailable, state that limitation rather than
inventing a reading. Use an explicit low-context warning to checkpoint conservatively.

Keep concise progress updates during execution. Otherwise continue until 011’s
completion requirements are verified or only genuine external blockers remain.
For external blockers, finish independent work first, export a concrete review packet
and identify exactly what is needed. Report incomplete status truthfully.

End every final response with “Next step:” and “Recommended model:” as AGENTS.md requires.

VERIFIED RESUME COMMANDS

Use these initial read-only checks; do not execute the old failing probe unchanged:

```bash
export SPECIFY_FEATURE_DIRECTORY="$PWD/specs/011-change-impact-and-freshness"
export PATH="/media/jefferson/11c42dee-73a3-4c2b-ab42-a0440011d9e0/.s-core-build/runs/score-fabric-xxefvd8p/bin:$PATH"
.venv/bin/score-fabric storage status
bash .specify/scripts/bash/check-prerequisites.sh --json --require-spec --require-tasks --include-tasks
```

Read next-prerequisite/readiness.json and proposed-limits.json, then establish a
fresh measured finite runtime-preparation envelope. Preserve manifest/source hashes,
Linux filesystem capabilities, QNX refusal, exact native SHA checks and task-local
no-index pip transport. Use the filename-preserving streaming operator as bounded
transport evidence, not new engineering policy. Save raw native results and exit
with bound offline reports; human acceptance stays pending outside Fabro.
