# Dependency roadmap

Status is indexed from per-increment tasks, not a second task database. Increments 000 and 001
are implemented for review; human owner review remains pending. Increment 001 retains fresh
minimal-consumer native build evidence. Increment 002 is implemented and validated as a bounded draft planner. Increment 003 is implemented with real pinned Fabro conformance; its production execution mapping remains pending owner review. The pinned module_template needs_json and docs_check builds now pass in disposable workspaces.

| Increment | Dependencies | Exit evidence | Current state |
| --- | --- | --- | --- |
| [000 bootstrap-and-discovery](../../specs/000-bootstrap-and-discovery/spec.md) | None | Spec Kit setup, constitution, upstream inventory and compatible locks | Partial: implementation complete, owner review pending |
| [001 native-process-catalog](../../specs/001-native-process-catalog/spec.md) | 000 | Typed native catalogue and source references | Implementation complete for pinned minimal consumer; owner review pending |
| [002 applicability-and-work-product-plan](../../specs/002-applicability-and-work-product-plan/spec.md) | 001 | Required instance plan with justified dispositions | Implementation complete; owner/profile review and source-conflict resolution pending |
| [003 deterministic-workflow-compiler](../../specs/003-deterministic-workflow-compiler/spec.md) | 001, 002 | Generated Fabro graph, source map, invariant tests | Implementation complete; production mapping owner review pending |
| [004 native-artifacts-and-traceability](../../specs/004-native-artifact-traceability/spec.md) | 001, 002 | Native document validation and expected-set trace/impact reports | Implementation complete for fixture profiles; production profiles and full target-owner review pending |
| [005 trusted-evidence-and-human-gates](../../specs/005-trusted-evidence-and-human-gates/spec.md) | 002, 004 | Evidence contracts, approval binding, fail-closed evaluations | Fixture-domain CLI and public old/new offline replay pass 689 tests; 41/42 tasks complete; protected production trust-root pin and owner authority pending |
| [006 fabro-runtime-integration](../../specs/006-fabro-runtime-integration/spec.md) | 003, 005 | Real workflow registration/run/inspect/resume/export | In progress; 39/40 tasks complete; disposable candidate register/run/status/wait/cancel/export/offline verify executed; same-run checkpoint resume unavailable on candidate (T025 open); runtime selection and 005 production authority pending |
| [007 apm-agent-context-and-profiles](../../specs/007-apm-agent-context-and-profiles/spec.md) | 000, 004, 006 | Pinned context/tool integration and bounded role execution | Implemented for disposable use; 21/22 tasks; real pinned MCP discovery/setup/context/check and catalogue-based admission; owner review of lock and draft role/model/budget profiles pending (T022); no live model call |
| [008 component-safety-feedback](../../specs/008-component-safety-feedback/spec.md) | 004, 005, 006, 007 | Real component FMEA/DFA draft/review/mitigation loop | Implemented for fixture demonstrations; 19/20 tasks; DEMO-02/03 checks, feedback loop, packet and separate gates; no eligible human decision (005 T009); owner review of safety profile and analyst roles pending (T020); no model call |
| [009 design-implementation-and-unit-verification](../../specs/009-design-implementation-and-unit-verification/spec.md) | 004, 005, 006, 007, 008 | C++17 demo design/source/tests with baseline-bound local results | Implemented for fixture demonstration; 17/18 tasks; owner review of verification and local toolchain profiles pending; protected 005 evidence unavailable |
| [010 misra-quality-and-deviations](../../specs/010-misra-quality-and-deviations/spec.md) | 005, 009 | Real quality-tool adapter, extraction checks, reviewed deviation route | Local adapters, native import/extraction, draft/correction history, fixture decision replay, guideline coverage, portable review packets, independent compliance blocker assessment and candidate installed context implemented; 88 tasks, 77 complete, 11 open; unknown denominator/manual gaps and zero accepted claims preserved; CodeQL prerequisite inspection, imported disposition context and fixed public native demonstrations implemented; eligible execution and engineering authority pending; ASan and full selected validation pass in the normal terminal; restricted sandbox remains incompatible |
| [011 change-impact-and-freshness](../../specs/011-change-impact-and-freshness/spec.md) | 004, 005, 008, 009, 010 | Transitive impact, stale-evidence rejection, bounded re-analysis and context containment | Local implementation and scoped native guard/service qualified; fixture projection measured 66.32–66.60%; T032 subjects and exact lifecycle #704 patch/advisory locally approved; native Flash implementation passes 113 cases; local PR, benchmark plan and paired no-provider packages prepared; protected local worker/result/collector APIs and wired graphs qualified with two 113-case replay checks; actual API worker/feedback routing and offline report/exit runs qualified with zero provider requests; human review outside workflows; P704 native export/docs checks and 135-label inventory measured; QNX dependency closure/accepted impact scope pending; local synthetic JSON/SSE observed-meter response/usage capture qualified; actual native agent response and exact fresh-feedback consumption qualified against a local emulator; actual native bounded correction and restarted-operator replay/interruption refusals qualified with synthetic replies; fresh P704 admission/check-scope packet and equal prompt serialization prepared; actual native implementation payload and pinned non-thinking JSON projection qualified with fresh regressions; full-input correction/review envelopes bound and actual native context-limit refusals measured; pinned stage source retrieval and actual native MCP consumption/context refusal qualified; verified complete bounded fixture correction/application, fresh checks/advisory review and native truncation-continuation refusal qualified; live full-output feasibility pending; offline native admission review verifies source CI/export identities and prepares explicit scope/QNX/role decision subjects; isolated Linux dependency probes retain cold/warm cache failures and unresolved Python index metadata, with QNX execution skipped; 68 public metadata pages prepared, original 67-page failure cleared and native QNX/unlisted download denial verified; all 68 metadata pages consumed in four pinned Linux analysis probes without misses; fifteen exact public module inputs prepared, seven module repositories materialized and five pilot packages load successfully; exact Bats archives prepared, both core aliases and Kotlin repositories completed; corrected Python 3.12 mirror qualifies explicit response completion; three exact cached Linux Buf tools and Go rules now materialize; three exact Linux Ferrocene compiler/coverage/Miri payloads now acquired and verified (289,823,045 bytes), both generated Linux repositories complete and 26 compiler notices retained; fresh bindings preserve old records after remount of the owner-confirmed 1 TiB image; exact Linux Coreutils 0.1.0 archive now acquired (4,819,217 bytes), actual license retained and independent native repository query/hash/mode qualified; configured analysis remains failed at the pinned Linux GCC 12.2.0 package, with original-lock/source/release hash, reported 157,834,687-byte size, inspected-cache absence and exceeded current acquisition bounds recorded for the next stage; native scope/QNX/roles unaccepted; live admission and complete B1–B5 qualification/native acceptance pending; publication deferred; latest isolated runtime qualifies pinned LLVM coverage and real B2 allocation/B3 mutation witnesses; docs export awaits cached Aspect unpack preparation; accepted native denominators and real paired trials remain open |
| 012 feature-and-component-integration | 008, 009, 010, 011 | Multi-component feature chain and integration evidence | Backlog |
| 013 security-lifecycle | 005, 007, 011, 012 | Applicable security branch and cross-domain impact | Backlog |
| 014 module-evidence-and-readiness | 010, 011, 012, 013 | Module reports/packages/manuals and scoped readiness | Backlog |
| 015 platform-integration-readiness | 014 | Reference integration baseline and platform evidence boundary | Backlog |
| 016 overnight-and-recovery-hardening | 006, 007, 011, 014 | Restart/budget/idempotency/terminal-handoff scenarios | Backlog |
| 017 assurance-and-portable-validation | 010–016 | Negative-test suite, end-to-end evidence, Fabro-free verification | Backlog |
| 018 upstream-packaging-and-handoff | 015, 016, 017 | Installable package, supported-version documentation, upstream proposal | Backlog |

Milestones: M0=000; M1=001–005; M2=006–009; M3=010–011; M4=012–014; M5=015–018.
M2 is a component slice, not release readiness. Native export proof belongs to 001;
Fabro version selection must resolve before 003/006; protected approvals before 005 live
acceptance; model capability/budgets before 007 live work; CodeQL eligibility before 010.

Architecture: [ADRs](../architecture/README.md). Requirements: [FAB index](requirements-index.md).

### 011 US40 exact Linux GCC follow-up — 2026-10-05

T139–141 measure exact pinned GCC package acquisition/notices, independent native
repository loading and configured Linux analysis. GCC loading passes; analysis stops
at unlisted Linux jq 1.7. [Complete offline evidence](../../specs/011-change-impact-and-freshness/evidence/t033-gcc-linux/review-report.md)
retains finite bounds, unchanged subjects, fresh checks and pending human acceptance.
The next bounded action is source-bound jq preparation; native/live scope remains incomplete.

### 011 US41 exact Linux jq follow-up — 2026-10-05

T142–144 measure jq native SHA-384 integrity, standalone binary/static/source-license
provenance, independent native loading and configured Linux analysis. jq loading passes;
analysis stops at pinned BSD tar. [Complete offline report](../../specs/011-change-impact-and-freshness/evidence/t033-jq-linux/review-report.md)
retains finite bounds, URL migration/refusal evidence, preservation and pending acceptance.
The next bounded action is exact BSD tar preparation; native/live scope stays incomplete.

### 011 US42 exact Linux BSD tar follow-up — 2026-10-05

T145–147 measure BSD tar checksum/source-license/static binary provenance, independent
repository loading and configured Linux analysis. BSD tar loading passes; analysis stops
at zstd with an interrupted GCC response retained. [Complete report](../../specs/011-change-impact-and-freshness/evidence/t033-bsdtar-linux/review-report.md)
preserves unknown transfer/public metadata and finite-budget stops. The next bounded
action is exact zstd provenance/preparation under a fresh metadata budget.

### 011 US43 exact Linux zstd follow-up — 2026-10-05

T148–150 prepare verified native-bound zstd and measure separate repository loading and
configured analysis. Repository loading passes; Linux analysis stops at the Docker Hub
token endpoint for the original pinned Debian test-runtime OCI image. [Complete report](../../specs/011-change-impact-and-freshness/evidence/t033-zstd-linux/review-report.md)
retains unknown object/transfer sizes, exact native pins, finite stops and offline acceptance.
Next inspect exact native-pinned OCI metadata/cache closure under fresh bounds.

### 011 US44 original-pinned Debian OCI follow-up — 2026-10-05

T151–153 prepare verified cache-only Debian linux/amd64 objects, diff-ID-bound static
inventory/notices and separate native repository loading/configured analysis. [Complete report](../../specs/011-change-impact-and-freshness/evidence/t033-debian-oci/review-report.md)
records completed alias/platform loading and the next original-pinned score_cpp_policies
0.1.1 archive failure. Current HTTP/token acquisition remains unused; acceptance remains
offline. Next measure exact pinned policy archive/cache/source-license/size provenance.

011 native follow-up: equal 94-target scoped reverse closures and three added
loadfiles are measured in specs/011-change-impact-and-freshness/evidence/t033-docs-impact/review-report.md.
Full closure remains QNX-blocked; B3 LLVM coverage requires a compatible disposable
Linux runtime for pinned Ferrocene tools. T154/T156 and T033 remain incomplete.

011 native docs follow-up: [bound export report](../../specs/011-change-impact-and-freshness/evidence/t033-aspect-export/review-report.md)
records original/candidate export success and unchanged 144/1251/916 native records.
Pinned public tools and refusals are retained; native expected sets, producer support,
B1-B5 qualification and offline T033 acceptance remain incomplete.

011 producer follow-up: [bound report](../../specs/011-change-impact-and-freshness/evidence/t033-producer-contract/review-report.md)
measures changed native metamodel and proposed explicit producer admission, plus eight
passing B3 cases and one failing mutant case. T159 remains unbuilt; T033/native/live
acceptance and complete engineering inputs remain open.
