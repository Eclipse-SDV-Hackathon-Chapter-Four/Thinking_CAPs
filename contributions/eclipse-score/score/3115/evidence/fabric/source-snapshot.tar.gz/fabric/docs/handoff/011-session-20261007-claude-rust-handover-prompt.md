# Prompt for Claude

You are taking over my Eclipse S-CORE Rust workflow and issue queue. Work from `/home/jefferson/s-core_sw_fabric`. Continue the technical review and prepare concrete next actions from the saved evidence. Preserve all existing work, source-correction limits and failures. This handover does not authorize extra source corrections, publication or a change of model for native Fabro runs.

## Read these first

Read only relevant sections and keep output bounded:

1. `AGENTS.md`, `.specify/memory/constitution.md`, the active `specs/011-change-impact-and-freshness/` spec/plan/tasks, and `docs/handoff/000-to-001.md`. Historical first-session stops are superseded only by the recorded subsequent user authority; do not infer authority for unrelated fabric development.
2. `docs/handoff/011-session-20261007-rust-queue-bounded-results.md`, its JSON and `-binding.json`.
3. `docs/handoff/011-session-20261007-rust-recovery-review.md` and its `-binding.json`.
4. `.agents/skills/score-rust-workflow/SKILL.md`; load its references only as needed.

Verify the handoff hashes before relying on them. The newest verified handoffs take precedence over older running/paused handoffs. Report any inconsistency rather than guessing or resetting counters.

## Objective and completed work

The objective was to implement a generic Rust issue workflow suitable for S-CORE, then process communication Rust issues through a supervised Fabro queue, excluding QNX issue #1278. The generic skill is implemented and installed. All 13 selected issue runs have been collected. No run is active, and all newly owned Fabro/Docker services are stopped. Not all issues are solved.

Native source baseline: `381d43dec900ab6a9076f3f30e7bfbdee019e26e`. Do not silently rebase or treat changes on current upstream main as implementation evidence for this baseline. Saved issue snapshots describe the retrieval date, not necessarily today's GitHub state.

- #250: proposed typed-wildcard implementation passed six selected Linux groups, 68 actual child cases, with two ignored doctests. Five library Clippy reports retain four warnings. System-wide scope, ownership, API/ABI, qualification, trace and human acceptance gaps remain.
- #560: a separately authorized Codex correction passed five selected Linux groups and 14 actual cases, with two Clippy warnings. Engineering applicability, trace and acceptance remain open.
- #173: assessment refreshed, including 39 passing actual cases and two ignored doctests; qualification/adoption decisions remain open.
- #1265: historical assessment contribution completed and pushed under earlier specific authority. That authority does not extend to new packets.
- #1261: a concrete heterogeneous LoLa stream/backend was drafted, but the final attempt failed compilation. No tests executed. A recovery review is available.
- #1264, #1263, #794, #781, #782, #1062, #741 and #490: unresolved assessments or partial drafts with exhausted source allowances. Use the JSON and original packets for exact per-issue dispositions.

Passing selected tests, a clean analyzer or Fabro lifecycle success never establishes human engineering acceptance or issue closure.

## Correction limits and model authority

These limits persist across this handover:

- #1261 and #250: **3/3 source corrections used; zero remaining. STOP further source fixes.** The other exhausted issues must also remain stopped.
- Original queue: **35/36 used**. Its only remaining original slot belongs to #173 (2/3 used). The assessment is already refreshed; no concrete defect currently justifies spending that slot or repeating tests.
- Separate extra #560 allowance: **1/3 used, two remaining, scoped to Codex corrections for #560 only**. Lifetime #560 source corrections are four, including the original three. Do not transfer this allowance to another issue or assume Claude inherits Codex-specific source-edit authority.
- Generic “go” or “resume” does not reset, expand or transfer these limits.

My preference remains **DeepSeek Flash only for native Fabro agent runs**: provider `deepseek`, actual model `deepseek-v4-flash`, alias `deepseek-flash`, no fallbacks. Claude's role in this handover is technical analysis and reporting outside Fabro. Do not replace the native run model with Claude or launch new paid runs from this prompt.

Proceed autonomously with read-only diagnosis and review artifacts. If useful implementation work requires changing an exhausted allowance, make the proposed change and required checks concrete in a plan, without applying it. Explain that execution would require explicit new authority because of my three-correction limit. Do not ask for permission before doing the permitted review work.

## Evidence locations

Contribution root: `/home/jefferson/eclipse_sdv_hackathon_2026/contributions/rust-api-queue/`.

Relevant directories beneath it:

- `score-rust-stream-final-hdmk9onj-results/`: failed final #1261 candidate, full 26-file baseline patch, changed sources, raw Linux evidence, reports and 105,315 complete native events. 152 payloads; manifest SHA-256 `7d8fe372bd1e86f3835879c57d703be8bedddea429e0e7a86e426a5ef0942a44`.
- `score-rust-stream-final-hdmk9onj-final-review-supplement/`: final delivered Codex review. The first complete review was sealed before its last transport note was added; this immutable supplement preserves the final delivery and exact diff without altering the base packet. Six payloads; manifest SHA-256 `83491afe50a22c9b1b0c9d38c0364e1004f16333183afda9e8077283ab76d14d`.
- `score-rust-stream-final-hdmk9onj-recovery-review/`: `recovery-plan.md`, `acceptance-matrix.json` and verified input bindings. Four payloads; manifest SHA-256 `57c7b0d9616dd96de7bf4cca78e65180d8c6915bd3756c2d28d38af84604ca03`.
- `score-rust-stream-u96hjh42-results/`: preserved failed preceding #1261 source attempt.
- `score-rust-250-final-fcuqf3or-results/`: final #250 proposal and selected passing Linux evidence.
- `score-rust-560-codex-eppa905r-results/`: #560 correction and selected passing evidence.
- `score-rust-resumed-67y5042v-results/`: #173 assessment refresh and explicitly labelled carried evidence.
- `score-rust-issue-queue-ycbvxir7-results/`: all 13 original terminal issue packets and original failure history.

Use the handoff JSON for other manifest digests. Sealed packets are immutable. Verify relevant input hashes before reusing evidence; label carried evidence explicitly. Do not repeat unchanged checks without a changed subject or unresolved concern that actually justifies the check.

## #1261 diagnosis to investigate

Read the final delivered Codex review before proposing changes. The measured compiler failure is `runtime.cpp:355: expected unqualified-id before '{' token`: the candidate removed the `Runtime::MergeAdditionalConfiguration(...)` definition signature while inserting wildcard enumeration.

One of four selected command groups ran and failed, with zero of five test targets executed. The other three groups did not run. Zero SARIF reports means analyzer cleanliness is unknown. The dedicated heterogeneous integration was unselected because the agent wrote `score/mw/com/test/basic_rust_api/regression-plan.json`, while the collector expects `.rust-queue/reports/regression-plan.json`. Do not create or move that plan and rerun the sealed candidate under the exhausted allowance.

Further findings include an unbounded notification queue, retained callback state, deferred native cleanup, an order-dependent HashSet unit assertion, weak integration assertions and a configured-only discovery universe narrower than the issue's system-wide criterion. Potential Rust application trait/import/type-inference defects are static concerns, not measured compiler diagnostics. A one-line compilation repair would not solve the issue. The recovery plan maps all four issue acceptance criteria to concrete work and missing evidence.

The earlier DeepSeek attempt failed on malformed replay of a reasoning-only assistant after a queued follow-up. The final attempt supplied all context initially and used no runtime follow-up. No provider codec repair or output-limit cause is established. Preserve exact failures and distinguish historical error text in imported context from actual runtime events.

## Working boundaries

- Preserve user changes and reference repositories. Native edits/builds belong only in disposable copies; inspect hooks and executable build configuration first.
- Use `score_sw_fabric.storage` / `score-fabric storage` for new disposable workspaces, builds and scratch. Prefer the measured writable external SSD/Linux image; explicit contribution destinations remain authoritative. Bind an active workspace to its volume and stop on disconnection rather than relocating it.
- The recorded Linux image is mounted at `/media/jefferson/11c42dee-73a3-4c2b-ab42-a0440011d9e0`; backing SSD UUID is `002B-CE31`. Validate availability before dependent work. Keep credentials and private server state internal. Do not change global caches/storage, migrate queues or restart sealed runs.
- Never rerun create/start/collector/finisher scripts for completed runs. Do not signal stale PIDs or alter global services.
- Keep engineering review outside Fabro workflows. “Offline” means outside automation, not without internet. Agents recommend; deterministic tools measure; authorized humans decide. Do not fabricate acceptance or native requirement IDs.
- No new commit, push, PR, issue comment/closure, merge, release or deployment is authorized. Preserve license notices and native statuses. Do not expose credentials.
- Follow repository validation requirements if separately authorized fabric source changes occur; this handover itself calls for review, not fabric implementation.

## First deliverable

Give me a concise, evidence-backed status for all 13 issues. Then independently assess the existing #1261 recovery plan: confirm measured blockers, distinguish static concerns from executed failures, identify the smallest technically complete recovery scope, and separate straightforward repairs from architecture/ownership decisions requiring human review. Prefer the saved evidence over speculative fresh runs.

Save useful new review material as a separate, hash-bound contribution without modifying sealed packets. Report exactly what you reviewed, unresolved obligations, and whether any new authority would be required for the next action. Preserve the active goal and counters in a concise verified handoff. Do not apply additional source fixes under exhausted limits.

End repository responses with the required `Next step:` and `Recommended model:` lines from `AGENTS.md`; naming a model must not imply switching this session or changing native run authority.
