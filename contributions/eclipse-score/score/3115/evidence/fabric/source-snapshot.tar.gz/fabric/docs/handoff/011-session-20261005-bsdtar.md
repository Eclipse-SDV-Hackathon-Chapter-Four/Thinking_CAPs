# Increment 011 BSD tar handoff — 2026-10-05

US42 / AC103–105 / T145–147 is complete and sealed. The mission remains incomplete.
Next action: refresh exact native-bound Linux zstd v1.5.6-bcr1 release/cache/source-
license/size provenance with a fresh metadata budget, then prepare its binary with
explicit successor bounds and retry configured Linux analysis. No background continuation
starts; this handoff is not a live provider instruction. Preserve all dirty user work.

Read [AGENTS.md](../../AGENTS.md), [constitution](../../.specify/memory/constitution.md),
[original handoff](000-to-001.md), [jq handoff](011-session-20261005-jq.md),
active [spec](../../specs/011-change-impact-and-freshness/spec.md),
[plan](../../specs/011-change-impact-and-freshness/plan.md),
[tasks](../../specs/011-change-impact-and-freshness/tasks.md),
[acceptance](../../specs/011-change-impact-and-freshness/acceptance.md) and
[complete sealed report](../../specs/011-change-impact-and-freshness/evidence/t033-bsdtar-linux/review-report.md).
Preserve original brief, native source/locks, old handoffs, every sealed packet and exact
reviewed T032/lifecycle #704 subjects. T032/T033 human task markers stay unchecked.

## Latest measured result

Packet: `specs/011-change-impact-and-freshness/evidence/t033-bsdtar-linux`.
Manifest SHA-256: `c309381e081d99d1c9b0fd12ddb7001a84b4c744392edc540e577df0cee217e7`.
It seals **131 files**. Exact large inputs remain on their bound SSD
paths with hash/size references; packet files retain source licenses/patch/provenance,
actual static binary findings, full native outputs/operators, checks and preservation.

The server restarted after source/cache preparation and before acquisition. Recovery
verified completed preparation and inherited hashes without repeating those actions.
The exact **1,774,384-byte BSD tar v3.8.1-fix.1 Linux binary** then passes original
native SHA-256 `fff8f72758a52e60fe82beae64b18e7996467013ffe8bec09173d1ba6b66e490`. One payload request completes without
retry; public release digest/size match native authority. Historical aspect-build and
canonical hermeticbuild URLs remain distinct. Builder commit
`2215f4da9b1beeb288f9e46777a07a4c1513c894`, LICENSE, workflows, MODULE/BUILD/Bazel settings and
libarchive patch are Git-blob/SHA-256-bound. libarchive v3.8.1 COPYING is bound to tag
commit `9525f90ca4bd14c7b335e2f8c84a4607b0af6bdf`. Build reproduction, release attestation
verification and complete linked-component licensing remain unaccepted/unmeasured.

The standalone ELF is 64-bit little-endian x86_64, machine 62, executable type 2,
without PT_INTERP. Two static notice-pattern fragments totaling **28 bytes** are retained
with offsets/hashes; they do not establish full notice coverage, runtime compatibility
or accepted licensing/tool qualification. No help/version/license/payload execution
occurs. The complete set is **35 inputs / 555,965,422 bytes**, including 34 inherited
inputs copied by exact hashes without remote reacquisition.

The independent unconfigured query of
`@@tar.bzl++toolchains+bsd_tar_toolchains_linux_amd64//:bsdtar_toolchain`
passes **0 in 3.724 seconds**, consuming verified cache with zero mirror requests.
Completed marker/generated-file/native executable hash/mode measurements are retained.
The original five-label configured Linux cquery then exits **1 in 9.95 seconds** at
unlisted zstd. **68 metadata responses and 30 of 31 asset responses complete**.
One GCC response is interrupted by client disconnect. Completed response content totals
**407,573,883 bytes**. The mirror's `served_bytes` counter **565,408,570** reserves
response content sizes; it is not actual successfully transferred bytes. Actual bytes
transferred in the interrupted GCC response remain **unknown**, not its declared
157,834,687 bytes. The collector's initial all-completed refusal/operator is retained;
correction keeps true completed/interrupted counts without repeating a native probe.
BSD tar's independent loading remains complete. Source/locks and enabled version warning
stay unchanged; the log reports zero action processes. No configured retry follows.

Fresh frozen sync, Specify 1.0.12 version/prerequisites, foundation, package build,
control whitespace and trace checks pass. Prior 223 tests/Ruff/mypy over 152 source
files are carried by **310 unchanged source/test hashes**; no new source checks run.
**27 old packets / 6,235 subjects**, 740 native originals, 3,484 runtime files, 405 cache
markers and twenty T032 subjects remain unchanged. Including this packet, the chain
contains **28 packets / 6366 subjects**. Owned probes/mirrors close; no private/
provider server or background continuation starts. Tasks are **145/147**, preserving
two human markers and claiming no whole-mission completion percentage.

## Next exact zstd prerequisite

[Readiness](../../specs/011-change-impact-and-freshness/evidence/t033-bsdtar-linux/zstd-readiness.json)
binds original-lock registry source, verified aspect_bazel_lib **2.22.0** module archive
and native wrapper/extensions/license bytes:

- Native URL: `https://github.com/aspect-build/zstd-prebuilt/releases/download/v1.5.6-bcr1/zstd_linux_amd64`.
- Native repository: `@@aspect_bazel_lib++toolchains+zstd_linux_amd64`.
- Version/platform: **1.5.6-bcr1 / linux_amd64**.
- Native SHA-256 literal: `0F0BD1193509A598629D7FA745C4B0B6D5FA6719E0C94C01EF0F20E466D801A7`.
- Normalized digest: `0f0bd1193509a598629d7fa745c4b0b6d5fa6719e0c94c01ef0f20e466d801a7`.

Keep the literal source checksum and normalized digest separate; normalization does
not replace native source authority. The exact inspected historical SHA-256 cache
key is absent, with no machine-wide absence claim. Public release size/digest/canonical
owner metadata is **unqueried**: all sixteen US42 metadata requests were used for admitted
BSD tar provenance. Missing size/combined byte total remain **null/unknown**, never zero.
No zstd binary, actual notices/license/compatibility is acquired/imported/executed or
accepted. Do not infer the canonical owner from BSD tar's migration or substitute host
zstd. Refresh exact public metadata/source-license/size and inspect exact cache keys
under separate successor bounds before acquiring bytes. Keep native source/locks intact.

Adding the binary makes **36 inputs**, outside US42's 35-input allowlist; aggregate
fit is unknown without its size. Do not reuse unused native attempts or silently widen
this sealed stage. Declare fresh input-count/byte/storage/request/probe limits and retain
all actual payload/static/source license findings. Include an independent admitted-repository
query to separate loading from configured failure order. Stop on first unchanged/out-of-
scope configured failure. Preserve interrupted delivery evidence; do not fix it by
repeating a stage whose missing input is still outside its allowlist.

## Storage/tool recovery and standing constraints

Use `score-fabric storage` / `score_sw_fabric.storage` for every new workspace/cache.
The owner confirmed **1 TiB** and authorized mounting the registered ext4 build image.
It remains mounted at `/media/jefferson/11c42dee-73a3-4c2b-ab42-a0440011d9e0`, current
device **1819**, backing SSD UUID **002B-CE31** on exfat. Current workspace:
`/media/jefferson/11c42dee-73a3-4c2b-ab42-a0440011d9e0/.s-core-build/runs/score-fabric-z2e7huiz`. Capacity was reconciled earlier without resizing, repair or reformatting.
Old device-1818 storage records remain unchanged. Re-bind historical same-UUID inputs
read-only by exact hashes instead of rewriting old records or resuming old run state.
Stop on disconnection; do not relocate active work, migrate queues/global storage or
copy credentials/private state. Never write/build in reference repositories.

US42 limits: 35 inputs, 256 MiB/inherited input, 8 MiB/new binary/static read, 1 GiB
aggregate/mirror bytes, one 120-second payload request, sixteen 2 MiB metadata responses,
2 MiB static notice excerpts and 20 GiB free reserve. Zero archive expansion/members.
Three 120-second native attempts permitted; two distinct probes used. Networking is
namespace-local, external hosts denied, real home hidden, only fresh bound scratch
writable. Operators are archived; adapt copies with new exact bindings/limits and keep
originals immutable. Static/source licenses do not accept tool qualification. Retain
upstream Markdown source under text evidence filenames with original hashes, preserving
bytes without treating its relative links as local fabric documentation.

Use Python >=3.12. `.venv` and the retained read-only mirror runtime are 3.12.14; host
Python 3.10 is unsuitable. Verify all 3,484 runtime hashes/current-volume bindings and
set `PYTHONDONTWRITEBYTECODE=1`. Bazel remains 8.7.0, SHA-256
`d7606e679b78067c811096fb3d6cf135225b528835ca396e3a4dddf957859544`.
Native source baseline: `7d1d7bec81d96752b5a9a235044d2dfc3ecd259b`;
archive: `19dbc09f9424ff9d52a9f7ec8b64715c79cba32b4c063e0d41c158d657c5368c`.
Pinned Specify 1.0.12 remains in the recorded SSD tool workspace; set
`SPECIFY_FEATURE_DIRECTORY=/home/jefferson/s-core_sw_fabric/specs/011-change-impact-and-freshness`
explicitly. No extension hooks are registered. Seven reviewer checklist items remain
pending/unchanged. Preserve exact source-bound prior checks and run appropriate fresh
frozen/foundation/package/Spec Kit/trace checks for successor changes.

QNX is skipped because the owner has no license. Do not request SDK/credentials or read
native license-path attribute files; those attributes remain unread source metadata.
Human review is offline outside Fabro workflows, with complete bound reports and no
human/wait nodes or synthetic decisions. Full native expected-check denominator,
transitive impact/work products, reviewer authority, tool qualification and live B1–B5/
T033 acceptance remain pending. PR publication stays deferred and the approved local
contribution destination stays unchanged. This stage made zero paid requests; historical
DeepSeek exceptions do not authorize general successor spending/live stages. Spec Kit
owns fabric development, S-CORE owns engineering semantics/artifacts and Fabro owns
execution/run state. No native compilation/test, SDK, publishing or human decision follows.

[Machine-readable snapshot](011-session-20261005-bsdtar.json) binds current controls,
source/reviewed subjects, evidence chain, workspace and exact next prerequisite/unknowns.
Recommended model: **gpt-6.1-sol (high)** for bounded zstd metadata/license/integrity
inspection and native dependency diagnosis; this recommendation does not switch the session.
