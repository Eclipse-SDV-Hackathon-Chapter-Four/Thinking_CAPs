"""Pinned correction/review source views; engineering acceptance stays external."""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

from score_sw_fabric.optimization.common import (
    OptimizationError,
    checked,
    integer,
    json_object,
    raw_file,
    safe_file,
)
from score_sw_fabric.optimization.paired_runtime import file_set_digest


class StageSources:
    """Revalidate every artifact and candidate file before each excerpt delivery.

    The caller supplies the manifest byte pin from its trusted stage binding. A
    sealed record alone supplies integrity, never execution or engineering authority.
    The view is a snapshot: changed candidates require a new stage and budget.
    """

    def __init__(self, root: Path, manifest: Path, pin: str, stage: str) -> None:
        self.root = root
        self.manifest = manifest
        self.pin = pin
        self.stage = stage
        self.value = self.validate()
        self.sources = {name: item["sha256"] for name, item in self.value["files"].items()}

    def _raw(self, reference: dict[str, Any]) -> bytes:
        if set(reference) != {"path", "sha256", "bytes"}:
            raise OptimizationError("STAGE_REFERENCE")
        integer(reference["bytes"], minimum=1, maximum=1_048_576)
        if safe_file(self.root, reference["path"]).stat().st_size != reference["bytes"]:
            raise OptimizationError("STAGE_REFERENCE")
        data, actual = raw_file(self.root, reference["path"], reference["sha256"])
        if actual != reference:
            raise OptimizationError("STAGE_REFERENCE")
        return data

    def validate(self) -> dict[str, Any]:
        try:
            return self._validate()
        except (KeyError, TypeError, UnicodeError) as error:
            raise OptimizationError("STAGE_MANIFEST") from error

    def _validate(self) -> dict[str, Any]:
        from score_sw_fabric.optimization.common import no_symlinks

        no_symlinks(self.manifest)
        if self.manifest.stat().st_size > 131_072:
            raise OptimizationError("STAGE_MANIFEST")
        data = self.manifest.read_bytes()
        if hashlib.sha256(data).hexdigest() != self.pin:
            raise OptimizationError("STAGE_MANIFEST_DRIFT")
        value = checked(json_object(data), "stage_retrieval_manifest")
        if (
            set(value) != {"kind", "schema_version", "digest", "stage", "artifacts", "files"}
            or self.stage not in {"correction", "review"}
            or value["stage"] != self.stage
            or set(value["artifacts"]) != {"binding", "candidate", "checks", "feedback"}
            or not isinstance(value["files"], dict)
            or not 1 <= len(value["files"]) <= 32
            or sum(
                integer(ref["bytes"], minimum=1, maximum=1_048_576)
                for ref in value["files"].values()
            )
            > 8_388_608
        ):
            raise OptimizationError("STAGE_MANIFEST")
        artifacts = {
            name: checked(json_object(self._raw(ref)), kind)
            for name, kind in {
                "binding": "paired_worker_binding",
                "candidate": "paired_candidate_applied",
                "checks": "paired_fresh_checks",
                "feedback": "paired_feedback",
            }.items()
            for ref in [value["artifacts"][name]]
        }
        binding, candidate, checks, feedback = (
            artifacts[name] for name in ["binding", "candidate", "checks", "feedback"]
        )
        if (
            candidate["binding"] != value["artifacts"]["binding"]["sha256"]
            or checks["binding"] != candidate["binding"]
            or checks["candidate"] != candidate["digest"]
            or feedback["candidate"] != candidate["digest"]
            or candidate["source_digest"] != checks["source_digest"]
            or feedback["source_digest"] != checks["source_digest"]
            or feedback["checks"]["sha256"] != value["artifacts"]["checks"]["sha256"]
            or feedback["checks"]["bytes"] != value["artifacts"]["checks"]["bytes"]
            or feedback["status"] != checks["status"]
        ):
            raise OptimizationError("STAGE_EVIDENCE_BINDING")
        if self.stage == "correction" and (
            candidate["stage"] != "implementation" or checks["status"] != "fail"
        ):
            raise OptimizationError("CORRECTION_WITHOUT_FAILED_CHECKS")
        hashes: dict[str, str] = {}
        for name, reference in value["files"].items():
            safe_file(self.root, name)
            if reference["path"] != name:
                raise OptimizationError("STAGE_REFERENCE")
            self._raw(reference).decode("utf-8")
            role, separator, native = name.partition("/")
            if not separator or role not in {"original", "candidate"}:
                raise OptimizationError("STAGE_REFERENCE")
            expected = (
                feedback["current_sources"] if role == "candidate" else binding["source_files"]
            )
            if expected.get(native) != reference["sha256"]:
                raise OptimizationError("STAGE_CANDIDATE_SOURCE_DRIFT")
            if role == "candidate":
                hashes[native] = reference["sha256"]
        if set(hashes) != set(binding["write_paths"]) or hashes != feedback["current_sources"]:
            raise OptimizationError("STAGE_CANDIDATE_SOURCE_DRIFT")
        inventory = dict(binding["source_files"])
        inventory.update(hashes)
        for name in binding["delete_paths"]:
            inventory.pop(name)
        if file_set_digest(inventory) != checks["source_digest"]:
            raise OptimizationError("STAGE_SOURCE_INVENTORY_DRIFT")
        if feedback["command_failures"] != [
            item["id"] for item in checks["commands"] if item["exit_code"] != 0
        ] or feedback["outputs"] != [
            {
                key: item[key]
                for key in item
                if key in {"id", "kind", "status", "sha256", "total", "failed", "errors", "skipped"}
            }
            for item in checks["outputs"]
        ]:
            raise OptimizationError("STAGE_FEEDBACK_DRIFT")
        return value

    def result_binding(self) -> dict[str, Any]:
        value = self.validate()
        return {
            "manifest_sha256": self.pin,
            "stage": self.stage,
            "candidate": value["artifacts"]["candidate"]["sha256"],
            "checks": value["artifacts"]["checks"]["sha256"],
            "feedback": value["artifacts"]["feedback"]["sha256"],
        }
