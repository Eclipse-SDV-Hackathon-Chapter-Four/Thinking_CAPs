# Tasks: Change impact, freshness and bounded AI context

Input: spec/plan/research/data-model/contracts. Negative-first tests required. Human-owned
reviews remain unchecked. Current implementation instruction authorizes development while
reviewer-owned requirements checklist remains pending; this is not engineering acceptance.

## Phase 1: Setup

- [x] T001 Preserve owner v3 brief and resolve Spec Kit templates in S_CORE_SW_FABRIC_TOKEN_OPTIMIZATION_SPEC_KIT_CODEX_BRIEF_v3_NO_JEV.md.
- [x] T002 Specify/plan/checklist/analyze 011 and constitution proposal in specs/011-change-impact-and-freshness/.

## Phase 2: Foundational contracts

- [x] T003 Add exact safe-path/digest/byte-estimate helpers in src/score_sw_fabric/optimization/common.py (FR-017).
- [x] T004 Define explicit opt-in policy and schemas in policies/optimization-v1.yaml and schemas/optimization-*-v1.schema.json (FR-002/010/017).

## Phase 3: US1 — Evidence containment

Independent test: 1 MiB one-line SARIF, traversal/drift and persistent stage exhaustion.

- [x] T005 [US1] Write negative-first evidence/firewall tests in tests/contract/test_optimization_evidence.py (FR-001/002/016).
- [x] T006 [US1] Implement bounded native findings/JSON queries in src/score_sw_fabric/optimization/evidence_query.py (FR-001).
- [x] T007 [US1] Retain full output and enforce persistent result/stage budgets in src/score_sw_fabric/optimization/tool_results.py (FR-002).
- [x] T008 [US1] Deny generic raw reads/broad search in src/score_sw_fabric/optimization/firewall.py and docs/handoff/someip-84/factory/guard_agent_tools.py (FR-016).
- [x] T009 [US1] Deliver summary-only feedback in docs/handoff/someip-84/factory/collect_obligations.py and overnight_hooks.py (FR-003).
- [x] T010 [US1] Execute bounded stdio service and pre-tool hook integration in src/score_sw_fabric/optimization/server.py and tests/integration/test_optimization_service.py (FR-016).

## Phase 4: US2 — Telemetry and baseline

Independent test: missing usage stays null and impossible cache splits refuse.

- [x] T011 [US2] Test and implement nullable per-call usage/aggregation in src/score_sw_fabric/optimization/telemetry.py and tests/contract/test_optimization_governor.py (FR-004).
- [x] T012 [US2] Retain five pre-budget context baselines in specs/011-change-impact-and-freshness/evidence/benchmark/baseline.json (FR-014).

## Phase 5: US3 — Transitive impact/freshness

Independent test: removed edges/cycles/unknown dependencies cannot narrow scope.

- [x] T013 [US3] Test both-baseline reachability/freshness in tests/contract/test_optimization_context.py (FR-005).
- [x] T014 [US3] Implement conservative old/new impact and baseline-vector invalidation in src/score_sw_fabric/optimization/impact.py and src/score_sw_fabric/artifacts/impact.py (FR-005).

## Phase 6: US4 — Classification

Independent test: S0–S4 cases, unresolved scope, safety/interface and fanout.

- [x] T015 [US4] Test and implement deterministic classifier in src/score_sw_fabric/optimization/task_classification.py and tests/contract/test_optimization_context.py (FR-006).

## Phase 7: US5 — Manifest/lazy context

Independent test: stale manifest blocks; required safety/L0 cannot trim; optional L2 omitted.

- [x] T016 [US5] Implement digest-bound manifest in src/score_sw_fabric/optimization/context_manifest.py (FR-007).
- [x] T017 [US5] Implement context accounting/retrieval/observations in src/score_sw_fabric/optimization/context_budget.py and src/score_sw_fabric/agents/context.py (FR-008).

## Phase 8: US6 — Lazy Skills

Independent test: modified/missing/unselected Skill refuses, reference loads only on demand.

- [x] T018 [US6] Create eight narrow Skills and registry in .agents/skills/score-*/SKILL.md and profiles/optimization-skills-v1.yaml (FR-009).
- [x] T019 [US6] Implement bounded selection and explicit runtime renderer in src/score_sw_fabric/optimization/skill_selection.py (FR-009).

## Phase 9: US7 — Governor/routing

Independent test: unknown usage, missing trigger, ceiling exhaustion and human gates refuse.

- [x] T020 [US7] Test and implement class governor in src/score_sw_fabric/optimization/token_governor.py and tests/contract/test_optimization_governor.py (FR-010).
- [x] T021 [US7] Route existing admitted catalogue profiles and conditional critic in src/score_sw_fabric/optimization/model_router.py and src/score_sw_fabric/agents/admission.py (FR-010/017).

## Phase 10: US8 — Structured stage/review output

Independent test: output schema rejects prose; required rationale stays intact; stable prefixes.

- [x] T022 [US8] Implement common prompt/result/review pack in src/score_sw_fabric/optimization/prompts.py and review_pack.py (FR-011).
- [x] T023 [US8] Apply silent common prompt contract in src/score_sw_fabric/agents/roles.py and docs/handoff/someip-84/factory/prepare_overnight_queue.py (FR-011).

## Phase 11: US9 — Progress/stops

Independent test: repeated failures/queries, unchanged correction and evidence-only refresh.

- [x] T024 [US9] Test and implement progress/stops in src/score_sw_fabric/optimization/progress.py and tests/contract/test_optimization_governor.py (FR-012).

## Phase 12: US10 — Derived modes

Independent test: five modes retain exact mandatory collectors/human gates.

- [x] T025 [US10] Implement derived mode projection in src/score_sw_fabric/optimization/workflow_modes.py and tests/contract/test_optimization_governor.py (FR-013).

## Phase 13: US11 — Benchmarks/audit

Independent test: B1–B5 deterministic outcomes/checks/IDs/evidence remain equal, estimates labelled.

- [x] T026 [US11] Implement five baseline/optimized benchmarks in src/score_sw_fabric/optimization/benchmark.py and evidence/benchmark/ (FR-014).
- [x] T027 [US11] Implement consistency audit/coverage map in src/score_sw_fabric/optimization/audit.py and specs/011-change-impact-and-freshness/coverage.yaml (FR-015).
- [x] T028 [US11] Add operator CLI in src/score_sw_fabric/optimization/cli.py and src/score_sw_fabric/cli.py (FR-017).

## Phase 14: Validation and reconciliation

- [x] T029 Execute native conformance and full regression with pinned tools; record logs in specs/011-change-impact-and-freshness/evidence/ (SC-002/004).
- [x] T030 Reconcile README, docs/backlog/roadmap.md, requirements-index.md, docs/architecture/0014-bounded-context-and-procedures.md and acceptance.md (FR-015).
- [x] T031 Run final analyze/converge and audit against all spec/plan/tasks in specs/011-change-impact-and-freshness/ (SC-004).
- [ ] T032 HUMAN: Review constitution proposal, optimization policy/Skill mapping and requirements checklist in .specify/memory/constitution.md and specs/011-change-impact-and-freshness/checklists/optimization.md.
  Owner approval was explicitly supplied on 2026-10-04; [owner-review.md](owner-review.md)
  records acceptance of the exact 20 reviewed subjects. The human-owned marker is preserved.
- [ ] T033 HUMAN/EXTERNAL: Authorize and measure native guarded Fabro stage activation and B1–B5 live provider usage; verify 60–80% routine uncached reduction in specs/011-change-impact-and-freshness/acceptance.md (FR-014/016).
  The owner requested issue selection on 2026-10-04; [lifecycle #704](t033-issue-selection.md)
  is selected. Scoped native execution and exact local patch review are now measured/approved;
  full B1–B5 coverage and native/005 engineering acceptance remain pending. See lifecycle-704-owner-review.md.

## Dependencies and implementation strategy

Setup → contracts → US1 → US2 baseline → US3 → US4 → US5 → US6 → US7 → US8 → US9 →
US10 → US11 → full validation. US1 is the independently testable emergency MVP. Tests precede
code or accompany interface updates. Independent read-only research runs in parallel; no concurrent
file edits. Converge after each major phase and append only new uncovered work. Human tasks do not
block local implementation or imply authority; default live execution remains disabled; US12 explicitly permits scoped qualification while T033 remains open.

## Phase 15: Convergence

- [x] T034 Bind bounded context/governor to reviewed compiler projections before IR generation in src/score_sw_fabric/compiler/optimization.py and tests/contract/test_optimization_governor.py per FR-013/016 (partial). Preserve every command/human node and native edge/loop; command-only modes reject supplied agent nodes instead of deleting obligations.

## Phase 16: Convergence

- [x] T035 Align generated collector/repair command and expected-output paths with actual summary-only feedback, enforce the complete serialized summary ceiling, and test host evidence retention versus copied agent feedback in docs/handoff/someip-84/factory/ and tests/contract/test_optimization_evidence.py per FR-003/016 (partial).

## Phase 17: Convergence

- [x] T036 Expose classifier thresholds and conservative precedence in policies/optimization-v1.yaml, bind them to the classification digest and self-audit, and test that broad sensitive work requires S4 scope authorization in src/score_sw_fabric/optimization/task_classification.py and tests/contract/test_optimization_context.py per FR-006/015 (partial).

## Phase 18: Scoped native qualification continuation

- [x] T037 Draft the T032 review subject and exact artifact bindings in specs/011-change-impact-and-freshness/review-draft.md; record owner continuation and Flash-only scope without accepting human items (FR-015/018).
- [x] T038 Test and implement host-private activation bindings and a DeepSeek-only bounded transport meter in src/score_sw_fabric/optimization/activation.py, provider_boundary.py and tests/contract/test_optimization_activation.py (FR-018).
- [x] T039 Measure real native stage guard/service behavior in a separate disposable Fabro server, initially without provider calls, and retain new evidence in specs/011-change-impact-and-freshness/evidence/qualification/ (FR-016/018).
- [x] T040 Run authorized Flash-only paired B1–B5 development measurements within ten requests and $0.10; stop on unmeasured required usage and retain raw native/provider records separately (FR-014/018).
- [x] T041 Reconcile source-derived price bounds, native activation limitations, tests, review draft, contracts, coverage, ADR/roadmap/acceptance and final analyze/converge without checking T032/T033 (FR-015/018).

## Phase 19: Measured overhead convergence

- [x] T042 Remove declarations for already-denied native tools before experimental provider transmission using a checksum-pinned bounded-tool selection; retain every message, allowed declaration and original/request digest, and enforce the pinned governor per task in src/score_sw_fabric/optimization/provider_boundary.py, activation.py and tests/contract/test_optimization_activation.py (FR-016/018). Replay real native requests without further paid calls; live requalification remains T033.

## Phase 20: Authorized projection measurement

- [x] T043 Execute the separately authorized second ten-request Flash comparison within $0.10, retaining unchanged original fixture prompts and equal tool selection, per-request stage/output/usage checks and fresh native/provider evidence in specs/011-change-impact-and-freshness/evidence/projection-qualification/ (FR-014/016/018).
- [x] T044 Reconcile the second comparison, cache observations, conservative price bounds, source pins and current acceptance/audit without rewriting the first experiment or checking human tasks; verify and commit/push the bounded result (FR-015/018).

## Phase 21: Real lifecycle #704 continuation

The owner's 2026-10-04 `go` authorizes local cleanup and guarded comparison preparation;
no new paid request or upstream publication. T032 approval is recorded separately;
the two human-owned markers and closed experiments remain unchanged.

- [x] T045 Recheck #704 activity, allocate shared-storage disposable source copy, inspect native hooks and inventory config consumers/source pins in evidence/lifecycle-704/ (FR-014/016; AC18/19).
- [x] T046 Implement minimal shared configuration definitions with exact per-consumer semantics in the disposable lifecycle copy; retain a portable patch (FR-014/017; AC18).
- [x] T047 Compare all effective configurations and run affected native checks with storage-bound caches; retain actual outcomes and explicit unavailable prerequisites (FR-014/015; AC18/19).
- [x] T048 Prepare baseline/optimized real-task contexts and current guard/Skill/governor bindings; execute no-provider native conformance without resetting closed ledgers (FR-014/016/018; AC20).
- [x] T049 Reconcile patch/evidence, acceptance, coverage and Spec Kit consistency; preserve human-owned markers and reviewed hashes (FR-015/017; AC19/20).

## Phase 22: Authorized Fabro/Flash implementation

- [x] T050 Allocate fresh storage-bound original-source copy, check current issue activity and pin the four-request/$0.10 owner instruction, source/Skill/tool bindings and private native server (FR-014/016/018; AC21/23).
- [x] T051 Execute native Flash implementation stages from original configs/BUILD files and deterministically apply only allowed operations; preserve original replies and separate formatting (FR-014/016/017/018; AC21).
- [x] T052 Measure all-three configuration and packaging equivalence plus affected native tests; retain failures and at most one bounded correction (FR-014/015/018; AC22).
- [x] T053 Execute the required S3 Flash advisory critique, retain actual native/provider usage, stop at human review and close the fresh experiment's meter/server (FR-010/016/018; AC22/23).
- [x] T054 Reconcile portable patch, evidence, acceptance, coverage and consistency; preserve all 20 T032 hashes and human-owned markers (FR-015/017; AC21/22/23).

US14 result: **failed qualification**. At US14 closure, T051/T052 were incomplete: rejected macro and
non-JSON BUILD output, no admissible Flash patch or affected passing tests. US15 below
completes those task obligations with separate new evidence. T053 reaches
the native human gate and closes all four requests; no approval is recorded. Further paid
implementation needs a fresh bounded instruction. See evidence/lifecycle-704-flash/.

## Phase 23: Owner budget exception retry

The owner's latest explicit instruction supersedes the need for a new spending ceiling
at the end of US14. It does not reopen its closed ledger or accept engineering decisions.

- [x] T055 Test and implement an optional private #704 owner budget exception without changing default admission, reviewed subjects or historical ledgers (FR-018; AC24).
- [x] T056 Run fresh native Fabro/Flash nonthinking JSON-mode implementation from original sources; complete T051/T052 with new native equality/package/regression evidence (FR-014/016/017/018; AC25).
- [x] T057 Retain S3 advisory critique, stop at the native human gate, close the new server/ledger and reconcile evidence/acceptance/coverage/audit (FR-010/015/018; AC24/25).

## Phase 24: Transport retention convergence

Final reconciliation found two legacy envelopes overwritten across fresh-ledger ticket
zeroes. Preserve this loss explicitly; structured outputs and native usage remain intact.

- [x] T058 Prevent raw artifact collisions using instruction-specific namespaces and exclusive creation; test two ledgers and refusal before a duplicate transmission (FR-015/018; AC24/25).
- [x] T059 Run a fresh guarded evidence-check/Flash advisory/human-gate graph with full request/reply/usage reconciliation under the fixed transport; close it before inactivity (FR-016/018; AC25).

US15 result: native Flash-produced implementation checks and the corrected transport's
fresh guarded proof pass. All local tasks complete; T032/T033 markers remain human-owned.
Two legacy envelopes are explicitly missing, with retained native outputs/usage and a
separately complete fresh proof. Advisory findings have draft evidence responses; no
engineering gate was accepted. See evidence/lifecycle-704-flash-retry/.

## Phase 25: Approved local upstream contribution packet

The owner approved the supplied patch/advisory review, then explicitly chose local PR
preparation. No publishing or new paid measurement is authorized by this choice.

- [x] T060 Verify approved US15/T032 subjects and record the exact owner decision separately in lifecycle-704-owner-review.md (FR-015/017; AC26).
- [x] T061 Recheck upstream activity/baseline/PR overlap, inspect hooks and apply the approved patch on a fresh shared-storage contribution branch (FR-015/017; AC27).
- [x] T062 Fill upstream improvement PR template and retain portable patch, validation scope, contribution sources and contribution-checkout/hash verification in evidence/lifecycle-704-upstream-packet/ (FR-015/017; AC27).
- [x] T063 Reconcile acceptance/review/coverage/roadmap and run foundation/audit/Spec Kit consistency checks without altering approved packets or human-owned markers (FR-015/017; AC26/27).

US16 result: the exact approved patch and review packet remain unchanged. A fresh bound
local contribution branch and native-template PR packet are complete; current source and
all 22 open PRs were rechecked. Foundation/package/consistency checks pass. No paid call,
commit, fork, push or publication occurred; human-owned T032/T033 markers remain unchanged.

## Phase 26: Real-target benchmark plan

The owner defers publication and approves local benchmark-plan preparation. Future paid
execution requires its own fresh admission packet; this phase supplies no live instruction.

- [x] T064 Bind existing native pilot/evidence and reviewed subjects in evidence/t033-benchmark-plan/source-bindings.json; distinguish P704 from B1–B5 and record unresolved native expected-set inputs (FR-014/015/017; AC28/29).
- [x] T065 Draft matched-arm oracles, context/tool controls, whole-task token/cache/cost/time accounting, failure/repetition protocol and execution prerequisites in t033-benchmark-plan.md and evidence/t033-benchmark-plan/case-plan.json (FR-014/016/018; AC28).
- [x] T066 Reconcile spec/plan/tasks/coverage/acceptance/roadmap and verify planning bindings, null metrics, local links, foundation/package and scoped Spec Kit consistency without live calls or modifying human markers (FR-015/017; AC29).

## Phase 27: Paired P704 no-provider preparation

- [x] T067 Allocate shared-storage original-source copies, inspect hooks, freeze current fabric implementation/locks and preserve prior control snapshots in evidence/t033-paired-preparation/ (FR-014/015/017; AC30/32).
- [x] T068 Derive baseline/selected contexts from original sources with identical task/contracts/tools; record native scope unknowns and refused stage governors (FR-014/016/018; AC30/31).
- [x] T069 Prepare matched native graph/config packages, source initialization and bounded-tool entrypoints plus common collector/result-binding expectations; retain unwired live boundaries explicitly (FR-016/017/018; AC31).
- [x] T070 Validate both graphs with the pinned native validator; check equal obligations and probe source initialization, bounded retrieval, drift/forbidden-tool/no-instruction refusals without provider/native build execution (FR-014/015/016; AC31/32).
- [x] T071 Reconcile current controls/coverage/acceptance/roadmap and retain source/validation/manifest records with frozen dependency, foundation, package and scoped consistency checks; preserve human markers (FR-015/017; AC32).

## Phase 28: Protected paired runtime bindings

- [x] T072 Preserve prior subjects and implement exact worker/source bindings and safe initialization in src/score_sw_fabric/optimization/paired_runtime.py (FR-015/016/017; AC33).
- [x] T073 Implement pinned structured result application, source scope and replay/correction protection with private local state and original response retention (FR-016/017/018; AC34).
- [x] T074 Implement fresh disposable native collectors with candidate/source/tool/command/output bindings and distinct failure/missing/skip outcomes in src/score_sw_fabric/optimization/paired_collector.py (FR-014/015/017; AC35).
- [x] T075 Exercise adversarial local tests and collector integration; wire both candidate graph packages and validate offline without provider calls (FR-014/016/018; AC33/34/35/36).
- [x] T076 Reconcile controls/coverage/acceptance/evidence, run frozen dependency/static/test/foundation/package checks and preserve human markers and live admission gaps (FR-015/017; AC36).

## Phase 29: Provider-disabled native API smoke

- [x] T077 Preserve US19/control subjects, allocate storage-bound scratch and freeze source/tool/command controls for a private provider-disabled API server (FR-015/016/017; AC37/39).
- [x] T078 Exercise exact native API worker/source initialization; retain actual metadata/refusals and implement/test necessary bounded compatibility fixes without provider authority (FR-016/017; AC37).
- [x] T079 Execute baseline/optimized native command workflows for labeled replay application, lightweight fresh checks, routed feedback, refusal and unanswered human gates; retain actual API evidence (FR-014/015/016/018; AC38).
- [x] T080 Verify zero provider requests and close only owned runs/server; preserve immutable packets and native acceptance/impact unknowns (FR-015/018; AC39).
- [x] T081 Reconcile coverage/spec/plan/tasks/acceptance/evidence and required frozen/static/test/foundation/package/Spec Kit checks without changing human markers (FR-015/017; AC39).

## Phase 30: Offline review outside workflow execution

- [x] T082 Preserve historical packets and control snapshots; replace current workflow human nodes with report/exit paths under the owner instruction (FR-013/015/016/017; AC40).
- [x] T083 Bind and export complete offline review reports with preserved failures, usage, source/check evidence and unresolved decisions; validate both revised native graphs (FR-014/015/017/018; AC41).
- [x] T084 Execute both graphs through the provider-disabled API to terminal report completion, verify no human handler/question or provider request, stop owned state and reconcile controls/checks without accepting engineering gates (FR-015/016/017/018; AC42).

## Phase 31: Measured P704 native scope review

- [x] T085 Preserve prior packet/control subjects and measure old/new source and reverse native build-dependency scope in fresh storage-bound copies (FR-005/014/015/017; AC43).
- [x] T086 Trace source/CI/platform/native declaration/process obligations and produce a proposed expected-check matrix with measured export/applicability boundaries (FR-005/014/016/017; AC44).
- [x] T087 Export offline review/results/provenance, verify historical subjects and reconcile controls, scope checks and human markers (FR-015/017; AC45).

## Phase 32: Local provider response and usage capture

- [x] T088 Preserve source/control/packet subjects, reproduce capture-binding gaps and pin retained response bytes to observed meter tickets and exact stage sources (FR-015/016/017/018; AC46).
- [x] T089 Exercise completed JSON/SSE local HTTP capture/application and tampering, unknown-usage, truncation and replay refusals; retain raw synthetic outcomes and stop owned endpoints (FR-015/016/018; AC47).
- [x] T090 Export offline evidence and reconcile coverage/controls with frozen/static/regression/foundation/package/Spec Kit checks, preserving historical subjects and pending human acceptance (FR-015/017; AC48).

## Phase 33: Native agent consumption against a local emulator

- [x] T091 Preserve historical/control subjects, freeze provider/prompt/runtime sources and prepare exact private API worker/stage/meter/loopback bindings (FR-015/016/017/018; AC49).
- [x] T092 Execute baseline/optimized native agent response/capture/check/feedback consumption and unknown-usage refusal; retain raw synthetic/native evidence without live claims (FR-014/015/016/018; AC50).
- [x] T093 Export complete offline reports, close owned state and reconcile controls/coverage/foundation/package/Spec Kit checks while preserving human markers and historical packets (FR-015/017; AC51).

## Phase 34: Native bounded correction and operator recovery refusal

- [x] T094 Preserve historical/control subjects, freeze source/transport/operator bindings and validate fresh bounded correction/refusal native graphs (FR-015/016/017; AC52/54).
- [x] T095 Execute actual native correction with exact failed feedback and fresh post-correction checks; measure unbound correction and restarted-operator replay/interruption refusals (FR-014/015/016/018; AC52/53).
- [x] T096 Export offline reports, close owned state, verify preservation and reconcile coverage/controls/foundation/package/Spec Kit checks while leaving human markers unchanged (FR-015/017; AC54).

## Phase 35: Fresh P704 admission and offline scope choices

- [x] T097 Refresh upstream/provider inputs, bind proposed full CI/check inventory and inspect the exact pinned QNX dependency declaration without repeated SDK fetching (FR-005/014/015/017; AC55).
- [x] T098 Prepare equal original-source prompt rendering, retain initial oversized reconstructions and measure common serialization under unchanged guards; check documented SSE usage locally and retain refused governors (FR-014/015/016/018; AC56).
- [x] T099 Export concrete offline native scope/roles/QNX choices and an unfilled decision record; preserve historical subjects/human markers, reconcile controls and verify repository/trace/package checks (FR-015/017; AC57).

## Phase 36: Actual native payload and pinned parameter qualification

- [x] T100 Preserve prior subjects/source controls, execute exact native prepared prompts against a loopback refusal endpoint, export actual body/wrapper/identity evidence and close owned state (FR-014/015/016/017/018; AC58).
- [x] T101 Fix measured native thinking/JSON defaults with an optional exact pinned Flash parameter profile; exercise source/limit preservation and profile/pin/byte-limit refusals with actual local HTTP wire tests (FR-015/016/017/018; AC59).
- [x] T102 Export bound offline findings and fresh code/validation provenance; reconcile controls/coverage/trace checks, preserve human markers and keep native scope/full-stage envelopes unaccepted (FR-015/017; AC60).

## Phase 37: Bound correction/review envelopes and actual size refusals

- [x] T103 Preserve prior/source/control subjects; bind complete historical correction/review candidate/source/check/feedback envelopes in both arms and exercise drift/failure-precondition refusals (FR-014/015/016/017/018; AC61).
- [x] T104 Validate and execute exact native dynamic-stage prompts against a loopback-only capture/refusal endpoint; retain projected sizes/context refusals and close owned state without human nodes or upstream (FR-014/015/016/018; AC62).
- [x] T105 Export complete offline findings/input/refusal provenance, reconcile controls/coverage and current foundation/package/trace checks, preserve human markers and retain bounded retrieval/native admission gaps (FR-015/017; AC63).

## Phase 38: Bound source retrieval through native MCP

- [x] T106 Implement pinned stage source manifests and a restricted bounded excerpt service; exercise candidate/check/feedback/source drift, scope and persistent budget refusals (FR-002/009/015/016/017; AC64).
- [x] T107 Prepare equal bounded correction/review inputs and execute actual native MCP delivery against local synthetic replies; retain whole-request meters, tool results and refusals without paid calls or relaxed guards (FR-014/015/016/018; AC65).
- [x] T108 Export offline reports and fresh code/check provenance, close owned state, preserve historical subjects and reconcile controls/trace/package checks without engineering acceptance (FR-015/017; AC66).

## Phase 39: Complete bounded correction and fresh feedback

- [x] T109 Implement verified multi-response capture with exact bounded-tool/conversation/source bindings, run-bound collector isolation and adversarial regression coverage (FR-002/015/016/017/018; AC67).
- [x] T110 Execute baseline/optimized fresh native correction, complete candidate application, new protected checks, bounded advisory review and truncated-result refusal against synthetic local replies (FR-014/015/016/018; AC68).
- [x] T111 Export offline evidence, close owned state, preserve historical/reviewed subjects and reconcile controls with required fresh checks (FR-015/017; AC69).


## Phase 40: Offline native admission evidence review

- [x] T112 Pin historical/source/owner subjects and deterministically review exact native CI/check identities, genuine exported architecture status and remaining impact closure (FR-005/014/015/017; AC70).
- [x] T113 Draft concrete trial scope/deferral choices, metadata-only QNX readiness findings and unfilled role/decision subjects; retain human drafting preferences separately from accepted authority (FR-014/015/018; AC71).
- [x] T114 Export review evidence and preservation results; reconcile current controls/coverage and foundation/package/trace checks with unchanged source-bound prior tests and human markers (FR-015/017; AC72).


## Phase 41: Linux native dependency loading with QNX skipped

- [x] T115 Preserve historical/control/source subjects, inspect hooks and prepare storage-bound native source/tool/options with explicit QNX execution exclusion (FR-005/014/015/017; AC73).
- [x] T116 Measure pinned Linux dependency loading/analysis and exact non-QNX inputs in isolated disposable probes; retain missing/cache/refusal distinctions without SDK substitution or native acceptance (FR-005/014/015/016/018; AC74).
- [x] T117 Export offline findings, verify immutable subjects and owned process closure, and reconcile controls/frozen/package/trace checks using unchanged source-bound prior tests (FR-015/017; AC75).


## Phase 42: Public Python metadata with QNX download denial

- [x] T118 Preserve historical/control/source subjects and prepare bounded public Python metadata with exact provenance and source/tool/downloader bindings (FR-005/014/015/017; AC76).
- [x] T119 Exercise namespace-local metadata delivery and explicit QNX/unlisted download denial in pinned native Linux retries; retain missing inputs, failures and exact unchanged source bindings (FR-005/014/015/016/018; AC77).
- [x] T120 Export offline reports, close owned processes/endpoints and reconcile preservation/controls/frozen/package/trace checks with source-bound prior tests (FR-015/017; AC78).

## Phase 43: Pinned Linux analysis with all captured metadata

- [x] T121 Preserve historical/control/source subjects and bind a fresh original source copy, native tool, 68-package mirror and exact lock-bound writable registry cache (FR-005/014/015/017; AC79).
- [x] T122 Measure bounded isolated Linux loading/analysis and diagnose remaining native dependencies without QNX, source/lock changes or inferred engineering acceptance (FR-005/014/015/016/018; AC80).
- [x] T123 Export complete offline findings, verify process/mirror closure and preservation, and reconcile controls/frozen/package/trace checks with unchanged source-bound prior tests (FR-015/017; AC81).

## Phase 44: Exact public module inputs and Linux analysis

- [x] T124 Preserve historical/control/source subjects and prepare exact bounded public module archive/patch inputs with native source-lock integrity and HTTP provenance (FR-005/014/015/017; AC82).
- [x] T125 Measure isolated native archive/patch consumption and configured Linux analysis; retain failed/missing dependencies and bounded stops without SDKs or source/lock changes (FR-005/014/015/016/018; AC83).
- [x] T126 Export offline findings, verify owned process/mirror closure and preservation, and reconcile controls/frozen/package/trace checks with unchanged source-bound prior tests (FR-015/017; AC84).

## Phase 45: Source-bound Bats inputs and Linux analysis

- [x] T127 Preserve historical/control/source subjects and prepare exact bounded Bats/source-module inputs with native lock/archive and HTTP/cache provenance (FR-005/014/015/017; AC85).
- [x] T128 Measure isolated verified dependency consumption and configured Linux analysis with per-probe input/source snapshots, explicit failures and bounded stops (FR-005/014/015/016/018; AC86).
- [x] T129 Export offline findings, verify process/mirror closure and immutable subjects, and reconcile controls/frozen/package/trace checks with unchanged source-bound prior tests (FR-015/017; AC87).

## Phase 46: Cached Linux Buf tools and analysis

- [x] T130 Preserve historical/control/source subjects and prepare exact cached Buf binaries with original lock/checksum provenance and bound storage/runtime (FR-005/014/015/017; AC88).
- [x] T131 Measure isolated configured Linux analysis and retain per-probe inputs, tool/source bindings, dependency failures and bounded stops (FR-005/014/015/016/018; AC89).
- [x] T132 Export offline evidence, verify process closure and preservation, and reconcile controls/frozen/package/trace checks without accepting human decisions (FR-015/017; AC90).

## Phase 47: Exact Linux Ferrocene inputs and analysis

- [x] T133 Preserve historical/control/source subjects; bind current storage and verified historical inputs, measure release/source/checksum/size provenance and declare separate finite acquisition limits (FR-005/014/015/017; AC91).
- [x] T134 Acquire the exact three pinned Linux payloads, retain archive inventories/notices, and measure isolated configured analysis with exact input/operator bindings and bounded failure stops (FR-005/014/015/016/018; AC92).
- [x] T135 Export offline evidence, verify preservation/process closure and reconcile controls/coverage/frozen/package/trace checks, preserving human markers and unqualified native/live scope (FR-015/017; AC93).

## Phase 48: Exact Linux Coreutils input and analysis

- [x] T136 Verify historical/control/reviewed subjects and bind fresh storage/source/tool/runtime; measure source-bound release/cache/size provenance and declare finite acquisition limits (FR-005/014/015/017; AC94).
- [x] T137 Acquire the exact Linux Coreutils archive, preserve actual inventory/notices and measure isolated configured analysis with input/operator/materialization bindings and bounded failure stops (FR-005/014/015/016/018; AC95).
- [x] T138 Export offline evidence, verify immutable preservation and process closure, reconcile controls/coverage/frozen/package/trace checks and preserve pending human/native/live boundaries (FR-015/017; AC96).

## Phase 49: Exact Linux GCC package and analysis

- [x] T139 Verify historical/control/reviewed subjects, bind fresh storage/source/tool/runtime and inherited inputs, refresh pinned Linux GCC release/source/digest/size provenance and declare finite limits (FR-005/014/015/017; AC97).
- [x] T140 Acquire exact original-lock-bound GCC package with actual inventory/notices, measure separate repository materialization and configured Linux analysis, and retain input/operator/failure bindings with bounded stops (FR-005/014/015/016/018; AC98).
- [x] T141 Export complete offline findings, verify immutable preservation/process closure and reconcile controls/coverage/frozen/package/trace checks with carried source-bound prior validation and pending human/native/live acceptance (FR-015/017; AC99).

## Phase 50: Exact Linux jq binary and analysis

- [x] T142 Preserve historical/control/reviewed subjects, bind fresh storage/source/tool/runtime and inherited inputs, refresh native SHA-384/release/source-license provenance and declare finite binary limits (FR-005/014/015/017; AC100).
- [x] T143 Acquire exact Linux jq 1.7, verify native integrity and measured SHA-256/ELF/static notice findings, then measure independent repository loading and configured analysis with bounded stops/input/operator bindings (FR-005/014/015/016/018; AC101).
- [x] T144 Export complete offline evidence, verify immutable preservation/process closure and reconcile controls/coverage/frozen/package/trace checks with carried prior source validation and pending human/native/live acceptance (FR-015/017; AC102).

## Phase 51: Exact Linux BSD tar binary and analysis

- [x] T145 Preserve historical/control/reviewed subjects, bind fresh storage/source/tool/runtime and inherited inputs, refresh native checksum/release/source-license provenance with canonical URL separation and declare finite limits (FR-005/014/015/017; AC103).
- [x] T146 Acquire exact Linux BSD tar with native SHA-256/ELF/static notice findings, measure independent repository loading and configured analysis with exact bindings and bounded failure stops (FR-005/014/015/016/018; AC104).
- [x] T147 Export complete offline evidence, verify immutable preservation/process closure and reconcile controls/coverage/frozen/package/trace checks with carried source validation and pending human/native/live acceptance (FR-015/017; AC105).

## Phase 52: Exact Linux zstd binary and analysis

- [x] T148 Preserve historical/control/reviewed subjects, bind fresh storage/source/tool/runtime and inherited inputs, refresh native checksum/release/source-license provenance with canonical URL separation and declare finite limits (FR-005/014/015/017; AC106).
- [x] T149 Acquire exact Linux zstd with native SHA-256/ELF/static notice findings, measure independent repository loading and configured analysis with exact bindings and bounded failure stops (FR-005/014/015/016/018; AC107).
- [x] T150 Export complete offline evidence, verify immutable preservation/process closure and reconcile controls/coverage/frozen/package/trace checks with carried source validation and pending human/native/live acceptance (FR-015/017; AC108).

## Phase 53: Exact Debian Linux OCI input and analysis

- [x] T151 Verify historical/control/reviewed subjects, bind fresh storage/source/tool/runtime and inherited inputs, measure original-pinned OCI closure with in-memory anonymous token handling and declare finite limits (FR-005/014/015/017; AC109).
- [x] T152 Prepare exact platform/config/layer objects with descriptor/diff-ID hashes and bounded inventory/notices, measure separate repository loading and configured analysis with preserved token fallback/refusals and bounded stops (FR-005/014/015/016/018; AC110).
- [x] T153 Export complete offline evidence, verify immutable preservation/process closure and reconcile controls/coverage/frozen/package/trace checks with carried source validation and pending human/native/live acceptance (FR-015/017; AC111).

## Phase 54: Convergence — authorized remaining native qualification

- [ ] T154 Resolve the demonstrated original-pinned C++ policy archive and successive exact native dependencies with fresh finite stage envelopes, cache/provenance/integrity/license/size evidence and preserved failures (FR-005/017; US44/AC110; partial).
- [x] T155 Execute the preserved five-target Linux native analysis/build/test scope on original and approved candidate source copies, retain complete real results and unresolved native applicability (FR-005/014/016; T033; partial).
- [ ] T156 Prepare remaining B1–B5 qualification inputs and independent oracles within available source authority; export exact missing provider budgets, engineering inputs and acceptance obligations (FR-014; US11/AC13; partial).
- [x] T157 Reconcile specification/plan/coverage/acceptance against measured outcomes, frozen/static/test/foundation/package validation and immutable preservation; export a complete bound offline report (FR-015/017; SC-004; partial).

Checkpoint follow-up: [t033-docs-impact/review-report.md](evidence/t033-docs-impact/review-report.md)
measures equal 94-target scoped native closures and three added loadfiles. Full
closure stays QNX-blocked; B3 coverage now requires a compatible disposable Linux
runtime for the unchanged Ferrocene host tool. T154/T156 remain open. Existing
tasks cover these demonstrated gaps; no duplicate convergence task is appended.

Runtime follow-up: [t033-linux-runtime/review-report.md](evidence/t033-linux-runtime/review-report.md)
qualifies isolated pinned compiler execution, actual B2 allocation and B3 coverage/
mutation witnesses. Original docs export next needs exact Aspect unpack preparation.
T154/T156 and T032/T033 remain open; all human-owned markers are preserved.

Documentation-export follow-up:

[Bound export report](evidence/t033-aspect-export/review-report.md) records fresh
original and approved candidate `//:needs_json` success after six exact pinned public
tool inputs. Both arms retain 144 Lifecycle, 1,251 Process and 916 Platform records;
all IDs and native values equal their historical exports. The stale P704 cache binding
is refused rather than rewritten. Intermediate dependency failures are preserved.
Actual Sphinx-Needs 8.5.0 exports do not establish compatibility with the catalogue
importer's pinned 8.3.1 producer contract. Native applicability/complete expected sets,
B1 selection, B2 production correction, full B3/RPC qualification, accepted B4/B5
inputs, fresh paid budgets and offline T033 acceptance remain unresolved.
[Remaining B3 inventory](evidence/t033-aspect-export/remaining-B3-coverage.json)
separates summary denominators from explicit LCOV locations; no missing locations are
invented. Existing T154/T156 remain partial and human markers are unchanged.

## Producer contract and extended B3 evidence

[Bound report](evidence/t033-producer-contract/review-report.md) measures the actual
docs-as-code8.3.0 / Sphinx-Needs8.5.0 pair against the existing8.2.0/8.3.1 baseline.
Native archive and metamodel bytes are verified; the schema is unchanged but relation,
type and option definitions change. An [explicit profile proposal](evidence/t033-producer-contract/architecture-draft.md)
preserves v1/default/source locks and remains proposed, unimplemented and unaccepted.
Complete immutable consumer source/namespace bindings and real conformance remain open.
Eight original-plus-extended B3 cases pass; summary132/182 lines,39/56 branches,10/12
functions. A wrong-rejection-reason mutant fails exactly one new case; seven pass.
Controlled graph peers do not qualify RPC transport, production graph behavior or full
issue685 coverage. A demonstrated capture gap causes one finite evidence refresh;
raw ZIP/text-format error and corrected capture remain explicit. Existing witnesses
are preserved; no provider requests or human decisions are made.

## Phase 55: Demonstrated native producer contract gap

- [x] T158 Measure real consumer creator/schema/metamodel changes against original lock/source bytes, export scoped architecture alternatives and extended held-out B3 coverage/mutation evidence with truthful capture gaps (FR-005/014/015/017; T033 remains incomplete).
- [ ] T159 Prepare complete immutable consumer source/namespace bindings and implement explicitly scoped producer/metamodel profile conformance while preserving existing v1/default/source-lock refusals and baseline digests; preserve unqualified native types/semantics and pending engineering acceptance (FR-005/017; demonstrated8.3.0/8.5.0 compatibility gap).
