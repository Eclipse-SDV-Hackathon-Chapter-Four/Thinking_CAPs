# Rust workflow and issue queue — frozen for later resume

User instruction: “froze the work with a handoff to continue later”. **Paused by user.**
Do not continue source corrections, native execution, paid model calls or publishing
until the user resumes. This handoff supersedes older “running” and “next action”
instructions; retain those files as history. Detailed verified state and bindings are
in [the JSON companion](011-session-20261006-rust-frozen.json).

## Completed and current status

The generic [S-CORE Rust workflow](../../.agents/skills/score-rust-workflow/SKILL.md)
exists and is installed for Codex. The original Rust issue queue has 13 terminal runs;
QNX #1278 is excluded. Runtime success records execution/export completion, including
failed checks, and does not establish that all issues are solved. The remaining queue
contains unresolved assessments, incomplete implementations and failed verification.

#560's latest scoped correction passed Linux verification: **five production LoLa
integration cases, three subprocess cleanup cases and six existing sync/async
regression cases**, plus binary build, native binary Clippy and explicit-label query.
Clippy retained two warnings; test-code Clippy was not measured. An independent Codex
supervisor found no blocking source defect in scope. Qualification, native trace and
applicability, downstream/example/concurrency coverage, future FFI-failure ownership
and offline human engineering acceptance remain pending. No upstream issue was closed
by this work and no new queue contribution was committed/pushed/published.

[Latest contribution](../../../eclipse_sdv_hackathon_2026/contributions/rust-api-queue/score-rust-560-codex-eppa905r-results/README.md):
107 payloads, manifest SHA-256
`63f3a414de0f6ba58835cb3ee74541bf1a58c76910bcac4dbd127f4cd42b35e1`.
Native run: `01M49A1PAGCVD0BTQPQ6RDPF3F`. All 2190 current source subjects match the
passing measurement; source-vector SHA-256
`636ba2b223c228962ec2d055f15200bbdec1818f3c0bf5dd28fddd1e6c50de2f`.
Read [the final results handoff](011-session-20261006-rust-560-codex-results.md) for
measured scope, source paths, raw evidence and limitations.

## Correction allowances — preserve across resume

The user explicitly authorized three **additional #560 corrections by Codex**.
One was used, two remain unused. Previous three attempts remain historical: four
lifetime attempts used, explicit maximum six. This exception applies to #560 only.
Do not infer a fresh allowance for every issue or reset it on a session/run change.

Original queue allowance is 31/36 used, five remaining: #250 two, #1261 two, #173 one.
#560's original three are exhausted; its two remaining Codex slots are a separate
user grant. #1264, #1263, #794, #781, #782, #1062, #741 and #490 have zero original
source corrections remaining. Historical #1265 permits zero new fixes/tests.
Failed correction calls count. Stop an issue when its applicable limit is exhausted.

Fabro agent runs remain DeepSeek Flash only: alias `deepseek-flash`, native model
`deepseek-v4-flash`, provider `deepseek`, no fallback. The later user exception permits
Codex review and #560's additional Codex corrections. Latest Fabro verification used
command stages only, with empty runtime model list and zero runtime model tokens;
Codex session usage/cost was not measured. Do not silently broaden that exception.

## Remaining queue findings

- #781: partial ABI draft; unchanged-source five ABI cases are carried evidence;
  later doctest/Clippy commands passed, with zero runnable doctest examples. Native
  field-offset, ownership/Send and trace findings remain open; zero source slots.
- #490: mock event-bus draft; final validation failed on Python metadata download;
  shared queues and subscriber isolation/delivery remain unverified; zero slots.
- #741: comment-only boundary probe; requested relocation is not implemented. Host
  relocation prototype/fixtures are not validated Fabro integration; zero slots.
- #250 and #1261: unresolved wildcard/backend design. #1261's API proposal defaults
  to NotSupported and does not implement the backend discovery stream; two slots each.
- #173: dependency assessment with one slot remaining. #1265 is an assessment with
  historical exhausted allowances. Other assessment issues remain unresolved.
- Written original supervisors are missing for #1263, #490, #250, #1261 and #173.
  Preserve actual failures/output; do not synthesize reviews or acceptance.

Original [queue results](011-session-20261006-rust-api-queue-results.md) and
[runtime review](011-session-20261006-rust-runtime-review.md) retain detailed per-issue
findings. Their old #560 counters/status are historical; use this handoff and the
latest #560 results for current allowances and outcome.

## Storage, runtimes and preservation

Current root:
`/media/jefferson/11c42dee-73a3-4c2b-ab42-a0440011d9e0/.s-core-build/runs/score-rust-560-codex-eppa905r`;
workspace: `workspaces/560`. Backing Lexar UUID `002B-CE31`, registered Linux image
UUID `11c42dee-73a3-4c2b-ab42-a0440011d9e0`. Validate bindings using shared
`score_sw_fabric.storage` before dependent work. If disconnected, stop; never relocate
active work silently. Allocate new disposable work/cache through shared storage.
Never build in reference repositories, reformat storage, migrate a running queue or
change global tool storage. Keep credentials/private server state internal.

Owned Fabro/Docker shutdown proofs were verified. The latest Fabro listener is closed,
its Docker socket absent, and the supervisor agent completed. Original queue services
remain stopped per preserved evidence. Never restart terminal IDs, rerun one-time
create/start scripts, signal stale PIDs or stop unrelated global/user services.

Freeze verification rechecked all payload hashes in five sealed packets: latest #560
results, preceding failed integration results, Codex review, original queue results
and runtime review. They remain unchanged. Current native source hashes and ledger
were verified. Preserve all prior sealed packets, failed attempts, original brief,
unrelated user modifications and human-owned review items.

Historical #1265 contribution was explicitly pushed on branch
`contributions/communication-1265-rust-assessment`, commit
`172cce29f317a284790fb89dc56707b42cc95818`, to the hackathon repository. This is
historical publication authority, not permission to publish newer queue contributions;
do not assume the current branch or rewrite user work.

## Resume

Start a fresh Codex session using [the resume prompt](011-session-20261006-rust-frozen-prompt.md).
Read current AGENTS.md, constitution, active feature 011 and this verified handoff.
Review remaining issue findings/allowances before selecting new work. The first useful
step is queue triage and offline engineering review of #560, not another #560 source
correction merely because two slots remain. Resume revokes the pause, not acceptance,
publication restrictions, model policy or attempt limits. User can then select/authorize
the next issue; clarification is required only where authority is actually missing.
