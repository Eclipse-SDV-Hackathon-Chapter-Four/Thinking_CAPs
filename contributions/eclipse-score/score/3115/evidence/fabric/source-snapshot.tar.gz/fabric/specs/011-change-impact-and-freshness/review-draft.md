# Owner review draft — 011

Status: agent-prepared review subject; owner acceptance pending.

Subsequent owner decision (2026-10-04): **accepted for T032**. See
[owner-review.md](owner-review.md) for the exact user instruction and reviewed hashes.
The pending statements below describe the pre-decision review packet. Its 20 reviewed
subjects and human-owned checkboxes remain unchanged. T033 remains pending.

Owner continuation: `go`, followed by `deepseek flash only` on 2026-10-03.
This permits the disposable qualification in US12, with ten requests and a $0.10
technical ceiling. It does not accept constitution amendments, engineering decisions
or the reviewer-owned checklist. T032 and T033 remain unchecked.

Review findings:

- Proposed constitution XIII–XV preserve native authority, human gates and truthful metrics.
- Default live-call policy remains disabled. Operational ceilings narrow role ceilings.
- Eight Skills provide scoped procedures and preserve source IDs; digest identity is not acceptance.
- Native transport overhead, usage completeness and actual reduction require measurement.
- Qualification inputs live outside the agent workspace and are checksum-pinned by the operator.
  Unix permissions do not isolate hostile processes sharing the operator account.
- Current catalogue prices are stale. Peak Flash bounds are $0.30 input and $1.20 output per
  million tokens from https://api-docs.deepseek.com/quick_start/pricing/.

Owner disposition template: artifact hashes reviewed, accept/revise, reviewer identity,
date, rationale and precise scope. No disposition has been recorded.

| Review artifact | SHA-256 |
|---|---|
| `.specify/memory/constitution.md` | `7542ff7d1ec62f276507a8cd510b0b86da383162b4e53b16d60a0b6902013544` |
| `policies/optimization-v1.yaml` | `57bd05cd6194d611c29a157b4c02425d38ce8e66987898a90404437a896bc84e` |
| `profiles/optimization-skills-v1.yaml` | `41781fc189a729e22627ae416bf02c59e8c3ce9e4d102e92c4c9dfdef2895c45` |
| `specs/011-change-impact-and-freshness/checklists/optimization.md` | `a9f850540c1e23ec24de5dc7547e9144931aa8132c51ac8a37f312465d623934` |
| `.agents/skills/score-architecture/SKILL.md` | `65331ae965bbc98aac44848d99c853c7acce95064d8793174aa74f37b41ea49d` |
| `.agents/skills/score-architecture/references/output.md` | `e56468b4b223dee51213caa6e3750dbbd2a4e981db40e108deb58190d9c84774` |
| `.agents/skills/score-change-impact/SKILL.md` | `11a7b300a0e701e2951fd05b2b6f75aaff50d3fe7f4c9b3291c1ecd4b11aac8d` |
| `.agents/skills/score-change-impact/references/output.md` | `e56468b4b223dee51213caa6e3750dbbd2a4e981db40e108deb58190d9c84774` |
| `.agents/skills/score-component-fmea/SKILL.md` | `a7250ca1812e6fab50c83bd4a45e502d05efdb0247549066f7393f0e8138e2ad` |
| `.agents/skills/score-component-fmea/references/output.md` | `e56468b4b223dee51213caa6e3750dbbd2a4e981db40e108deb58190d9c84774` |
| `.agents/skills/score-dfa/SKILL.md` | `1bd705e33babe23779d8d44a6b022a15558ee2160db9922208ed1c2bf09e7ce8` |
| `.agents/skills/score-dfa/references/output.md` | `e56468b4b223dee51213caa6e3750dbbd2a4e981db40e108deb58190d9c84774` |
| `.agents/skills/score-implementation/SKILL.md` | `6923af35c1b3f2b375b33c1193424729eb6fcad541ab4f0a615744eab66bfb4a` |
| `.agents/skills/score-implementation/references/output.md` | `e56468b4b223dee51213caa6e3750dbbd2a4e981db40e108deb58190d9c84774` |
| `.agents/skills/score-quality-review/SKILL.md` | `4413d155354bb1673b3704df6f0aee74d628f395c92941bc2d75e80e8fbcbc06` |
| `.agents/skills/score-quality-review/references/output.md` | `e56468b4b223dee51213caa6e3750dbbd2a4e981db40e108deb58190d9c84774` |
| `.agents/skills/score-requirements/SKILL.md` | `3860282113d32d1cc4457bfe1cf198a6af694fc83eef3c9dcdd0ddeedbf9f21f` |
| `.agents/skills/score-requirements/references/output.md` | `e56468b4b223dee51213caa6e3750dbbd2a4e981db40e108deb58190d9c84774` |
| `.agents/skills/score-verification/SKILL.md` | `3c84b180539324890e5e809bee799f8aa031b9e8f60fa7314e1a5d313f6338fa` |
| `.agents/skills/score-verification/references/output.md` | `e56468b4b223dee51213caa6e3750dbbd2a4e981db40e108deb58190d9c84774` |

Measured continuation: [qualification](evidence/qualification/README.md). Native scoped
guard/service evidence and ten Flash observations are available. The measured 30.5%
fixture reduction does not accept the live routine target. Bounded tool projection and
pinned per-task budget enforcement were locally verified before the second authorization.
The subsequent `go` approved an additional ten-request Flash comparison capped at $0.10.
[Projection qualification](evidence/projection-qualification/README.md) now measures
66.32–66.60% on unchanged rendering fixtures with equal tool selection and matching outputs.
Both experiments are closed. Real engineering qualification remains pending. The review
artifact hashes above remain unchanged; no owner checkbox or disposition has been changed.

Latest qualification result (2026-10-04): the actual four-request native Fabro/Flash
implementation attempt failed. [Recorded failures and closure](evidence/lifecycle-704-flash/README.md)
remain distinct from the earlier tested Codex patch and controlled fixture measurements.
T032 reviewed hashes remain unchanged; T033 and human engineering acceptance remain pending.

## US15 — temporary owner budget exception and autonomous retry

[Owner instruction](deepseek-budget-exception.md) authorizes this #704-only exception;
all default policy and reviewed T032 bytes remain unchanged. Native Fabro/DeepSeek Flash
produced a valid patch: three parsed JSON configurations, native unit runfiles and the
integration package match baseline semantics, and 113 affected native cases pass. A fresh
corrected-transport graph completes deterministic evidence checks and advisory review,
then reaches the unanswered human gate. All ledgers/server bindings and servers are stopped.
[Review packet](evidence/lifecycle-704-flash-retry/README.md) retains source/patch/usage,
failures, draft evidence responses and an explicit two-envelope historical retention gap.
Five new calls have a peak-price observed upper bound of $0.014952, not an invoice.
T033 acceptance, full native impact/export closure, QNX and B1–B5 savings remain pending.

## Approved #704 subject and local PR preparation

The owner approves the exact US15 patch/advisory response subjects via the current user
session, recorded separately in [lifecycle-704-owner-review.md](lifecycle-704-owner-review.md).
The selected next action is local-only contribution preparation. [PR packet](evidence/lifecycle-704-upstream-packet/README.md)
retains unchanged approved code, exact template/source/storage/hash bindings and full
validation scope. No authenticated native receipt or upstream acceptance is inferred;
human markers, prior evidence and stopped ledgers remain unchanged.

## US19 local binding qualification

Worker/result/collector APIs and both graph packages are implemented and locally tested;
the protected feedback API binds current source and raw fresh-check receipts. Native
collector tests use an explicit replay of the already-approved patch, with 113 cases
passing in each isolated copy. This does not establish new Flash generation, current
live admission, engineering acceptance or paired savings. Actual native API worker and
provider-observer/prompt consumption still need a fresh bounded qualification.
See [the retained packet](evidence/t033-runtime-bindings/README.md).

## US20 actual API evidence

The private command-node API smoke verifies real run/cwd bindings and exact feedback
routing, including missing-check and provider refusals. It reaches unanswered human
gates and closes all owned runtime state with zero provider requests. The explicit
native checkpoint metadata binding preserves all source hashes and rejects unexpected
Git config/HEAD/hooks/links. Retained failures and bounded regression cases accompany
the proof. Provider observation, agent consumption, native impact/expected-set closure
and engineering acceptance remain unqualified.

## US21 offline review findings

Human review now occurs outside current workflow execution. Terminal Fabro success
means report export completed; failed/missing checks and refused admission remain
visible. Reports, raw events/stages, source/result bindings and review questions are
available for offline examination. T032/T033 markers remain pending; neither a
synthetic answer nor an accepted decision is recorded.

## US22 measured native scope findings

The five-target historical minimum is narrower than pinned CI's //... test scope.
The proposed inventory has 135 labels, including 84 integration labels. Native
exports/checks pass after genuine Git metadata binding and exported Need records
are equal. These results establish export comparison, not no-impact or accepted
check applicability. Source/process records retain draft planning/tailoring/role
placeholders; QNX SDK checksum failures prevent full dependency closure. Review
stays offline with the proposed expanded matrix and unresolved inputs.

## US23 local provider capture findings

The old observed meter did not bind response bytes; valid changed candidate content
with unchanged usage could apply. New byte/size, configured source and reasoning
checks close that measured gap. Nineteen focused tests and eight raw local HTTP probes
pass, retaining initial failures, unknown usage reservations and truncated-result
refusals. Endpoints close and bills remain null. Synthetic fixtures establish only
local transport/result behavior; actual Fabro agent feedback consumption, genuine
DeepSeek behavior, native accepted scope and engineering qualification remain pending.
See [the offline report](evidence/t033-provider-capture/review-report.md).

## US24 actual native agent findings

The native engine consumes exact synthetic responses and transmits complete fresh
failed-check feedback through real agent requests. Byte-bound capture and native
output/context/usage reconcile; an unknown-usage refusal retains original source and
stops the second request. Native catalog estimates and default zero counters cannot
become actual bills or known zero usage. Initial vault/path failures are preserved,
and all owned state closes without human workflow nodes. Fixture replies/historical
patch replay remain distinct from live behavior, new generation or accepted scope.
See [the native agent review](evidence/t033-native-agent/review-report.md).

## US25 native correction/recovery findings

Actual native correction consumes exact failed-check feedback, changes candidate source
and receives new bound checks. The local injected fault is fixed while native XML stays
missing. Native command execution launches new operators that refuse replay/collector
order and the explicit interrupted-state marker without further mutation. A correction
without prior failed checks refuses application. Six synthetic replies and nine refusals
are retained; no Fabro checkpoint-resume or live-provider equivalence is inferred.
See [the offline report](evidence/t033-native-recovery/review-report.md) and its next-trial
readiness record. Human decisions remain offline, prior subjects immutable and PR release
deferred. The runtime proof does not close unresolved engineering applicability or T033.

## US26 fresh native-scope choices and admission findings

[The offline review](evidence/t033-p704-admission/review-report.md) proposes complete native
qualification or a bounded Linux experiment with explicit deferred obligations. Neither
choice is accepted here. The 135 labels are discovered inventory, not executed tests.
QNX dependency loading may block Linux analysis irrespective of applicability tailoring.
Both initial request reconstructions exceeded the guard; equal serialization now fits
without dropping source content or relaxing limits. Baseline headroom is 61 bytes and
requires actual no-provider native observation. Effective live model/settings, exact
check denominator, native impact/roles and runtime instructions remain unbound. The
blank decision record and production refusal records keep human decisions offline.

## US27 actual native payload and settings findings

[The offline findings](evidence/t033-native-preflight/review-report.md) distinguish actual
raw native requests, tool-only projection and locally applied proposed parameter
projection. The native emitter's low reasoning/absent JSON controls are measured, and
an explicit optional pinned profile closes that declared-settings gap. Actual captured
implementation payloads fit; baseline headroom is 125 bytes after profile projection.
This does not establish dynamic correction/review fit or effective provider behavior.
Zero paid requests, null usage/bills/savings and pending native decisions remain explicit.
Fresh scoped tests replace carried code results; historical packets remain unchanged.

## US28 dynamic envelope size findings

[The offline report](evidence/t033-stage-envelopes/review-report.md) retains exact stage
inputs and four actual native budget refusals. Candidate content adds about 13 KB;
implementation-only headroom cannot admit complete correction/review context. Fourteen
operator binding adversaries refuse without emission. Complete original/candidate
content and failed/missing evidence are preserved, with no automatic source omission
or budget relaxation. Full-stage bounded retrieval/aggregate accounting is the next
technical gap; current native engineering inputs and real instructions stay unresolved.

## US29 actual bounded MCP findings

[The offline report](evidence/t033-bounded-retrieval/review-report.md) separates
restricted stage source delivery, full native request meters and engineering inputs.
Nine actual native MCP calls include eight successful paired excerpts and one larger
excerpt whose next request is refused. All source/provenance pins and durable budget
refusals are checked. Complete correction output/application is not qualified by the
small advisory replies. Current native denominator/QNX/roles remain offline/unfilled;
T033 acceptance, live savings and publication remain pending.

## US30 complete correction findings

[The offline findings](evidence/t033-complete-correction/review-report.md) retain exact
multi-response source-tool chains, complete candidate replies/applications and new
protected checks/feedback in both arms. Direct earlier-final receipts, substitutions,
stale bindings and truncation refuse. A native length continuation exceeds the unchanged
context guard and stops before delivery; capture leaves worker source/state unchanged.
Run-bound collector directories preserve repeated same-arm measurements. The local
oracle passes after correction, while missing native XML keeps overall checks failed.
Replies/usage remain synthetic, live full-candidate output-token feasibility remains
unmeasured, and native scope/QNX/roles, T033 acceptance and publication stay pending.


## US31 native admission review findings

[The consolidated review](evidence/t033-admission-review/review-report.md) distinguishes
source-backed native identity from unresolved impact applicability and acceptance.
The owner initially preferred complete-native qualification, then clarified that
no QNX license is available and instructed us to skip QNX. The current draft proposes
native qualification with QNX deferred; reviewer names remain unspecified.
The bounded five-target Linux alternative retains six semantic rows and explicit deferrals.
QNX's checksum mismatch remains unresolved and Linux tailoring alone does not repair
Bazel dependency loading. Named scope/verification roles and readiness references remain
unfilled. The new decision form binds exact subjects without accepting them; later
human decisions use a separate copy and remain outside the workflow. Prior T032 and
patch approval retain their exact scope, and no real execution follows from this review.


## US32 Linux loading findings

[The measured probes](evidence/t033-linux-loading/review-report.md) preserve
QNX execution deferral without SDK substitution or native source/lockfile changes.
Linux loading remains incomplete: cached overrides, configured analysis and warm
reuse all require public Python metadata. Cache availability and embedded-tool
bootstrap failures are recorded separately. Three metadata refusals stop repetition;
no compilation/test pass, QNX closure, live trial or human acceptance follows.
Prepare public metadata under explicit QNX denial before another bound Linux probe.


## US33 metadata preparation findings

[The bound findings](evidence/t033-python-metadata/review-report.md) distinguish the
prepared 68-page public mirror from the 67-page input actually consumed. Native QNX
and unlisted registry downloads refuse; source and lockfiles remain unchanged.
Writable cache plus lock-bound registry imports clear the original 67-package
failure. The additional roman-numerals page is now ready for a fresh bounded Linux
analysis. No native build/test, engineering acceptance or live provider claim follows.

## US34 complete metadata and public module dependencies

[The bound findings](evidence/t033-linux-analysis/review-report.md) record four native
Linux analysis failures after successful consumption of all 68 metadata pages. The
final failure denies the pinned Rust module archive URL; its exact archive and module
version patch are absent from retained cache inputs. The rules_perl archive passes
integrity verification and produces a real cache hit, followed by filename rejection.
A filename-preserving loopback route remains unqualified, with no archive HTTP request
or successful extraction observed in the final probe. The bounded stage stops and
exports closed process/mirror records. QNX remains skipped; full native scope/impact,
reviewer authority, compilation/tests and live feasibility remain pending offline.

## US35 verified module inputs and positive pilot loading

[The bound findings](evidence/t033-public-modules/review-report.md) distinguish verified
public inputs, native archive delivery, seven completed module repositories and the
successful direct query of five pilot labels. Configured Linux analysis remains failed
on Bats; its source-bound core/default helper pins are prepared as the next input plan.
Kotlin delivery lacks a completed repository/extraction result. Eight native attempts
stop with closed mirrors/processes, unchanged source and QNX denied. No build/test,
full native expected-set/impact closure, live trial or engineering acceptance is implied.

## US36 Bats source completion and cached Linux Buf input draft

[The bound findings](evidence/t033-bats-dependencies/review-report.md) record four
verified Bats archives, two completed core aliases and completed Kotlin extraction.
Configured analysis still fails at the Linux Buf executable. Its checksum list is
bound to the original native lock; three exact executables exist in verified cache
and a concrete cache-only next-stage draft retains their sizes and exclusion here.
The first Python runtime mismatch and unknown interrupted delivery remain historical;
corrected probes use Python 3.12.14 and explicit write-completion records. No current
binary input acceptance, tool qualification, build/tests or broader native acceptance
is inferred; human engineering decisions remain offline.

US37 review subjects: exact cached Buf executable/checksum/source bindings, completed
native repository hashes/modes and sixteen complete response writes; one failed configured
Linux probe reaching the next pinned Ferrocene compiler dependency. No compiler payload
is admitted or fetched. Missing cache inputs, sizes and payload licensing/tool qualification
remain explicit in the offline draft. QNX stays skipped; no engineering decision is accepted.
See [the sealed report](evidence/t033-buf-tools/review-report.md) for full raw/provenance records.

## US38 Linux Ferrocene follow-up

[Offline report](evidence/t033-ferrocene-linux/review-report.md): exact Linux compiler,
coverage-tools and Miri payloads are hash-verified and materialize in completed native
repositories. Configured analysis still fails at unlisted Linux Coreutils 0.1.0; its
source-bound checksum/cache absence and unknown size/notices remain explicit. The
1 TiB image is mounted, capacity registration is reconciled per the owner, and fresh
read-only input bindings preserve old workspace records. Reader/operator refusals,
current validation, source-bound prior checks and complete preservation/closure are
retained. T032 historical acceptance and human markers stay unchanged. Broader native
scope/impact/roles/tool qualification/live acceptance remain pending offline.

## US39 Linux Coreutils follow-up

[Offline report](evidence/t033-coreutils-linux/review-report.md): exact native-bound
Coreutils acquisition, actual inventory/license and independent repository query are
measured. Release asset digest stays null; native extracted executable hash/mode and
marker pass. Configured analysis still fails at the original-lock-bound Linux GCC
12.2.0 package. Its public metadata gives matching digest and size, but actual payload/
notices and qualification remain unmeasured; current file/byte/new-payload bounds forbid
adding it. All prior subjects and human markers stay preserved; scope/impact/roles/live
and engineering acceptance remain pending offline, with QNX skipped and publication deferred.

## US40 Linux GCC follow-up

[Offline report](evidence/t033-gcc-linux/review-report.md) binds exact GCC archive,
actual notices, builder sources and completed independent native repository loading.
Configured Linux analysis now fails at the unlisted jq 1.7 binary; its native SHA-384,
public size/digest fields and limited cache inspection remain explicit. No jq payload
or compiler execution occurs. Fresh validation and unchanged historical/source/review
subjects remain bound. Full native scope/impact/roles/tool qualification/live acceptance
stay pending offline. T032/T033 human markers, QNX skip and publication deferral persist.

## US41 Linux jq follow-up

[Offline evidence](evidence/t033-jq-linux/review-report.md) binds exact native SHA-384,
actual standalone binary/ELF findings, measured SHA-256 and separate jq/Oniguruma source
licenses. Independent repository loading passes without payload execution. Configured
Linux analysis stops at unlisted BSD tar v3.8.1-fix.1; its original native checksum,
wrapper/module/registry metadata and canonical URL migration are preserved explicitly.
The retained collector refusal does not cause a native retry or binary admission.
All historical/source/reviewed subjects and human markers stay unchanged. Full native
scope/impact/roles/tool qualification/live acceptance remain pending offline.

## US42 Linux BSD tar follow-up

[Offline evidence](evidence/t033-bsdtar-linux/review-report.md) binds exact binary/native
SHA-256, separate source licenses/patch, static findings and completed independent
repository loading without payload execution. Configured analysis fails at zstd; one
inherited GCC response is interrupted and its actual transferred bytes remain unknown.
The retained collector refusal is corrected through truthful separate write counts,
without a native retry. Native zstd source/cache/checksum is bound, but public size/
canonical/digest metadata remains unqueried because the budget is exhausted. All prior
subjects/human markers remain unchanged; broader native/impact/roles/tool/live acceptance
stays pending offline, with QNX skipped and publication deferred.

## US43 Linux zstd follow-up

[Complete evidence](evidence/t033-zstd-linux/review-report.md) binds native SHA-256,
separate source licenses/patches, static findings and independent repository loading.
Configured Linux analysis advances to the original pinned Debian OCI image and stops at
its out-of-scope token endpoint. Native image/platform/digest and rules_oci sources are
bound; registry/object size and closure remain unknown, without token/credential/image
acquisition or execution. Preserve all previous subjects and pending human/native/live
acceptance; next inspect exact OCI closure under fresh finite bounds.

## US44 Debian OCI follow-up

[Complete evidence](evidence/t033-debian-oci/review-report.md) binds real verified cache-only
image object preparation, descriptor/diff-ID integrity, bounded inventory/notices and
independent native repository loading. Anonymous acquisition/authentication is not tested;
source-supported token-failure fallback keeps native objects exact without token persistence.
Configured Linux analysis advances to original-pinned score_cpp_policies 0.1.1 and stops
outside scope. Preserve source/locks/warning policy, prior evidence and human markers;
measure exact next archive provenance/size under new finite bounds.


Autonomous 011 checkpoint: the original and approved historical candidate each
pass all five Linux native tests (113 cases each), with preserved parsed profiles,
runfiles and tar path/content. See evidence/t033-autonomous-native/review-report.md.
This closes the scoped local test gap only. Full native reverse impact now needs
locked watchfiles 1.2.0; real B1–B5 qualifications, engineering applicability and
T033 acceptance remain incomplete. No new human decision or provider grant is made.

See evidence/t033-docs-impact/review-report.md for equal scoped 94-target closures,
three added native loadfiles and preserved dependency/coverage failures. The next
prerequisite is compatible disposable Linux execution for pinned native tools.
T032's subjects/approval are unchanged; T033 and real B1–B5 remain incomplete.

## Compatible runtime and oracle checkpoint

[Bound runtime report](evidence/t033-linux-runtime/review-report.md) records exact
Ferrocene/LLVM execution in a disposable mount namespace, with verified image
libraries and no host library change. Original B3 coverage passes three cases;
a held-out handler test passes four and detects a wrong-status mutant. B2 measures
two C++ allocations per actual getter/setter call. Neither establishes accepted
engineering scope or paired provider savings. Native mapping inventories remain
partial; original docs export stops at the pinned Aspect unpack binary. Existing
T154/T156 cover the successor and missing inputs; no duplicate task or human
checkbox change is made. The operator option-order failure and correction remain
explicit. Future sessions use bounded output, targeted reads and hash-verified
carried checks under the owner's credit-efficiency instruction.

## Native documentation export follow-up

[Bound export report](evidence/t033-aspect-export/review-report.md) records fresh
original and approved candidate `//:needs_json` success after six exact pinned public
tool inputs. Both arms retain 144 Lifecycle, 1,251 Process and 916 Platform records;
all IDs and native values equal their historical exports. The stale P704 cache binding
is refused rather than rewritten. Intermediate dependency failures are preserved.
Actual Sphinx-Needs 8.5.0 exports do not establish compatibility with the catalogue
importer's pinned 8.3.1 producer contract. Native applicability/complete expected sets,
B1 selection, B2 production correction, full B3/RPC qualification, accepted B4/B5
inputs, fresh paid budgets and offline T033 acceptance remain unresolved.
[Remaining B3 inventory](evidence/t033-aspect-export/remaining-B3-coverage.json)
separates summary denominators from explicit LCOV locations; no missing locations are
invented. Existing T154/T156 remain partial and human markers are unchanged.

## Producer contract and extended B3 evidence

[Bound report](evidence/t033-producer-contract/review-report.md) measures the actual
docs-as-code8.3.0 / Sphinx-Needs8.5.0 pair against the existing8.2.0/8.3.1 baseline.
Native archive and metamodel bytes are verified; the schema is unchanged but relation,
type and option definitions change. An [explicit profile proposal](evidence/t033-producer-contract/architecture-draft.md)
preserves v1/default/source locks and remains proposed, unimplemented and unaccepted.
Complete immutable consumer source/namespace bindings and real conformance remain open.
Eight original-plus-extended B3 cases pass; summary132/182 lines,39/56 branches,10/12
functions. A wrong-rejection-reason mutant fails exactly one new case; seven pass.
Controlled graph peers do not qualify RPC transport, production graph behavior or full
issue685 coverage. A demonstrated capture gap causes one finite evidence refresh;
raw ZIP/text-format error and corrected capture remain explicit. Existing witnesses
are preserved; no provider requests or human decisions are made.
