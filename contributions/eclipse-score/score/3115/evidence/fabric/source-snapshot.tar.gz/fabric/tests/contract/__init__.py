"""Contract test package."""
