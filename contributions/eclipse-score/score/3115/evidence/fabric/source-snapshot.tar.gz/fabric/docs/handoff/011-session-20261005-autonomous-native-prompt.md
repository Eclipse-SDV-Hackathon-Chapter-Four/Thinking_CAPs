Continue increment 011 autonomously in:

/home/jefferson/s-core_sw_fabric

Resume the existing persistent Goal if supported; create it only if none exists:
complete increment 011 against its specification and acceptance requirements, with
verified evidence and preserved engineering boundaries. Do not mark it complete
while required evidence or acceptance remains missing.

Start by reading AGENTS.md, .specify/memory/constitution.md, the active 011
specification/plan/tasks/acceptance, and the latest verified handoff:

docs/handoff/011-session-20261005-autonomous-native.md
docs/handoff/011-session-20261005-autonomous-native.json

Verify the snapshot and preserved subjects before continuing. If a newer verified
handoff exists, use it. The current next prerequisite is original-lock-resolved
score_docs_as_code 8.3.0's watchfiles==1.2.0 requirement. The exact native block,
allowed hashes, source bindings and proposed unstarted finite envelope are in
specs/011-change-impact-and-freshness/evidence/t033-autonomous-native/next-prerequisite/.
The original and approved historical candidate each already passed all five Linux
tests (113 cases each) with raw XML/logs and all three profile/runfile/tar checks.
Carry those measurements only by exact bindings; do not repeat them unchanged.
The full original reverse query failed at watchfiles; candidate query is unattempted.

AUTONOMOUS AUTHORITY

I authorize the remaining reversible technical work necessary for 011: dependency
discovery and preparation, public source/tool acquisition, fabric implementation
fixes, scoped Linux native analysis/builds/tests and necessary disposable test
containers, validation, convergence, benchmark preparation and complete offline reports.

This authorization covers successive dependency stages. Do not stop after each
missing dependency or ask me to say “go” again. Historical single-stage stopping
instructions do not require renewed permission for work covered here. Preserve each
stage’s evidence, declare fresh finite limits for its successor, and continue.

Stay within 011. Do not start 012, publish, push, merge, release, deploy, change global
storage, introduce a scheduler or synthesize engineering decisions.

WORKING METHOD

1. Use Spec Kit to track actual remaining obligations. Add tasks only for demonstrated
gaps. Keep spec, plan, tasks, coverage and acceptance consistent. Completing existing
checkboxes alone is insufficient.

2. Follow the native dependency chain from exact source/lock bindings. Measure cache
availability, provenance, integrity, licensing evidence and sizes before acquisition.
Prefer verified cache reuse. Establish finite request, download, storage, archive,
execution and retry limits before each stage.

3. A newly discovered dependency ends that bounded probe, not the overall task. Preserve
the failure, prepare the next admissible stage and continue without renewed permission.
Do not repeat unchanged failures blindly, silently widen sealed limits, remove mandatory
checks or change native policy to obtain success.

4. Use score-fabric storage and score_sw_fabric.storage. The registered build image should
be 1 TiB; mounting it is authorized if needed. Verify writable Linux capabilities and
fresh volume bindings. Stop on disconnection. Preserve historical bindings, sealed
packets, dirty user work and reference repositories. Keep credentials/private state
internal and ephemeral bearer tokens out of SSD evidence and logs.

5. QNX remains skipped because I have no license. Preserve unresolved applicability
honestly. Keep Spec Kit responsible for fabric development, S-CORE for engineering
semantics/artifacts and Fabro for execution/run state.

6. Run appropriate frozen dependency, Ruff, mypy, pytest, foundation, package and native
checks. Reuse unchanged validation only with exact source bindings and explicit carried
evidence labels. Investigate failures and retain unsuccessful evidence. Avoid redundant
testing and rereading unchanged files.

7. Complete real native validation and prepare the remaining B1–B5 qualification work.
Additional paid provider calls require a fresh explicit provider/model/request/spending
budget; closed historical budgets cannot be reused. Finish all independent authorized
work before presenting one consolidated request for genuinely missing authority or inputs.

8. Preserve T032’s recorded approval and human-owned markers. Human engineering acceptance
stays offline. Never infer acceptance from tests, emulator replies, fixtures, agent
assertions or Fabro success. Do not claim 011 complete while mandatory T033 evidence
or acceptance is missing.

CONTEXT HANDOFF — MANDATORY

Monitor remaining context whenever the interface/runtime exposes it. When it falls
BELOW 20%:

- Stop starting new work.
- Safely finish or terminate owned operations; retain partial results and failures.
- Save a verified Markdown/JSON handoff under docs/handoff/, without modifying sealed packets.
- Save a copy-ready continuation prompt under docs/handoff/.
- Include exact current files, hashes, workspace/storage bindings, completed work, open
  obligations, failures, next commands, authority and budgets in the handoff.
- Carry this entire autonomous authority and below-20% rule into the new prompt.
- Pause any active Goal; I explicitly authorize that conditional pause.
- Return the handoff links and continuation prompt, then end the session.

If remaining context percentage is unavailable, state that limitation rather than
inventing a reading. Use an explicit low-context warning to checkpoint conservatively.

Keep concise progress updates during execution. Otherwise continue until 011’s
completion requirements are verified or only genuine external blockers remain.
For external blockers, finish independent work first, export a concrete review packet
and identify exactly what is needed. Report incomplete status truthfully.

End every final response with “Next step:” and “Recommended model:” as AGENTS.md requires.

VERIFIED RESUME COMMANDS

Use these as initial read-only checks; do not execute an old probe unchanged:

```bash
export SPECIFY_FEATURE_DIRECTORY="$PWD/specs/011-change-impact-and-freshness"
export PATH="/media/jefferson/11c42dee-73a3-4c2b-ab42-a0440011d9e0/.s-core-build/runs/score-fabric-xxefvd8p/bin:$PATH"
.venv/bin/score-fabric storage status
bash .specify/scripts/bash/check-prerequisites.sh --json --require-spec --require-tasks --include-tasks
```

Read next-prerequisite/readiness.json and declared limits. Prepare only compatible
exact native-hash-bound watchfiles bytes after fresh provenance/cache/size/license
measurements; the known working transport is task-local PIP_CONFIG_FILE with no-index
and exact wheelhouse. Native pins, isolated pip mode and hash checks remain mandatory.
Pinned native query expressions and scripts are retained under the packet's
operator-scripts/ and native-probes/. Create a new envelope/probe name; stop each
probe on its first new dependency and continue its successor. Root helpers are snapshots,
not a scheduler and not an authority source. A later broader docs-wheel group must
receive independent measured finite limits; it cannot reuse the 14-wheel tooling grant.
