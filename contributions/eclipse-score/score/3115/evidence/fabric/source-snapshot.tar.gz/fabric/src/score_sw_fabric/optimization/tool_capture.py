"""Verify completed source-tool exchanges before selecting a structured final reply."""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

from score_sw_fabric.optimization.common import (
    OptimizationError,
    checked,
    integer,
    json_object,
    raw_file,
    record,
)
from score_sw_fabric.optimization.stage_retrieval import StageSources
from score_sw_fabric.process_source.reader import InputError


def completed_tools(raw: bytes) -> dict[str, Any]:
    """Decode only complete JSON/SSE tool turns; never salvage a candidate reply."""
    try:
        return _completed_tools(raw)
    except (KeyError, TypeError, AttributeError, UnicodeError) as error:
        raise OptimizationError("TOOL_RESPONSE_INCOMPLETE") from error


def _completed_tools(raw: bytes) -> dict[str, Any]:
    if len(raw) > 2_000_000:
        raise OptimizationError("RESPONSE_SIZE")
    if not raw.startswith(b"data:"):
        envelope = json_object(raw)
        choices = envelope.get("choices")
        if (
            envelope.get("model") not in {"deepseek-flash", "deepseek-v4-flash"}
            or not isinstance(choices, list)
            or len(choices) != 1
            or choices[0].get("index") != 0
            or choices[0].get("finish_reason") != "tool_calls"
        ):
            raise OptimizationError("TOOL_RESPONSE_INCOMPLETE")
        message = choices[0]["message"]
    else:
        calls: dict[int, dict[str, Any]] = {}
        text = ""
        done = stopped = False
        for line in raw.splitlines():
            if not line:
                continue
            if done or not line.startswith(b"data: "):
                raise OptimizationError("TOOL_RESPONSE_INCOMPLETE")
            if line == b"data: [DONE]":
                done = True
                continue
            frame = json_object(line[6:])
            choices = frame.get("choices")
            if (
                frame.get("model") not in {"deepseek-flash", "deepseek-v4-flash"}
                or not isinstance(choices, list)
                or len(choices) > 1
            ):
                raise OptimizationError("TOOL_RESPONSE_INCOMPLETE")
            for choice in choices:
                if choice.get("index") != 0 or stopped:
                    raise OptimizationError("TOOL_RESPONSE_INCOMPLETE")
                delta = choice.get("delta", {})
                if not isinstance(delta, dict):
                    raise OptimizationError("TOOL_RESPONSE_INCOMPLETE")
                fragment = delta.get("content")
                if fragment is not None:
                    if not isinstance(fragment, str):
                        raise OptimizationError("RESPONSE_CONTENT")
                    text += fragment
                fragments = delta.get("tool_calls", [])
                if not isinstance(fragments, list):
                    raise OptimizationError("TOOL_RESPONSE_INCOMPLETE")
                for part in fragments:
                    if not isinstance(part, dict) or set(part) - {
                        "index",
                        "id",
                        "type",
                        "function",
                    }:
                        raise OptimizationError("TOOL_RESPONSE_INCOMPLETE")
                    index = integer(part["index"], maximum=9)
                    target = calls.setdefault(
                        index,
                        {"id": "", "type": "function", "function": {"name": "", "arguments": ""}},
                    )
                    if part.get("type", "function") != "function":
                        raise OptimizationError("TOOL_RESPONSE_INCOMPLETE")
                    function = part.get("function", {})
                    if not isinstance(function, dict) or set(function) - {"name", "arguments"}:
                        raise OptimizationError("TOOL_RESPONSE_INCOMPLETE")
                    for key, value in {"id": part.get("id", ""), **function}.items():
                        if not isinstance(value, str):
                            raise OptimizationError("TOOL_RESPONSE_INCOMPLETE")
                        destination = target if key == "id" else target["function"]
                        destination[key] += value
                        if len(destination[key].encode()) > (8192 if key == "arguments" else 128):
                            raise OptimizationError("TOOL_RESPONSE_INCOMPLETE")
                finish = choice.get("finish_reason")
                if finish is not None:
                    if finish != "tool_calls":
                        raise OptimizationError("TOOL_RESPONSE_INCOMPLETE")
                    stopped = True
        if not done or not stopped or sorted(calls) != list(range(len(calls))):
            raise OptimizationError("TOOL_RESPONSE_INCOMPLETE")
        message = {
            "role": "assistant",
            "content": text or None,
            "tool_calls": [calls[index] for index in sorted(calls)],
        }
    if (
        not isinstance(message, dict)
        or message.get("role") != "assistant"
        or message.get("content") is not None
        and not isinstance(message["content"], str)
        or not isinstance(message.get("tool_calls"), list)
        or not 1 <= len(message["tool_calls"]) <= 10
    ):
        raise OptimizationError("TOOL_RESPONSE_INCOMPLETE")
    identifiers = set()
    for call in message["tool_calls"]:
        if (
            not isinstance(call, dict)
            or set(call) != {"id", "type", "function"}
            or not isinstance(call["id"], str)
            or not 1 <= len(call["id"].encode()) <= 128
            or call["id"] in identifiers
            or call["type"] != "function"
            or not isinstance(call["function"], dict)
            or set(call["function"]) != {"name", "arguments"}
            or not isinstance(call["function"]["arguments"], str)
        ):
            raise OptimizationError("TOOL_RESPONSE_INCOMPLETE")
        identifiers.add(call["id"])
        json_object(call["function"]["arguments"].encode())
    return {
        "role": "assistant",
        "content": message.get("content") or None,
        "tool_calls": message["tool_calls"],
    }


def verify_tool_link(
    root: Path,
    source: dict[str, Any],
    stage: str,
    instruction: dict[str, Any],
    previous: dict[str, Any],
    following: dict[str, Any],
    *,
    worker_binding: str | None = None,
    candidate: str | None = None,
    check_sha256: str | None = None,
) -> None:
    """Require an unchanged message prefix and exact manifest-bound source results."""
    try:
        _verify_tool_link(
            root,
            source,
            stage,
            instruction,
            previous,
            following,
            worker_binding=worker_binding,
            candidate=candidate,
            check_sha256=check_sha256,
        )
    except OptimizationError:
        raise
    except InputError as error:
        raise OptimizationError(str(error.code)) from error
    except (KeyError, TypeError, AttributeError, UnicodeError) as error:
        raise OptimizationError("TOOL_SOURCE_BINDING") from error


def _verify_tool_link(
    root: Path,
    source: dict[str, Any],
    stage: str,
    instruction: dict[str, Any],
    previous: dict[str, Any],
    following: dict[str, Any],
    *,
    worker_binding: str | None = None,
    candidate: str | None = None,
    check_sha256: str | None = None,
) -> None:
    pin = source["instruction_sha256"]
    directory = "provider-records/" + pin + "/"
    response, _ = raw_file(
        root, directory + f"response-{previous['ticket']:02d}.raw", previous["response_sha256"]
    )
    assistant = completed_tools(response)
    before, _ = raw_file(
        root, directory + f"request-{previous['ticket']:02d}.json", previous["request_sha256"]
    )
    after, _ = raw_file(
        root, directory + f"request-{following['ticket']:02d}.json", following["request_sha256"]
    )
    earlier, later = json_object(before)["messages"], json_object(after)["messages"]
    calls = assistant["tool_calls"]
    if (
        not isinstance(earlier, list)
        or not isinstance(later, list)
        or later[: len(earlier)] != earlier
        or len(later) != len(earlier) + 1 + len(calls)
    ):
        raise OptimizationError("TOOL_CONVERSATION_DRIFT")
    actual = later[len(earlier)]
    # The native codec omits null assistant content during tool-only turns.
    if isinstance(actual, dict) and "content" not in actual and assistant["content"] is None:
        actual = {"content": None, **actual}
    if actual != assistant:
        raise OptimizationError("TOOL_CONVERSATION_DRIFT")
    allowed = instruction.get("tool_projection", {}).get("allowed_tools", [])
    view_root, manifest = Path(source["tool_root"]), Path(source["tool_manifest"])
    if not view_root.is_relative_to(root) or not manifest.is_relative_to(view_root):
        raise OptimizationError("TOOL_SOURCE_BINDING")
    manifest_raw, _ = raw_file(view_root, manifest.relative_to(view_root).as_posix())
    view = StageSources(view_root, manifest, hashlib.sha256(manifest_raw).hexdigest(), stage)
    artifacts = view.value["artifacts"]
    candidate_raw, _ = raw_file(
        view_root, artifacts["candidate"]["path"], artifacts["candidate"]["sha256"]
    )
    if (
        worker_binding is not None
        and artifacts["binding"]["sha256"] != worker_binding
        or candidate is not None
        and json_object(candidate_raw)["digest"] != candidate
        or check_sha256 is not None
        and artifacts["checks"]["sha256"] != check_sha256
    ):
        raise OptimizationError("TOOL_SOURCE_BINDING")
    for call, result in zip(calls, later[len(earlier) + 1 :], strict=True):
        name = call["function"]["name"]
        if name != "mcp__score_bounded__get_source_excerpt" or "get_source_excerpt" not in allowed:
            raise OptimizationError("BOUNDED_TOOL_REQUIRED")
        args = json_object(call["function"]["arguments"].encode())
        if set(args) != {"path", "start", "end"} or args["path"] not in view.sources:
            raise OptimizationError("TOOL_SOURCE_BINDING")
        if Path(args["path"]).suffix.lower() in {".json", ".jsonl", ".sarif", ".xml", ".log"}:
            raise OptimizationError("RAW_STRUCTURED_EVIDENCE_FORBIDDEN")
        start = integer(args["start"], minimum=1)
        end = integer(args["end"], minimum=start, maximum=start + 249)
        data, raw = raw_file(view_root, args["path"], view.sources[args["path"]])
        lines = data.decode().splitlines()
        text = "\n".join(lines[start - 1 : end])
        if start > len(lines) or len(text.encode()) > 3000:
            raise OptimizationError("TOOL_SOURCE_BINDING")
        expected = record(
            "source_excerpt",
            raw=raw,
            start=start,
            end=min(end, len(lines)),
            text=text,
            stage_binding=view.result_binding(),
        )
        if (
            result.get("role") != "tool"
            or result.get("tool_call_id") != call["id"]
            or not isinstance(result.get("content"), str)
            or checked(json_object(result["content"].encode()), "source_excerpt") != expected
        ):
            raise OptimizationError("TOOL_RESULT_DRIFT")
