# Rust API queue terminal collection in progress

All 13 revised native jobs have started. At the observer snapshot recorded in the
machine handoff, eight terminal packets were collected and five jobs were active.
No counter, workflow definition, selected volume or running queue was reset/migrated.
The operator collector now uses native per-run replayable SSE, not dispatch logic.

Continue the live collector at the queue root recorded in the machine handoff. Never
rerun admission/start scripts or restart the original archived IDs. DeepSeek Flash
remains the sole provider/model for scope/draft/corrections/supervision. New issues
retain a maximum of three correction attempts; #1265 remains zero-fix historical reuse.
Successful native exports can retain failed checks and missing reviews.

After all 13 terminal packets are collected, run the prepared `finalize_results.py`
using `uv run --frozen python` from this repository. It verifies final evidence and
models, preserves failures, checks previous sealed packets, stops only the owned new
Docker/private Fabro processes and seals a sibling results packet. Inspect its results
and write a final verified handoff. Do not publish, accept or launch more model runs.

Runtime findings to preserve: duplicate lint rc loading; relocation/delete/rename and
native JSON read capability gaps for #741; missing written #1263 supervisor review;
#560 compile failure and first correction's provider network failure (one of three
slots used, current subject hashes match). #741's patch is only a boundary-probe file.

Existing sealed contribution packets remain unchanged. Individual collected issue
packets are sealed too; add final metadata beside them rather than rewriting them.
The root results packet is not yet sealed. The external SSD must remain connected;
validate its existing binding before operations, and stop on disconnect.

Next step: finish collecting all 13 native terminal packets and seal the results.
Recommended model: deepseek-flash — mandatory for any authorized Fabro agent work.
