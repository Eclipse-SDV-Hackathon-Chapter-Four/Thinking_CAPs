# Rust queue: independent Claude review (offline)

This supersedes, for continuation purposes only, `011-session-20261007-rust-recovery-review.md`.
The bounded-results handoff JSON/binding remains authoritative for the goal, baseline
`381d43dec900ab6a9076f3f30e7bfbdee019e26e`, packets and services. **No native run is
active. All owned Fabro and Docker services remain stopped.**

## What this session did

Claude ran read-only, outside Fabro.

- Verified the handoff hashes.
- Rehashed every payload of ten packets, with zero mismatches.
- Reconciled the correction ledgers: 35/36, no inconsistency.
- Re-derived the #1261 blockers from sealed source, logs and `driver.py`, and read two
  baseline blobs.
- Made no source edits, builds, test reruns, native or paid runs, commits or publication.

New sealed packet: [score-rust-claude-independent-review-20261007](/home/jefferson/eclipse_sdv_hackathon_2026/contributions/rust-api-queue/score-rust-claude-independent-review-20261007/review.md).
It has 5 payloads, manifest SHA-256 `ebc62c163f2644c34e764c2f75c5dab5111a4f93f8067e5136980d5b96745be5`.

## Key findings

- **#1261 measured blockers confirmed.** The `MergeAdditionalConfiguration` signature line was
  replaced by the new function's first line (a diff-splice). The regression plan was written to
  the source path instead of `.rust-queue/reports/`. 0/5 tests ran, and 0 SARIF reports exist.
- **The callback leak comes from the baseline.** The empty find-service `dispose` at baseline
  `registry_bridge_macro.h:189` already affects `find_service`. The candidate amplifies it by
  holding a strong `Arc` per watch. Recovery-plan item 4 should be split:
  - a local repair: capture the stream state weakly (`Weak`);
  - a separate native ownership decision: callback reclamation (D3).
- **New static concerns:**
  - `IRuntime` virtual inserted mid-vtable;
  - unsynchronized `AddConfiguration` versus discovery read, and a stale cache;
  - unproven complete/empty-snapshot callback semantics;
  - no runtime `Err` items;
  - a module doc that wrongly claims bounded allocation.
- **Other issues.** For 1264, 1263, 794, 781, 782, 1062 and 490, the check "failures" are
  the duplicate `clippy_strict` aspect launcher defect, one to one, while the selected tests
  passed. Their lint evidence is missing, not refuted. #741's query fails on the unrelocated
  package. #490's test group failed loading `rules_python`.
- **Smallest complete #1261 scope:** repairs R1–R7, plus decisions D1–D6, where D2/D4 have
  recommended options and D3 is tracked separately. See `recovery-scope.json`.

## Persistent limits (unchanged)

- #1261 and #250: **3/3, STOP.** The other exhausted issues stay stopped.
- Original queue: 35/36. The remaining slot belongs only to #173 (2/3), and no defect
  justifies spending it.
- #560 Codex extra allowance: 1/3 used, 560-only, non-transferable.
- Native runs use DeepSeek Flash only (`deepseek` / `deepseek-v4-flash`, no fallbacks).
- Claude has no source-edit authority.
- Any R1–R7 execution needs explicit new #1261 authority that names the editor, model and
  budget.
- D1–D6 are offline human decisions.
- Generic "go" or "resume" does not reset or transfer counters.
- SSD image `/media/jefferson/11c42dee-…` (UUID `002B-CE31` backing) was mounted ext4 rw
  at review time. Validate it again before any dependent work, and stop on disconnect.
- No commit, push, PR, comment, closure, merge, release or deployment is authorized.

Next step: offline human decisions D1 (universe scope), D2 (buffering/error contract) and D4 (ABI), then decide whether to grant a new #1261 allowance.
Recommended model: claude-opus-5-5 (high) for any further offline architecture review; native runs stay deepseek-v4-flash under the existing preference.
