# T033 — real-target paired benchmark plan

Status: **prepared locally; live execution and engineering qualification pending**.
The owner's `go` follows the proposed preparation of this plan. PR publication is
deferred. This extends increment 011 and does not start increment 012.

[Case plan](evidence/t033-benchmark-plan/case-plan.json) and
[source bindings](evidence/t033-benchmark-plan/source-bindings.json) identify the
pilot and unresolved inputs. Historical evidence and all 20 T032 subjects are preserved.

## Comparison

Question: does context selection reduce actual provider uncached input while preserving
the same engineering task, required checks, evidence and offline human review obligations?

Both fresh Fabro arms start from identical untouched source and receive identical task
intent and output contracts. Pin the same model/settings, selected tools, collector
commands, retry limits and advisory and offline human review obligations. The baseline receives full permitted
task context; the optimized arm receives deterministic impact-selected L0/L1 context,
selected Skills and bounded L2 access to the same permitted evidence. Retain every
inclusion/omission with source hashes and rationale. Never disable baseline guards.

Use identical tool declaration projection in both arms, isolating context selection.
The earlier fixture result primarily measured tool-schema projection; measure that
effect separately if needed. If full baseline context exceeds a shared ceiling,
record an inadmissible comparison; do not truncate it or relax just one arm's limits.

## Coverage

| Case | Activity | Initial target | Preparation still needed |
| --- | --- | --- | --- |
| P704 | Configuration/build deduplication | Lifecycle #704 at `7d1d7bec81d96752b5a9a235044d2dfc3ecd259b` | Paired contexts/graphs, expected-set closure and admission |
| B1 | Metadata change | Unselected | Real metadata scope, native identities and validation oracle |
| B2 | Local C++ correction | Unselected | Real defect, independent reproducer and affected source/tests |
| B3 | Unit-test change | Unselected | Real test gap, failure witness and actual test change |
| B4 | Component feature | Unselected | Accepted requirements/interfaces and verification obligations |
| B5 | Safety/architecture | Unselected | Accepted applicability/coupling inputs and authorized reviewer roles |

P704 is an additional pilot. It cannot substitute for a C++ correction, new unit tests,
component feature or safety/architecture work. Its safety/security-sensitive settings
support the earlier conservative S3 classification, not B5 coverage. Reclassify the
new task envelope deterministically. Unselected cases are future dependencies, not
claims of five measured cases.

## P704 sources and oracle

Deduplicate the common service-type definition while preserving all three effective
JSON profiles, labels, runfiles and integration package paths. Give both arms the
original JSON and BUILD files. Keep the approved patch, final-source files, model
replies and advisory responses outside both agent inputs as evaluator-only references.

Allowed edits are one new `config/mw_com_config.bzl`, three BUILD files and removal of
their three JSON files; the case plan lists all seven paths. Out-of-envelope changes
fail the scope predicate. Different Starlark implementations are allowed: compare
measured semantics/behavior, not equality to the previously approved code hash.

The retained native declaration is `feat_arc_sta__lifecycle__cfg_params_static`,
version `1`, status `valid`, from `docs/features/lifecycle/architecture/index.rst`.
This source citation does not establish a validated export or complete native check set.

| Measured minimum | Required fresh outcome in each arm |
| --- | --- |
| Three generated configurations | Parsed objects equal their respective originals; preserve ordered arrays and every per-profile value |
| Provider/client unit runfiles | Original paths and parsed JSON values remain available |
| Integration tar | `tests/switch_run_target/etc/mw_com_config.json` retains its path and parsed values |
| Five affected native targets | Execute all five; retain raw XML/logs and separate failure/error/skip/missing counts |
| Buildifier 8.5.1 | Format/lint changed Starlark/BUILD files; retain mechanical formatting separately |
| Portable patch | Clean application against original pinned source; complete changed-path inventory |
| Source/consumer sweep | Account for consumers and changed/new dependencies; preserve unresolved native impact/export obligations |
| Offline human review | Identical review obligations; export reports and exit; no human workflow node or synthetic decision |

Historical target counts are 3, 2, 36, 71 and 1 (113 total). Each new arm must execute
its own candidate; reused XML cannot count as fresh paired verification. Explain changed
case counts rather than forcing them to 113. These checks are a measured minimum,
not the complete S-CORE expected set. Accepted tailoring/applicability and full native
impact/export closure remain necessary before T033 engineering acceptance.

## Preparation and run sequence

1. Refresh source/task activity before binding the execution snapshot. A new baseline
   requires new inputs and expectations for both arms; deliberately retaining the old
   pin measures only that historical revision.
2. Bind process/tool/catalogue revisions, actual model capability/settings, native
   expected-set applicability, roles, task envelope and output schema. Pin the fabric
   worktree snapshot; Git HEAD alone cannot identify dirty source.
3. Inspect hooks and allocate separate disposable copies through the shared storage
   module/CLI. Bind workspaces/caches to measured Linux filesystem capabilities; stop
   on volume loss. Keep credentials/private Fabro state internal and references read-only.
4. Prepare both native Fabro graphs and contexts without provider calls. Compare required
   commands, tools, check sets, native identities, input revisions, output schemas and
   offline review obligations. Reject reduced obligations. Validate actual worker initialization.
5. Bind fresh operator instructions, per-stage governors and aggregate request/spending
   limits to the exact graphs and current price/capability evidence. Neither old ledgers
   nor the earlier issue exception are reused. Missing authority/limits block transmission.
6. Run admitted trials sequentially through Fabro. The first pair tests feasibility.
   Propose three independent pairs for a descriptive pilot, ordered baseline/optimized,
   optimized/baseline, baseline/optimized. Three pairs cannot support a general claim.
7. Reconcile every request/reply/native stage and execute the same candidate checks
   after each trial. Count all repairs, rejected responses, failed attempts and advisory
   calls. Retain unsuccessful arms; no unbounded replacement or selective omission.
8. Export reports and exit without waiting for a reviewer; close owned meters/servers,
   verify shutdown, and export
   source/patch/commands/checks/usage/licenses under a portable SHA-256 manifest.
   The record remains useful without Fabro. Publication remains deferred.

Require complete raw transport for all new calls. The two missing legacy envelopes
remain historical gaps and cannot be reconstructed. Earlier #704 generation was not a
matched pair and cannot become one arm of a future savings comparison: prompts, settings,
repairs and source exposure differ. It is planning evidence only.

## Measurements and conclusions

Retain original native/transmitted request hashes and bytes, complete replies, model
settings, stage/tool events, nullable input/cache/output/reasoning usage, native usage,
price-source revision and nullable billed cost. Use monotonic durations for provider,
agent stages, deterministic checks and complete tasks separately. Raw evidence stays
on the host; model feedback uses the reviewed bounded service.

Sum actual cache-miss input over every implementation, repair, follow-up and advisory
request in each arm. Compare whole-task totals; expose stage totals for explanation.
Report total input/cache hits too. Derive misses from input minus hits only when provider
definitions reconcile. Missing usage or zero baseline misses makes reduction unavailable.

Eligible paired reduction = `1 - optimized_uncached / baseline_uncached`. Report each
pair, ratio of sums, sample size/order, min/max, cache behavior, failures and retries.
Never average percentages from incompatible activities. Provider caches cannot be assumed
reset; record cache differences and withhold a context-only claim when they confound the
result. Use the same recorded build-cache preparation policy in both arms; time native
checks separately. Cost/time comparisons use complete-arm denominators and remain null
when unavailable. Token-price bounds are not invoices; historical prices are not current.

The 60–80% routine/local target remains unmeasured until real eligible cases have fresh
reconciled usage and adequate engineering outcomes. Report values above 80% and review
scope preservation; they are not an automatic failure. Keep failures, skips, missing
and stale evidence separate. Measurements from unsuccessful/incomplete arms may be
reported descriptively but cannot support equivalent-engineering savings claims.
B4/B5 are coverage obligations without an invented routine percentage target. T033
needs its human decision and full qualification; a pilot or Fabro success cannot close it.

## Deliverables and next step

The plan supplies a protocol, coverage matrix, unresolved inputs, source hashes and
integrity/consistency records. New live metrics remain null. No server, provider call,
native build, scheduler, commit, PR or new increment is started by this preparation.

Next prepare P704's two source/context/graph packages and admission packet without
provider calls. Resolve native expected-set boundaries and compare graph/tool/context
obligations before proposing a fresh live pair. Select B1–B5 targets with independent
oracles before extending coverage. PR publication remains deferred.

The owner places human review offline. Prior human-node graphs remain historical; new
workflows finish with report export/exit while failed checks and acceptance stay explicit.
