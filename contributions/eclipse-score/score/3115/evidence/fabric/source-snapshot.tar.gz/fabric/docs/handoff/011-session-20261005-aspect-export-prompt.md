Continue increment 011 autonomously in /home/jefferson/s-core_sw_fabric.

Resume the existing persistent Goal if supported; create it only if none exists:
complete increment 011 against its specification and acceptance requirements with
verified evidence and preserved engineering boundaries. Never mark it complete while
required evidence or acceptance is missing.

Read AGENTS.md, constitution, relevant active011 spec/plan/tasks/acceptance sections,
docs/handoff/000-to-001.md and this verified latest checkpoint:

- docs/handoff/011-session-20261005-aspect-export.md
- docs/handoff/011-session-20261005-aspect-export.json
- specs/011-change-impact-and-freshness/evidence/t033-aspect-export/review-report.md

Verify snapshot/manifest and immutable subjects, fresh storage identity/capabilities,
source/runtime/large-input bindings before continuing. Use bounded summaries; never
print whole JSON snapshots, native exports or logs to conversational context.

Current next stage: verify the new snapshot/manifest/immutable inputs, then assess
Sphinx-Needs8.5.0 producer-contract compatibility and remaining independent benchmark
preparation against exact source authority. Original and approved candidate native
//:needs_json exports now pass; do not retry them unchanged. Native 144/1251/916 ID
sets and complete values equal historical exports. The catalogue importer admits
8.3.1 only; no wider support or readiness is claimed. Preserve reviewed source locks.

Read t033-aspect-export/review-report.md, original/candidate-export-inventory.json,
remaining-B3-coverage.json and missing-inputs.json. Raw native exports stay outside
conversational context. The LCOV summary denominator differs from explicit DA/BRDA
entries; do not invent locations or rerun successful held-out witnesses blindly.
B1 selection, accepted B4/B5 inputs, full B3/RPC applicability, complete native expected
sets, fresh paid budgets and offline T033 acceptance remain missing. Complete all
independent authorized work before one consolidated missing-input request.

Native/runtime workspaces and compatible overlays remain as recorded in the snapshot.
Use shared storage validation before reuse. The older P704 and Specify tool workspaces
fail historical storage bindings; do not rewrite them or invoke tools from them.
Native tools were acquired via exact source-declared URLs/SHA-256 into the current
bound workspace. Reprepare exact Spec Kit1.0.12 before a future CLI invocation.
Local pinned prerequisite scripts do not invoke the legacy CLI and passed freshly.
All owned processes and mirrors are closed; stage limits restored; no provider/Fabro/
Docker daemon or paid budget is active. QNX remains skipped without a license.

CREDIT-EFFICIENCY PREFERENCE — OWNER INSTRUCTION

Keep tool output small, read only relevant sections and reuse unchanged checks through
verified hashes with explicit carried labels. Rerun when subjects change or an actual
failure leaves a relevant concern unresolved. Restart from a concise verified handoff
when accumulated history becomes less useful than that handoff. Preserve the Goal,
authority, budgets, storage, failures and outstanding obligations across sessions.
This does not reduce required checks or acceptance, and does not authorize a new model
or paid request. Recommended next model: gpt-6.1-sol, medium reasoning for exact cached
input preparation and scoped native export retry; escalate effort only for new complexity.
Naming the model does not switch this session.

AUTONOMOUS AUTHORITY

I authorize the remaining reversible technical work necessary for 011: dependency
discovery and preparation, public source/tool acquisition, fabric implementation
fixes, scoped Linux native analysis/builds/tests and necessary disposable test
containers, validation, convergence, benchmark preparation and complete offline reports.

This authorization covers successive dependency stages. Do not stop after each
missing dependency or ask me to say “go” again. Historical single-stage stopping
instructions do not require renewed permission for work covered here. Preserve each
stage’s evidence, declare fresh finite limits for its successor, and continue.

Stay within 011. Do not start 012, publish, push, merge, release, deploy, change global
storage, introduce a scheduler or synthesize engineering decisions.

WORKING METHOD

1. Use Spec Kit to track actual remaining obligations. Add tasks only for demonstrated
gaps. Keep spec, plan, tasks, coverage and acceptance consistent. Completing existing
checkboxes alone is insufficient.

2. Follow the native dependency chain from exact source/lock bindings. Measure cache
availability, provenance, integrity, licensing evidence and sizes before acquisition.
Prefer verified cache reuse. Establish finite request, download, storage, archive,
execution and retry limits before each stage.

3. A newly discovered dependency ends that bounded probe, not the overall task. Preserve
the failure, prepare the next admissible stage and continue without renewed permission.
Do not repeat unchanged failures blindly, silently widen sealed limits, remove mandatory
checks or change native policy to obtain success.

4. Use score-fabric storage and score_sw_fabric.storage. The registered build image should
be 1 TiB; mounting it is authorized if needed. Verify writable Linux capabilities and
fresh volume bindings. Stop on disconnection. Preserve historical bindings, sealed
packets, dirty user work and reference repositories. Keep credentials/private state
internal and ephemeral bearer tokens out of SSD evidence and logs.

5. QNX remains skipped because I have no license. Preserve unresolved applicability
honestly. Keep Spec Kit responsible for fabric development, S-CORE for engineering
semantics/artifacts and Fabro for execution/run state.

6. Run appropriate frozen dependency, Ruff, mypy, pytest, foundation, package and native
checks. Reuse unchanged validation only with exact source bindings and explicit carried
evidence labels. Investigate failures and retain unsuccessful evidence. Avoid redundant
testing and rereading unchanged files.

7. Complete real native validation and prepare the remaining B1–B5 qualification work.
Additional paid provider calls require a fresh explicit provider/model/request/spending
budget; closed historical budgets cannot be reused. Finish all independent authorized
work before presenting one consolidated request for genuinely missing authority or inputs.

8. Preserve T032’s recorded approval and human-owned markers. Human engineering acceptance
stays offline. Never infer acceptance from tests, emulator replies, fixtures, agent
assertions or Fabro success. Do not claim 011 complete while mandatory T033 evidence
or acceptance is missing.

CONTEXT HANDOFF — MANDATORY

Monitor remaining context whenever the interface/runtime exposes it. When it falls
BELOW 20%:

- Stop starting new work.
- Safely finish or terminate owned operations; retain partial results and failures.
- Save a verified Markdown/JSON handoff under docs/handoff/, without modifying sealed packets.
- Save a copy-ready continuation prompt under docs/handoff/.
- Include exact current files, hashes, workspace/storage bindings, completed work, open
  obligations, failures, next commands, authority and budgets in the handoff.
- Carry this entire autonomous authority and below-20% rule into the new prompt.
- Pause any active Goal; I explicitly authorize that conditional pause.
- Return the handoff links and continuation prompt, then end the session.

If remaining context percentage is unavailable, state that limitation rather than
inventing a reading. Use an explicit low-context warning to checkpoint conservatively.

Keep concise progress updates during execution. Otherwise continue until 011’s
completion requirements are verified or only genuine external blockers remain.
For external blockers, finish independent work first, export a concrete review packet
and identify exactly what is needed. Report incomplete status truthfully.

End every final response with “Next step:” and “Recommended model:” as AGENTS.md requires.


VERIFIED RESUME COMMANDS

```bash
export SPECIFY_FEATURE_DIRECTORY="$PWD/specs/011-change-impact-and-freshness"
.venv/bin/score-fabric storage status
bash .specify/scripts/bash/check-prerequisites.sh --json --require-spec --require-tasks --include-tasks
```

Use the shared storage module to validate both bound workspaces and all new mirror
inputs. Before any future Specify CLI invocation, prepare the exact source-pinned
v1.0.12/e77daa9021d20db26b878f7dfa5640fe5a42d04e tool in a fresh bound workspace and
put it on PATH; the prior tool binding is refused. Do not hash/read the refused P704
cache or retry old missing-dependency failures. Preserve failed evidence, finite
successor limits, offline review and pending acceptance.
