# Resume prompt

Resume the paused S-CORE Rust workflow/issue queue in `/home/jefferson/s-core_sw_fabric`.
Read AGENTS.md, `.specify/memory/constitution.md`, active `specs/011-change-impact-and-freshness/`,
`docs/handoff/000-to-001.md`, and then the current frozen handoff:

- `docs/handoff/011-session-20261006-rust-frozen.md`
- `docs/handoff/011-session-20261006-rust-frozen.json`
- `docs/handoff/011-session-20261006-rust-560-codex-results.md`

Treat this message as resuming the pause; preserve all existing authority/budgets.
The generic Rust workflow is implemented. All queued issues are not solved. #560's
latest scoped correction passed 14 actual Linux cases with independent Codex review;
two binary Clippy warnings and engineering acceptance/qualification gaps remain.
Preserve immutable evidence and unrelated user changes. Do not publish or accept
engineering decisions automatically.

#560 used 1/3 additionally authorized Codex corrections; two remain, in addition to
three historical attempts already exhausted. Original queue has only five remaining
source slots: #250 two, #1261 two, #173 one. Others exhausted, #1265 zero new work,
QNX #1278 excluded. Do not reset counters or extend the Codex exception to other
issues. Fabro agent calls remain DeepSeek Flash only, without fallbacks; Codex handles
the explicitly authorized #560 corrections/review. Fabro owns runtime/check state.

Owned runtimes are stopped; never restart old terminal IDs or signal historical PIDs.
Validate external SSD/Linux-image bindings before workspace access/builds. Stop if
disconnected, with no active relocation. Keep credentials/private state internal.
Recheck hash bindings before reusing prior evidence and label it carried evidence.

First review the verified queue inventory and suggest the next concrete issue/action
within existing allowances; continue work only where its authority is established.
Do not repeat passing #560 checks without changed subjects or a relevant unresolved
concern. Every repository final response must end with explicit Next step and
Recommended model lines. Naming a model does not switch the session.
