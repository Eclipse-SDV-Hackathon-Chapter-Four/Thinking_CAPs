# Implementation Plan: Change impact, freshness and bounded AI context

**Branch**: `011-change-impact-and-freshness` | **Date**: 2026-10-03
**Spec**: [spec.md](spec.md)

## Technical Context
Python >=3.12, frozen uv dependencies, stdlib JSON/hashlib/dataclasses/SQLite-free JSON state,
existing PyYAML and exact schema/digest readers. No new tokenizer/provider dependency.
Existing 004 artifact impact and 005 freshness remain authoritative. New 011 adapters validate
inputs and derive context; 007 admission still controls catalogue/destination/cost admission.
Fabro retains execution and run state. New stage accounting is a bounded derived context ledger,
not a scheduler, requirements store or approval source. Native tool/result interception is
verified against pinned source; no post-hook result mutation is assumed.

## Constitution Check
All fifteen principles preserved. XIII–XV are a 1.1.0 proposal expressly requested by the v3
brief; owner ratification remains pending. Existing first-session stop is superseded by the
current explicit 011 implementation request. Native reference trees are read-only. Credentials
and runtime server state stay internal. New analysis/build scratch uses `score-fabric storage`.
No paid calls, publishing, merging or target acceptance is authorized. Unknowns remain blockers.

## Architecture and File Structure
- `optimization/common.py`: exact records, conservative UTF-8 token estimate, immutable refs.
- `optimization/evidence_query.py`: deterministic bounded SARIF/JSON summaries and pagination.
- `optimization/tool_results.py`: output retention/preview and persistent stage budgets.
- `optimization/firewall.py`: generic-tool denial; runtime hook adapter and bounded MCP service.
- `optimization/telemetry.py`: nullable provider usage and dimension-bound aggregation.
- `optimization/impact.py`: old/new native reverse reachability and stale baseline reports.
- `optimization/task_classification.py`: explicit S0–S4 policy, unknown scope. Candidate
  thresholds/precedence are declared in policy and audited; broad sensitive work remains S4.
- `optimization/context_manifest.py`: native-index/impact/baseline/mapping-bound scope.
- `optimization/context_budget.py`: mandatory L0/L1, optional L2 and indexed observations.
- `optimization/skill_selection.py`: file/directory-safe registry/selection/lazy rendering.
- `optimization/token_governor.py`, `model_router.py`: operational ceilings + 007 admission.
- `optimization/review_pack.py`, `prompts.py`: structured results, bounded diffs, static prefix.
- `optimization/progress.py`, `workflow_modes.py`: bounded stop reasons and derived modes.
- `optimization/server.py`, `cli.py`: stdio bounded tools and additive CLI commands.
- `optimization/benchmark.py`, `audit.py`: five offline comparisons and consistency audit.
- `.agents/skills/score-*`: eight procedural Skills; versioned registry in `profiles/`.
- `policies/optimization-v1.yaml`: explicit reviewed-candidate limits/triggers, disabled live use.
- `schemas/optimization-*-v1.schema.json`: exact versioned input/output contracts.
- `agents/context.py`, `roles.py`: optional v2 context path, lazy observations, common prompts.
- `agents/admission.py`: additive narrowed admission bridge; keep v1 replay unchanged.
- `artifacts/impact.py`: old/new relation reachability and changed relation seeds.
- `compiler/optimization.py`: narrow reviewed action projections before computing native IR IDs;
  `compiler/`: consume derived mode plans via existing native graph compile interfaces; preserve
  expected collectors/human gates, no alternative scheduling.
- `docs/handoff/someip-84/factory/`: new raw-evidence guard, bounded feedback summaries and
  no-narration instructions; historical `runs/` and active frozen queues remain untouched.
- `tests/contract/test_optimization_*.py`, `tests/integration/test_optimization_service.py`:
  negative-first contract coverage and actual no-provider stdio/tool-hook execution.

## Sequencing and Migration
1. Specify/plan/checklist/tasks/analyze before code. Reproduce huge evidence privately.
2. Containment first: bounded query adapters, result/stage budgets, deny generic raw reads,
   collector summaries and common prompts. Converge before telemetry.
3. Record baseline telemetry and five context benchmarks before adding class budgets.
4. Impact → classification → manifest → context/Skills → governor/routing/critique.
5. Progress stops/modes/review pack; native source/config verification and service replay.
6. Benchmark, full regression, audit, analyze/converge and reconcile docs.
Existing v1 profiles and public CLI output remain replayable; new policy is opt-in and narrows
rights. No running queue migration. On missing dependencies, baseline drift, unavailable bounded
service or unsupported runtime interception, refuse optimized activation. Rollback selects old
profiles only within their existing separately authorized execution scope; no silent bypass.

## Benchmark and Acceptance Strategy
Five recorded synthetic deterministic tasks are development fixtures. Measure raw/context UTF-8
bytes and conservative estimates, gate outcomes and required-check/trace/evidence equality.
Provider usage/cost/cache/wall-time savings require separately authorized runtime observations;
null is retained in offline records. Target >=60% offline reduction on routine B1–B3; distinct
live 60–80% uncached reduction remains open. Full logs and raw SARIF stay unchanged on host.
See [contracts](contracts/optimization.md), [research](research.md), [data model](data-model.md)
and [quickstart](quickstart.md). Human acceptance and runtime live qualification stay open tasks.

## Scoped qualification continuation

Add `optimization/activation.py` for private operator-instruction validation and
`optimization/provider_boundary.py` for a localhost DeepSeek-only request meter. Fabro remains
executor: the meter only admits/forwards provider transport and retains usage, never schedules,
accepts artifacts or starts successor runs. The immutable instruction quotes the current owner
messages, scopes qualification only and is pinned in native hook commands. Use a separate private
Fabro server and credentials via `private_server_root`; select scratch via shared storage. Explicit
run titles prevent auxiliary title-generation calls. Global settings/profiles remain disabled.
Capture native source/config/worker identity and real hook events before any live transmission.
Provider prices are source-derived conservative bounds, not reported bills. Qualification datasets
are explicitly development fixtures and cannot satisfy native engineering readiness. Store new
measurements separately from prior acceptance evidence. Prepare a T032 agent review draft with
artifact digests and leave every human marker untouched.

The measured native overhead exposes 23 tools, of which 13 are already denied. Optional
operator-pinned tool projection removes only denied/unselected declarations, without editing
messages or selected schemas. The guard enforces the same selected bounded tool set. Preserve
original and transmitted request hashes and apply ceilings before and after projection. The
initial ten-call experiment remains immutable; qualification of this new path stays T033.

The subsequent owner `go` permits one additional ten-request Flash comparison capped at
$0.10. Allocate a fresh volume-bound workspace, private server and stopped-on-exhaustion
ledger. Apply the same empty tool selection to both unchanged original prompt variants;
retain original/transmitted bytes and compare total/cache-miss tokens independently.
Inspect each native agent stage and exact expected output before proceeding. Store new
evidence under `evidence/projection-qualification/`; preserve the original experiment.

## Real issue continuation

The 2026-10-04 owner `go` permits lifecycle #704 implementation and comparison preparation.
Pin upstream commit `7d1d7bec81d96752b5a9a235044d2dfc3ecd259b`, recheck public activity,
allocate a volume-bound disposable copy, inspect hooks and inventory exact consumers.
Preserve effective configurations via common verified definitions plus consumer-specific
variants using the smallest supported native build mechanism. Compare parsed generated JSON
against the untouched baseline before running affected native unit/configuration checks.
Retain portable patch and evidence under `evidence/lifecycle-704/`. Prepare baseline and
optimized real-task contexts and no-provider native guard/conformance without paid requests.
Missing native dependencies remain measured limitations. Human T032/T033 markers and reviewed
artifact bytes remain unchanged; T032's dated owner decision is in owner-review.md.

## Fabro/Flash implementation qualification

The latest owner `go` authorizes US14: allocate a fresh workspace and private Fabro server,
pin the current source and four-request/$0.10 experiment, then obtain code from Flash using
original configurations and BUILD files. No earlier implementation is supplied as an answer.
Use native agent runs with checksum-pinned stage hooks and the existing request meter.
Deterministic application validates model output against exact paths and operation schemas;
native checks measure configuration/package equivalence and affected regression. Preserve
raw responses, mechanical formatting, bounded correction and S3 advisory critique separately.
Stop at the human engineering boundary and retain all source-impact/export gaps. This finite
operator experiment starts no queue and does not change default disabled live policy.

## Scoped budget exception retry

Implement and test an explicit optional private owner exception under AC24. Keep default
policy and reviewed subjects unchanged. Start a fresh volume-bound source/server/ledger;
use nonthinking JSON mode with full native JSON schemas and enough output for the macro
and three BUILD edits. Deterministic application, fresh native checks and S3 advisory
critique precede the unaccepted human gate. Retain evidence/lifecycle-704-flash-retry/.

Final convergence fixes cross-ledger transport artifact collisions with instruction-SHA
namespaces and exclusive creation before transmission. Retain the two legacy losses,
then execute a separately complete guarded proof. Native advisory findings remain unchanged;
additional consumer/runfile/original-byte measurements are draft evidence responses only.
The native process changes its argv title; stop the owned server using verified PID,
executable and private storage identity, then verify both loopback ports are closed.

## Approved local upstream packet

US16 records the owner's approval separately from the immutable US15 evidence, then
prepares a new disposable contribution checkout via shared storage. Pin current upstream
main and issue activity, inspect hooks, and apply the exact approved patch on a local
branch. Reconcile all seven changed paths with the approved final/original source bytes;
reuse existing native test evidence only while its exact source/tool baselines match.
Fill the actual upstream improvement template and retain project contribution/license
instructions. Keep ECA/DCO/committer acceptance and external publication distinct from
local owner approval. Retain evidence/lifecycle-704-upstream-packet/ and preserve T032/T033.

## Real-target benchmark preparation

US17 prepares [the T033 paired protocol](t033-benchmark-plan.md) and machine-readable
pilot/coverage/source bindings under evidence/t033-benchmark-plan/. P704 supplements
the B1–B5 matrix rather than relabeling a Starlark cleanup as those activities. Both
arms retain the same guards/tools/checks; context selection is isolated from tool-schema
projection. Every future trial needs fresh loss-free request/usage capture, independent
candidate checks and native expected-set/admission bindings. Dirty fabric source requires
an exact worktree snapshot, not HEAD alone. Proposed repetitions are descriptive only.

This continuation creates no runtime adapter or live instruction. Shared storage owns
temporary analysis/tool caches; final planning artifacts stay in the requested repository.
Keep all reviewed T032/native packets unchanged. Verify the bound sources, planning JSON,
relative links, foundation consistency, packaging and final scoped Spec Kit analysis.

## Paired P704 package preparation

US18 materializes source/context/graph packages under evidence/t033-paired-preparation/
and separate shared-storage native copies. Freeze the actual Python source/lock snapshot
used by local entrypoints; preserve the prior plan's control bindings in a new historical
snapshot instead of editing its manifest. Both arms start at the original native baseline,
with identical six JSON/BUILD inputs and the same native declaration. The baseline includes
its complete architecture document; the selected context retains the exact declaration
excerpt while full source stays available through equally bounded tools. These are context
byte estimates only; no provider savings target is inferred or engineered by padding.

Prepare graphs with common source initialization, implementation/correction/check/review
and human gates. Stage hooks refuse without a fresh operator grant; native applicability,
live worker/result binding and protected collector execution remain explicit unmeasured
boundaries. Source/service smoke checks run locally in disposable copies, not a live Fabro
trial. No runtime server, request meter, old exception or provider call is started.

## US19 implementation extension

Implement private operator bindings in `optimization/paired_runtime.py` and fresh
measurement in `optimization/paired_collector.py`. Use the frozen P704 original
archive/740-file manifest and the selected structured output schema. Tests exercise
identity, tampering, replay, correction ordering and failed/missing measurements.
A local replay of the approved patch may test the native collector, explicitly
excluded from new model output and paired savings. No paid transport is started.
Retain this phase under `evidence/t033-runtime-bindings/`; preserve previous controls
as byte-identical `.md.txt` snapshots before updating them.

## US20 native API smoke extension

Start a fresh isolated API server using the pinned local Fabro executable, with private
credentials/state and a localhost provider endpoint that refuses all requests. The smoke
workflows contain only command/human nodes. Bind the native run's measured cwd after API
creation, then initialize/apply a labeled historical local replay and collect lightweight
source/feedback evidence. Missing native checks must remain missing. Inspect actual
routing context rather than claiming agent prompt transmission. If native workspace
metadata changes the source boundary, retain the initial refusal and add only a measured,
source-grounded exclusion with negative tests. Close all owned runs/server and record
remaining observed-provider, native impact and human acceptance gaps.

## US21 — offline review placement

Replace native human nodes with a deterministic report command and exit in current
workflow packages. Refusal/failure paths converge on report export; checks do not
become passed when Fabro completes. Retain the prior unanswered-gate API proof as
history. Qualify two fresh provider-disabled API runs with no human handler visits
and complete hash-bound offline review packets. Human decisions remain external,
subject-bound and pending; provider admission and native expected-set gaps remain.

## US22 — native scope review

Freeze prior packet/control hashes, extract two exact original-source copies using
shared storage, inspect hooks and apply only the approved historical patch to one.
Use pinned native Bazel queries for old/new reverse dependencies and target sets.
Inspect baseline-bound CI/platform, native declaration and process references.
Derive a source-grounded proposed required-check matrix, retaining query/export or
applicability failures as explicit gaps. No successful query or report supplies
engineering acceptance. Review stays offline; no Fabro/provider server is needed.

## US23 — synthetic provider capture qualification

Preserve current source/control and historical packet hashes. Use fresh shared-storage
scratch with internal private fixture bindings. Exercise the production HTTP boundary
against a loopback upstream through a test-only substitution of its fixed official URL;
disable proxies and use only a synthetic key. Do not add an alternate production
endpoint or relax live guards. Test completed JSON/SSE envelopes through observed
ticket capture and scoped application, plus byte/usage/source tampering, unknown
usage, truncation and replay. Fix measured gaps with focused regression tests and
retain initial failures. Export raw synthetic evidence and static/frozen/foundation/
package results for offline review. No new Fabro agent consumption is implied.

## US24 — native agent/emulator execution

Pin the executable, native provider codec/fidelity/agent sources and current fabric
snapshot before creating a private API server with isolated auth home and synthetic
DeepSeek key. Configure its provider URL to a loopback router; scoped production
request meters retain original/projected requests and byte-bound responses. A test-only
upstream opener sends exclusively to the local emulator. Generic tool declarations are
projected away, and pre-tool hooks refuse any attempted tool execution.

Use actual API-created worker/run identities and the original P704 archive. The emulator
returns an explicitly labeled historical patch replay in the structured contract.
Capture/apply it through protected command nodes, collect fresh lightweight checks with
required native XML missing, and route bound feedback into a fresh native agent session.
Measure its actual outgoing feedback and returned synthetic advisory. A missing-usage
run must export its refusal and exit without applying or reaching the second agent.
All paths export offline reports without human nodes. Retain every initial compatibility
failure; close only owned state. No live benchmark/native scope acceptance is supplied.

## US25 — bounded correction and restarted operator qualification

Reuse the pinned native executable and qualified loopback router/meter protocol in
fresh shared-storage scratch with internal private server state. Freeze source and
transport interfaces. Three workflows cover baseline and optimized worker identities
plus correction without failed checks; arm names do not measure context optimization.
Each performs exactly one implementation and one correction agent request. Normal
workflows inject serviceId 7999 in the historical patch, retain a failed protected
literal-data oracle (expected 7101), route its exact feedback at compact fidelity,
restore the historical candidate and collect again. Required native XML stays missing.

After collection, a native command launches distinct operator processes to exercise
exclusive receipt, application order and collector order refusals. Another child persists
an explicit interrupted-state marker and exits 73; the next process must refuse writes.
This is recovery of private operator state, not Fabro same-run checkpoint resume. The
unbound workflow omits collectors before correction, so application must refuse with
CORRECTION_WITHOUT_FAILED_CHECKS. Every path exports reports and exits; meters/server
close after inspection. Synthetic observations remain distinct from native verification,
model generation, live benchmarks and human acceptance.

## US26 — fresh offline admission draft

Refresh read-only GitHub activity and official Flash documentation against the original
source archive. Bind all source CI profiles, ready dependencies, 135 discovered labels,
semantic oracles and unresolved native impact/QNX obligations in a proposed matrix.
Offer complete native qualification or explicitly bounded Linux experimentation as
offline choices; neither is automatically selected. Confirm QNX source checksum and
access/license prerequisites without retrying the failed SDK fetch.

Render original full/selected contexts with equal JSON whitespace normalization and
common obligations. Preserve all source/contract bytes, initial oversized requests and
production refusal results. Measure reconstructed native wrapper overhead; require an
actual native no-provider preflight before a paid pair because baseline headroom is
61 bytes. Check documented final-content-chunk SSE usage with synthetic local bytes.
No worker/server/provider call is started. Export an unfilled offline decision record
and seal current controls separately from historical control snapshots.

## US27 — actual payload preflight and explicit parameter fix

Create fresh storage-bound scratch and private internal API state. Use a clean explicit
server environment, synthetic SQL-vault key and loopback-only refusal endpoint, with
no upstream transport. Bind exact prepared prompts in four-node native graphs, retain
actual HTTP bodies and identity hooks, then export reports and exit. Measure current
tool projection and actual wrapper differences. Do not apply any candidate or run
native target builds. Close only owned state and remove the synthetic vault entry.

When observed native defaults differ from the declared non-thinking JSON contract,
add an optional exact request_parameters profile to private activation verification
and production request projection. Keep old instructions unchanged; accept only the
complete Flash disabled/none/json_object profile. Re-measure actual captured bodies,
retaining original raw requests. Run fresh scoped regressions, HTTP JSON/SSE wire
checks, byte-overrun and pin/profile refusals, Ruff/mypy, foundation/build and trace
audit. Native scope/QNX/roles and dynamic correction/review envelopes remain unresolved.

## US28 — full-input dynamic stage measurement

Allocate fresh shared-storage analysis scratch and internal private API state. Bind
retained synthetic initial/post-correction candidates and checks into four immutable
stage envelopes; reconstruct complete source inventories and verify exact feedback.
Keep all original context and candidate files, without feeding historical answers into
implementation arms. Exercise binding drift and correction-without-failure refusals.

Use exact four-node native correction/review report/exit graphs against a loopback-only
capture endpoint with no upstream transport. Apply current explicit optional parameter/
tool projection and measure complete bodies. Export context-limit refusals when large;
do not weaken scope or raise guards. Distinguish the local endpoint guard from the
production RequestMeter/engineering admission. Remove synthetic vault state and close
owned processes/endpoints. No production/test change is required; carry previous fresh
checks only by unchanged source hashes, and run current foundation/package/trace checks.

US29 implements stage-bound source snapshots via the existing stdio bounded service.
The manifest byte pin binds the original inventory, candidate, checks and feedback;
every query revalidates all selected files and artifacts. Only get_source_excerpt is
advertised. StageBudget retains escaped MCP result limits and RequestMeter controls
the full native conversation separately. Original mandatory obligations and deleted
paths stay in prompts; file indexes replace eager whole-file inclusion. The local
qualification uses synthetic replies, never native-scope acceptance or paid authority.

US30 verifies every observed exchange before capture: non-final responses must be
completed permitted tool calls whose next recorded native request carries exact
assistant calls and manifest-bound source results. The last response must decode as
complete structured output. Stage source views bind protected fresh checks/feedback;
only the final candidate can enter the existing application/collection path. Native
fixture correction and advisory review retain full output bytes and stop truncation.
Synthetic usage proves accounting behavior, never live output-token feasibility.

Each collector directory includes the complete worker binding SHA, preventing same-arm
qualification repetitions from sharing output paths. Keep native null-content codec
normalization exact and refuse direct earlier-final receipts. Native length continuation
may reach the request guard before capture; retain the incomplete response and the
continuation refusal separately, with unchanged worker source/private state. Medium
native fidelity may bound repeated command history while exact current feedback/source
view remains in runtime context and complete command records stay in offline reports.


US31 allocates shared-storage review scratch and pins the sixteen historical packets,
current 310 source/test subjects and accepted T032 bytes. Deterministic review compares
18 proposed rows and 135 discovered labels with the source CI matrix, verifies the
configuration architecture record in genuine exports, and retains unaccepted impact
closure. Metadata-only known QNX path probes never read licenses or fetch an SDK.
Draft scoped experiment/full-native choices and review responsibilities; bind a new
unfilled form to stable decision subjects. Optional user drafting preferences supply
no implicit acceptance. The latest owner instruction skips QNX because no license
is available; retain its unresolved applicability and incomplete qualification.
Immutable templates must be copied for a later decision,
leaving sealed evidence unchanged. No production code, provider or native build changes
are needed; carry hash-bound tests and run current control/package/trace checks.


US32 allocates a fresh shared-storage workspace for the pinned original archive and
exact Bazel binary. Inspect pre-commit and Bazel configuration before probes; copies
contain no Git hooks. Verify supported options from native help. Use a measured
network namespace and read-only inputs for dependency probes, with local writes and
caches confined to the bound workspace. Retain public cached dependency identities
and any unavailable repositories explicitly. QNX downloads/execution remain skipped;
no credential helper, substitute SDK or checksum change is permitted. A successful
Linux package load or analysis is not a native build/test pass. Export all outcomes
and limitations outside Fabro; no paid call or native engineering decision follows.


US33 prepares bounded public PyPI HTML index responses for the measured missing
packages, recording exact response hashes and HTTP provenance on shared storage.
Native probes have no external network or credentials. A namespace-local mirror
serves only the captured package metadata; pinned Bazel downloader rewrite/allow/block
configuration denies other remote hosts, including QNX. Bind a deny-only credential
helper rather than supplying access. Prove the guard with native refusal evidence.
Read-only existing repositories remain explicit historical cache inputs. Keep exact
original source and lockfiles; stop bounded failures, preserve all results and leave
compilation/tests/engineering acceptance unclaimed unless separately measured.

US34 uses a fresh shared-storage workspace and the sealed 68-package metadata input.
Copy the verified original source without hooks and the exact native binary; import only
685 positive registry files matching original lock hashes into a new writable cache.
Keep genuine previously generated external repositories as explicit read-only cache inputs.
Run at most four 120-second probes, stopping three repeated unchanged failures sooner.
The network namespace has only the captured loopback mirror; all other downloads,
including QNX, remain blocked. Diagnose missing repositories from pinned native sources
and retained cache identities rather than inventing replacements or changing lockfiles.
No native build/test/provider call is included. Export results and process closure,
preserve historical/source subjects and run current control/foundation/package checks.

US35 prepares the exact missing public Rust module source archive and registry patch,
verifying their declared SHA-256 values before any native use. Pin request/final URLs,
redirects, status and byte counts; bound each response to 64 MiB, aggregate input to
128 MiB and sixteen public inputs. Only source-lock-bound module archives/patches are
eligible; exclude SDKs, credentials and binary toolchain payloads. Native analysis has
no external network and uses exact loopback archive routes preserving filename suffixes.
Use a fresh storage-bound original source copy and writable cache; preserve prior
inputs and operator versions. Limit native attempts to eight at 120 seconds each and
stop three repeated unchanged failures sooner. Export missing dependencies and actual
cache/download/extraction outcomes, close tools and reconcile repository controls.

US36 uses a new storage-bound original copy and imports the fifteen immutable public
inputs from US35. Bind Bats core/support/assert/file declarations to the exact native
module archive and original registry lock before acquiring or importing bytes. Only
source-bound public source archives and module patches are eligible; no SDK or binary
toolchain download is allowed. Limit the combined set to thirty-two files, 64 MiB per
input and 128 MiB total. Native probes retain per-attempt snapshots and source hashes
captured before execution; the loopback mirror preserves names and excludes external
networking. Stop at eight 120-second attempts or three repeated unchanged failures,
export missing dependencies and reconcile current controls and closed owned state.

When native analysis reaches Buf release checksums, import only the existing cached
checksum list with the exact SHA-256 in the original extension repository attributes.
Retain the input-scope extension explicitly; no binary route or SDK download is enabled.
Capture the resulting Linux binary refusal as a concrete next prerequisite.

US37 imports the three exact already-cached Linux Buf v1.47.2 tools selected by the
original-lock-bound native wrapper and checksum list. The initial 28 public inputs
total 99,394,665 bytes; retain 32-file, 64 MiB/file, 128 MiB aggregate and eight-attempt
bounds. Use the verified Python 3.12.14 runtime read-only from its bound SSD workspace.
Namespace networking denies every unlisted route and QNX; no source/lock edits, remote
binary acquisition, native build/test or human acceptance is authorized by this stage.
Additional exact cached public source archives/patches may resolve observed source
dependency failures within those bounds; SDK/binary additions remain outside scope.

US38 selects a fresh workspace on the registered mounted 1 TiB ext4 image. Remount
changes the device number: retain old guards/records and bind historical source/cache/
runtime as independently hash-verified read-only inputs on the current UUID-bound
volume. Correct only the registration's capacity metadata following the owner reply.
Release 1.3.1 metadata reports 289,823,045 bytes for the exact three Linux payloads;
combined with the 28 inherited inputs this is 389,217,710 bytes. Explicit new limits
are 32 inputs, 256 MiB/input, 512 MiB total, three payload requests (180 seconds each),
8 GiB expanded archive data, 100,000 members/archive and 20 GiB free reserve. Preserve
checksum and builder/payload notices without inferring licensing or qualification
acceptance. Native analysis uses at most three 120-second probes, stops at the first
unchanged/out-of-scope missing input, and serves exact inputs through loopback only.
No external networking, QNX SDK/variant, compiler substitution, source/lock edits,
native build/tests, provider calls or publishing is included. Export results offline.

The first US38 archive reader refused the compiler's 13,733,840-byte COPYRIGHT.html
under a 2 MiB notice-read bound after the archive passed HTTP/hash checks. Retain the
original operator/refusal and validated payload. Measured compiler notice data totals
14,397,469 bytes; a separate reader correction declares 16 MiB/notice and 32 MiB/archive
notice limits before rereading, without another compiler request or native scope change.

US39 prepares a new bound workspace on the registered mounted 1 TiB ext4 SSD image.
Import the 31 verified prior inputs without altering old records, queues or caches.
Release metadata reports 4,819,217 bytes for the exact Coreutils 0.1.0 Linux amd64
archive and provides no asset digest; preserve that null and verify acquired bytes
against the original-lock/wrapper-bound native SHA-256. Tag commit and source license
are retained separately from actual archive notices; no build reproduction or accepted
payload licensing/tool qualification is inferred. Combined input is 394,036,927 bytes.
Limits are 32 inputs, 256 MiB/input for inherited compiler payloads, 64 MiB for the one
new payload, 512 MiB aggregate, one 120-second payload request, sixteen 2 MiB metadata
responses, 512 MiB expanded new archive data, 10,000 members, 16 MiB/notice and 32 MiB
archive notice data, with 20 GiB free reserve. At most three 120-second native attempts
are allowed; stop on the first unchanged/out-of-scope failure. Namespace networking
denies external hosts; the loopback mirror serves exact listed source/metadata/payload
bytes only. Native compilation/tests, QNX SDKs/variants, credentials, paid requests,
source/lock changes, publishing and engineering acceptance remain outside this stage.

The first US39 configured probe fails at the unlisted GCC package before creating a
Coreutils repository marker; the new archive is not delivered through the mirror.
Do not infer Coreutils extraction from that failure's changed ordering. One separate
unconfigured `query` of the exact admitted Coreutils repository is included to measure
its native cache consumption, extraction and hash/mode without GCC analysis, tool
execution or input-scope widening. This remains within the three-attempt bound; stop
further configured retries at the GCC boundary and retain both distinct outcomes.

US40 admits only the original-lock-bound Linux GCC 12.2.0 package from release v0.0.4
in a fresh workspace on the mounted registered 1 TiB SSD image. Refresh public release
metadata and builder source/notices separately from actual payload notices. The one
157,834,687-byte payload makes 33 prepared inputs / 551,871,614 reported bytes. Limits
are 33 inputs, 256 MiB/input and new payload, 1 GiB aggregate/mirror response bytes,
one 180-second payload request, sixteen 2 MiB metadata responses, 8 GiB expanded new
archive data, 100,000 members, 16 MiB/notice, 64 MiB/archive notices and 20 GiB free
reserve. Validate paths/link targets without executing payload tools. Use at most three
120-second native probes: an exact unconfigured GCC repository query followed by the
original five-label configured Linux cquery. Stop configured retries on the first
unchanged/out-of-scope dependency. No compiler substitution, source/lock edits, native
compilation/test, QNX input/credential/license access, paid calls or publishing follows.
Old records/queues/cache and sealed evidence remain unchanged. Export complete offline
reports, preserve human markers and distinguish materialization from qualification.

US41 prepares only the exact native SHA-384-bound jq 1.7 linux_amd64 standalone binary,
using a fresh source/cache copy on the registered mounted 1 TiB SSD image. Refresh
release metadata/tag/source/licenses and distinguish source notices from static binary
findings. Release-reported 2,319,424 bytes makes 34 inputs / 554,191,038 total bytes.
Bounds are 34 inputs, 256 MiB/inherited input, 8 MiB/new binary/static read, 1 GiB total
and mirror bytes, one 120-second payload request, sixteen 2 MiB metadata responses,
2 MiB static notice excerpts, 16 MiB/source notice, 64 MiB source notices and 20 GiB
free reserve. This is no archive; archive expansion/member allowance is zero. Native
probes allow three 120-second attempts: exact unconfigured jq repository query then
original five-label configured Linux cquery. Stop on first unchanged/out-of-scope
failure. Native SHA-384 remains authoritative; acquired SHA-256 is separately measured
for mirror/cache metadata. Verify standalone ELF architecture and retain static strings
without executing the payload or claiming complete license/component qualification.
No host substitution, source/lock edits, compilation/test, QNX SDK/variant/license/
credential access, paid call, publishing or accepted human decision follows.

US42 prepares only the exact native SHA-256-bound BSD tar v3.8.1-fix.1 linux_amd64
standalone binary in a fresh workspace on the mounted registered 1 TiB SSD image.
Preserve historical aspect-build and canonical hermeticbuild URLs separately and refresh
release/tag/build/source-license metadata without changing native URL/checksum authority.
The reported 1,774,384 bytes make 35 inputs / 555,965,422 total bytes. Bounds are 35
inputs, 256 MiB/inherited input, 8 MiB/new binary/static read, 1 GiB aggregate/mirror
bytes, one 120-second payload request, sixteen 2 MiB metadata responses, 2 MiB static
notice excerpts and 20 GiB free reserve, with zero archive expansion/members. Retain
source Markdown bytes under text evidence filenames to distinguish upstream source
from repository documentation links. At most three 120-second native probes: exact
unconfigured BSD tar repository query then original five-label configured Linux cquery.
Stop on first unchanged/out-of-scope configured failure. Source licenses, static findings,
materialization and configured success remain separate from licensing/qualification.
No host substitution, source/lock edits, payload execution, compilation/test, QNX SDK/
variant/license/credential access, paid calls, publishing or human decisions follow.

US43 prepares only the exact native SHA-256-bound zstd v1.5.6-bcr1 linux_amd64
standalone binary in a fresh workspace on the mounted registered 1 TiB SSD image.
Preserve historical native and observed canonical URLs separately and refresh
release/tag/build/source-license metadata without changing native URL/checksum authority.
Release size and aggregate fit must be measured before acquisition. Bounds are 36
inputs, 256 MiB/inherited input, 8 MiB/new binary/static read, 1 GiB aggregate/mirror
bytes, one 120-second payload request, sixteen 2 MiB metadata responses, 2 MiB static
notice excerpts and 20 GiB free reserve, with zero archive expansion/members. Retain
source Markdown bytes under text evidence filenames to distinguish upstream source
from repository documentation links. At most three 120-second native probes: exact
unconfigured zstd repository query then original five-label configured Linux cquery.
Stop on first unchanged/out-of-scope configured failure. Source licenses, static findings,
materialization and configured success remain separate from licensing/qualification.
No host substitution, source/lock edits, payload execution, compilation/test, QNX SDK/
variant/license/credential access, paid calls, publishing or human decisions follow.

US44 prepares original native-pinned Debian test-runtime OCI image objects selected
for linux/amd64 in a fresh registered SSD-image workspace. Preserve the native index
digest, exact descriptor/config/layer closure and tag as a hint only. Bound discovery
before any acquisition: sixteen two-MiB metadata responses and at most one 64-KiB /
30-second anonymous-token response, held in memory only without logging its value.
Admit at most eight exact OCI objects plus 36 inherited inputs (44 inputs total),
256 MiB/object, 1 GiB aggregate/mirror content, eight 120-second payload requests,
256 MiB expanded layer bytes, 20,000 members, eight-MiB/notice and 32-MiB notice total,
512 mirror requests and 20 GiB free reserve. Stream bounded inventory/diff-ID/notice
inspection without filesystem extraction or image execution. Copy only measured exact
objects into the new native SHA-256 cache. Token acquisition/headers/values never enter
SSD/evidence; real home is hidden, private credential configuration is never imported.
The original rules_oci 2.3.0 source-supported OCI_GET_TOKEN_ALLOW_FAIL environment flag
permits a refused token request to fall back to unauthenticated exact cached/local mirror
objects. Preserve the refusal; do not synthesize a token or claim live native registry
authentication qualification. At most three 120-second probes: exact admitted alias/
platform repository query then original five-label configured Linux cquery. Stop on
first unchanged/out-of-scope configured failure. Do not widen the previous sealed stage,
substitute current tags/host images, alter source/locks, remove scoped targets, execute
containers/builds/tests, access QNX, make paid calls or synthesize human acceptance.


## Autonomous 011 continuation — 2026-10-05

The current owner instruction authorizes remaining reversible technical preparation,
public dependency acquisition and scoped Linux native analysis/builds/tests, including
necessary disposable test containers. Historical single-stage stops preserve bounded
failure evidence but do not end this authorized continuation. Each successor records
new finite request/download/storage/archive/execution/retry limits before acquisition;
no sealed limit, native pin, warning policy or five-target obligation is changed.
Use a fresh bound SSD workspace, exact original source and approved historical candidate
only; inspect hooks and keep reference inputs read-only. QNX remains skipped without
a license. No paid request is authorized: close historical budgets and prepare the
remaining B1–B5 protocol/inputs independently. Human acceptance remains offline and
pending T033; T032's subject-bound recorded approval and human markers are preserved.
Stop starting work at exposed context below 20%; if unavailable, checkpoint conservatively
and carry the full current authority into a verified Markdown/JSON/prompt handoff.

The native impact/coverage checkpoint uses an explicit source universe after the
full query refuses QNX; preserve the missing full closure and native applicability.
Original/candidate reverse sets match at 94, with three added native loadfiles.
Prepare a measured compatible disposable Linux environment for the pinned
Ferrocene/LLVM coverage profile; preserve its real host ABI failure and native
sources/checks/policy. See evidence/t033-docs-impact/next-prerequisite/ for exact
bindings and proposed unstarted limits. Do not repeat the host probe unchanged.

## Compatible runtime and oracle checkpoint

[Bound runtime report](evidence/t033-linux-runtime/review-report.md) records exact
Ferrocene/LLVM execution in a disposable mount namespace, with verified image
libraries and no host library change. Original B3 coverage passes three cases;
a held-out handler test passes four and detects a wrong-status mutant. B2 measures
two C++ allocations per actual getter/setter call. Neither establishes accepted
engineering scope or paired provider savings. Native mapping inventories remain
partial; original docs export stops at the pinned Aspect unpack binary. Existing
T154/T156 cover the successor and missing inputs; no duplicate task or human
checkbox change is made. The operator option-order failure and correction remain
explicit. Future sessions use bounded output, targeted reads and hash-verified
carried checks under the owner's credit-efficiency instruction.

## Native documentation export follow-up

[Bound export report](evidence/t033-aspect-export/review-report.md) records fresh
original and approved candidate `//:needs_json` success after six exact pinned public
tool inputs. Both arms retain 144 Lifecycle, 1,251 Process and 916 Platform records;
all IDs and native values equal their historical exports. The stale P704 cache binding
is refused rather than rewritten. Intermediate dependency failures are preserved.
Actual Sphinx-Needs 8.5.0 exports do not establish compatibility with the catalogue
importer's pinned 8.3.1 producer contract. Native applicability/complete expected sets,
B1 selection, B2 production correction, full B3/RPC qualification, accepted B4/B5
inputs, fresh paid budgets and offline T033 acceptance remain unresolved.
[Remaining B3 inventory](evidence/t033-aspect-export/remaining-B3-coverage.json)
separates summary denominators from explicit LCOV locations; no missing locations are
invented. Existing T154/T156 remain partial and human markers are unchanged.

## Producer contract and extended B3 evidence

[Bound report](evidence/t033-producer-contract/review-report.md) measures the actual
docs-as-code8.3.0 / Sphinx-Needs8.5.0 pair against the existing8.2.0/8.3.1 baseline.
Native archive and metamodel bytes are verified; the schema is unchanged but relation,
type and option definitions change. An [explicit profile proposal](evidence/t033-producer-contract/architecture-draft.md)
preserves v1/default/source locks and remains proposed, unimplemented and unaccepted.
Complete immutable consumer source/namespace bindings and real conformance remain open.
Eight original-plus-extended B3 cases pass; summary132/182 lines,39/56 branches,10/12
functions. A wrong-rejection-reason mutant fails exactly one new case; seven pass.
Controlled graph peers do not qualify RPC transport, production graph behavior or full
issue685 coverage. A demonstrated capture gap causes one finite evidence refresh;
raw ZIP/text-format error and corrected capture remain explicit. Existing witnesses
are preserved; no provider requests or human decisions are made.
