Resume increment 011 only when the owner chooses to continue.

Latest pause note: docs/handoff/011-session-20261006-paused.md
Pause verification: docs/handoff/011-session-20261006-paused.json
The owner explicitly paused on 2026-10-06. Keep the existing Goal paused until this
continuation is invoked to resume work; never create a duplicate Goal. The pause JSON
supplements the immutable 2026-10-05 snapshot rather than replacing its native bindings.
Read any recorded subject deltas and revalidate affected checks before carrying evidence.
Both external workspaces currently refuse validation: “Workspace is no longer on its bound
external build volume”. Before native cache/tool access, restore availability of the original
bound volume and verify storage identity and native/runtime/cache bindings. Do not rewrite
bindings or silently relocate the workspaces. No storage repair was attempted during the pause. Ignore the
parallel rust-workflow task. No new paid authority or engineering acceptance was granted.

The following saved continuation preserves the full autonomous authority and context rule:

Continue increment 011 autonomously in /home/jefferson/s-core_sw_fabric.

Resume the existing persistent Goal if supported; create it only if none exists:
complete increment 011 against its specification and acceptance requirements with
verified evidence and preserved engineering boundaries. Never mark it complete while
required evidence or acceptance is missing.

Read AGENTS.md, constitution, relevant active011 spec/plan/tasks/acceptance sections,
docs/handoff/000-to-001.md and this verified latest checkpoint:

- docs/handoff/011-session-20261005-producer-contract.md
- docs/handoff/011-session-20261005-producer-contract.json
- specs/011-change-impact-and-freshness/evidence/t033-producer-contract/review-report.md

Verify snapshot/manifest and immutable subjects, fresh storage identity/capabilities,
source/runtime/large-input bindings before continuing. Use bounded summaries; never
print whole JSON snapshots, native exports or logs to conversational context.

Current next stage: T159. Verify this snapshot, sealed manifests, immutable inputs
and fresh storage bindings, then complete immutable docs-as-code8.3.0 consumer revision,
source/namespace/relation/mount bindings and implement a separately selected exact
producer/metamodel profile with conformance/refusal tests. Preserve catalogue v1 default,
existing digests and reviewed source locks. The architecture/profile are proposed,
unimplemented and unaccepted. Do not globally widen creator or metamodel allowlists.
Use the appropriate implementation skill and Spec Kit controls for this scoped change.

Read t033-producer-contract/review-report.md, architecture-draft.md and compatibility-assessment.json
in bounded sections. Six real exports passed previously; do not retry successful exports
or unchanged witnesses. Actual pair is docs-as-code8.3.0/Sphinx-Needs8.5.0. Native source
archive SHA-256 is2cada3d263cbfe148dc57c0dd8573ba415d224038b3ebb74ae6065662ad315b3.
Archive/metamodel/schema bytes are verified; immutable commit and complete ownership maps
remain unprepared. New native types have no observed instances; fixture checks cannot
establish real qualification. Do not claim a full new import has already run.

The owner instructs: rust-workflow is parallel task, ignore it for now. Do not edit or
repair that parallel task. Full foundation failure for its missing links is retained;
a disposable snapshot excluding exactly that directory passes the unchanged checker.
The scoped pass does not mean a full-workspace pass. Check owned work and report scope.

Held-out B3 oracles and mutants are evaluator-only. Future implementation agents must
not read held-out-oracles, prepare-B3-extended.py.txt, disposable oracle test source or
raw oracle test logs. The operator owns these witnesses; use hashes and bounded measured
summary8 pass/132of182 lines,39of56 branches,10of12 functions and1of8 mutant failures.
Do not combine these with earlier suites or reconstruct native LCOV from summary totals.
Capture omissions/misattribution/ZIP parsing failure are retained and a finite refresh
supplies real aggregate ZIP/LCOV. Prior B2/B3 and fabric checks are explicitly carried
only through verified immutable subjects. Full RPC/Graph/concurrency remains unqualified.

Complete independent authorized technical work before one consolidated missing-input
request. T159, T154/T156 and offline human acceptance remain open;011 is incomplete.
B1 selection, accepted B4/B5 inputs, full B2/B3 applicability, complete expected sets,
fresh paid provider/model/request/spending budgets and offline T033 acceptance stay missing.
No new provider request is authorized by historical closed budgets. QNX remains skipped.

Use shared storage validation for native/runtime roots before every reuse. Historical
P704 and Specify CLI tool bindings remain refused. Reprepare exact source-pinned
Spec Kit1.0.12 in a fresh bound workspace before future CLI invocation; local pinned
prerequisite scripts do not invoke that legacy CLI. All three native stages are reaped,
mirrors closed and prior limits restored. No provider/Fabro/Docker daemon is active.

CREDIT-EFFICIENCY PREFERENCE — OWNER INSTRUCTION

Keep tool output small, read only relevant sections and reuse unchanged checks through
verified hashes with explicit carried labels. Rerun when subjects change or an actual
failure leaves a relevant concern unresolved. Restart from a concise verified handoff
when accumulated history becomes less useful than that handoff. Preserve the Goal,
authority, budgets, storage, failures and outstanding obligations across sessions.
This does not reduce required checks or acceptance, and does not authorize a new model
or paid request. Recommended next model: gpt-6.1-sol, high reasoning for exact source-bound profile
implementation, provenance and refusal/freshness conformance.
Naming the model does not switch this session.

AUTONOMOUS AUTHORITY

I authorize the remaining reversible technical work necessary for 011: dependency
discovery and preparation, public source/tool acquisition, fabric implementation
fixes, scoped Linux native analysis/builds/tests and necessary disposable test
containers, validation, convergence, benchmark preparation and complete offline reports.

This authorization covers successive dependency stages. Do not stop after each
missing dependency or ask me to say “go” again. Historical single-stage stopping
instructions do not require renewed permission for work covered here. Preserve each
stage’s evidence, declare fresh finite limits for its successor, and continue.

Stay within 011. Do not start 012, publish, push, merge, release, deploy, change global
storage, introduce a scheduler or synthesize engineering decisions.

WORKING METHOD

1. Use Spec Kit to track actual remaining obligations. Add tasks only for demonstrated
gaps. Keep spec, plan, tasks, coverage and acceptance consistent. Completing existing
checkboxes alone is insufficient.

2. Follow the native dependency chain from exact source/lock bindings. Measure cache
availability, provenance, integrity, licensing evidence and sizes before acquisition.
Prefer verified cache reuse. Establish finite request, download, storage, archive,
execution and retry limits before each stage.

3. A newly discovered dependency ends that bounded probe, not the overall task. Preserve
the failure, prepare the next admissible stage and continue without renewed permission.
Do not repeat unchanged failures blindly, silently widen sealed limits, remove mandatory
checks or change native policy to obtain success.

4. Use score-fabric storage and score_sw_fabric.storage. The registered build image should
be 1 TiB; mounting it is authorized if needed. Verify writable Linux capabilities and
fresh volume bindings. Stop on disconnection. Preserve historical bindings, sealed
packets, dirty user work and reference repositories. Keep credentials/private state
internal and ephemeral bearer tokens out of SSD evidence and logs.

5. QNX remains skipped because I have no license. Preserve unresolved applicability
honestly. Keep Spec Kit responsible for fabric development, S-CORE for engineering
semantics/artifacts and Fabro for execution/run state.

6. Run appropriate frozen dependency, Ruff, mypy, pytest, foundation, package and native
checks. Reuse unchanged validation only with exact source bindings and explicit carried
evidence labels. Investigate failures and retain unsuccessful evidence. Avoid redundant
testing and rereading unchanged files.

7. Complete real native validation and prepare the remaining B1–B5 qualification work.
Additional paid provider calls require a fresh explicit provider/model/request/spending
budget; closed historical budgets cannot be reused. Finish all independent authorized
work before presenting one consolidated request for genuinely missing authority or inputs.

8. Preserve T032’s recorded approval and human-owned markers. Human engineering acceptance
stays offline. Never infer acceptance from tests, emulator replies, fixtures, agent
assertions or Fabro success. Do not claim 011 complete while mandatory T033 evidence
or acceptance is missing.

CONTEXT HANDOFF — MANDATORY

Monitor remaining context whenever the interface/runtime exposes it. When it falls
BELOW 20%:

- Stop starting new work.
- Safely finish or terminate owned operations; retain partial results and failures.
- Save a verified Markdown/JSON handoff under docs/handoff/, without modifying sealed packets.
- Save a copy-ready continuation prompt under docs/handoff/.
- Include exact current files, hashes, workspace/storage bindings, completed work, open
  obligations, failures, next commands, authority and budgets in the handoff.
- Carry this entire autonomous authority and below-20% rule into the new prompt.
- Pause any active Goal; I explicitly authorize that conditional pause.
- Return the handoff links and continuation prompt, then end the session.

If remaining context percentage is unavailable, state that limitation rather than
inventing a reading. Use an explicit low-context warning to checkpoint conservatively.

Keep concise progress updates during execution. Otherwise continue until 011’s
completion requirements are verified or only genuine external blockers remain.
For external blockers, finish independent work first, export a concrete review packet
and identify exactly what is needed. Report incomplete status truthfully.

End every final response with “Next step:” and “Recommended model:” as AGENTS.md requires.


VERIFIED RESUME COMMANDS

```bash
export SPECIFY_FEATURE_DIRECTORY="$PWD/specs/011-change-impact-and-freshness"
.venv/bin/score-fabric storage status
bash .specify/scripts/bash/check-prerequisites.sh --json --require-spec --require-tasks --include-tasks
```

Use the shared storage module to validate both bound workspaces and all new mirror
inputs. Before any future Specify CLI invocation, prepare the exact source-pinned
v1.0.12/e77daa9021d20db26b878f7dfa5640fe5a42d04e tool in a fresh bound workspace and
put it on PATH; the prior tool binding is refused. Do not hash/read the refused P704
cache or retry old missing-dependency failures. Preserve failed evidence, finite
successor limits, offline review and pending acceptance.
