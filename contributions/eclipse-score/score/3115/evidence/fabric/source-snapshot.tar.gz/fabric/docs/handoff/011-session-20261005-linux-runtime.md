# Increment 011 compatible runtime / B2–B3 checkpoint — 2026-10-05

Increment 011 remains incomplete. The owner's context/credit-efficiency preference
is now in AGENTS.md: bounded output, relevant sections, exact-hash carried checks,
and a fresh session when accumulated history becomes less useful than a concise
handoff. Context percentage and actual billed credits are unavailable. An explicit
conservative checkpoint warning stopped new stages; every owned operation is closed.

[Complete bound report](../../specs/011-change-impact-and-freshness/evidence/t033-linux-runtime/review-report.md),
[JSON snapshot](011-session-20261005-linux-runtime.json) and [continuation](011-session-20261005-linux-runtime-prompt.md).
The packet seals 271 files; manifest SHA-256 `485b2f0cc3dbd6cf7522d79ad47924f892538c57a486b9ceb4d29bead7871bed`.

32 historical packets / 8,753 sealed files, 310 fabric source/test files, 20 reviewed
T032 subjects, 740 original / 738 approved candidate native files and 3,484 runtime
files match. Fresh foundation/Specify/package/diff/trace and 16 operator syntax checks
pass. Prior 223 fabric tests, Ruff/mypy and 113 native cases per arm are carried only
by verified unchanged hashes. Host libraries are unchanged; no provider, Fabro or
Docker daemon is started. Human markers and T032's recorded approval are preserved.

Cached Debian glibc2.36 is incompatible. A checksum-bound Canonical Ubuntu Noble
image (30,033,716 bytes) supplies glibc2.39 and libstdc++14.2.0 in a private bwrap
library namespace. Exact Ferrocene, Python and Bazel preflights pass. Checksums are
verified through retained HTTPS-origin sums; no GPG signature verification is claimed.
No native tools, pins, warning policy or required coverage scope are replaced.

B2's actual original getter/setter each makes 32 C++ allocations in 16 calls after
warmup, with response values preserved. Caller-thread new/new[] counting and a
controlled test queue consumer are explicit limits; production Graph/concurrency and
any correction remain unqualified. B3 baseline passes3 tests, covering92/182 lines,
30/56 branches and8/12 functions in control_provider.cpp. The held-out real-handler
test passes4 tests and increases coverage to98/182 lines,31/56 branches and9/12
functions. A wrong-status mutant fails exactly the new test; all three older tests
pass. Full issue685 coverage and RPC transport are not claimed. Held-out patches
must remain outside future agent inputs.

Raw unsuccessful evidence remains explicit: safe absolute-symlink extraction refusal,
initial unflushed metadata hash records, runner profile-order/GCC failure and final
scanner/capture errors. Corrected stages retain their own sources and raw outcomes.
The native inventory measures4 source annotations,2 component/build associations and
44 work-product documents; complete accepted denominators remain missing. Old native
export placeholder/unknown remote links and native statuses are preserved.

Original `//:needs_json` now stops at the exact Aspect rules_py v1.4.0 unpack binary:
`https://github.com/aspect-build/rules_py/releases/download/v1.4.0/unpack-x86_64-unknown-linux-musl`
Native SHA-256 `cc946841057e196ddc08da5f78991cd16f182400669ee88edcadffdc92fd1617`.
The known P704 repository cache contains a file at that SHA path; presence alone is
measured, integrity/storage compatibility still requires fresh verification before
reuse. [Readiness](../../specs/011-change-impact-and-freshness/evidence/t033-linux-runtime/next-prerequisite/readiness.json)
and proposed finite successor limits are unstarted. Do not retry without preparation.

Native workspace remains `/media/jefferson/11c42dee-73a3-4c2b-ab42-a0440011d9e0/.s-core-build/runs/score-011-autonomous-wrr1v6c2`; compatible runtime/oracle scratch is `/media/jefferson/11c42dee-73a3-4c2b-ab42-a0440011d9e0/.s-core-build/runs/score-011-runtime-p0y6xo39`.
Both are bound to image UUID11c42dee-73a3-4c2b-ab42-a0440011d9e0, device1819,
backed by SSD UUID002B-CE31; registration stays1TiB. Use shared storage and stop on
loss. Preserve historical bindings; no global storage/library/cache change occurs.
Credentials/private state stay internal. QNX remains skipped without a license.

T154/T156 remain open. B1 selection, accepted B4 requirements/interfaces and B5
coupling/applicability/reviewer roles, full native expected-set decisions, fresh paid
provider/model/request/spending limits, real paired B1–B5 usage/savings and offline
T033 acceptance remain missing. No012, publication/push/merge/release/deployment,
scheduler or synthetic decision is authorized. Complete all independent technical
work before presenting a consolidated missing-input request.

The Goal is incomplete; conditional pause is requested after these files are saved.
The final Goal tool response confirms its status. The full autonomous authority,
below20% rule and credit-efficiency preference continue in the copied prompt. No new
go is needed for the next reversible stage.
