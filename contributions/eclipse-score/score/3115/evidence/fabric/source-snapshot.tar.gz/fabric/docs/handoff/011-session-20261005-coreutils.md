# Increment 011 Coreutils handoff — 2026-10-05

US39 / AC94–96 / T136–138 is complete and sealed. The mission remains incomplete.
Next concrete action: prepare the exact original-lock-bound Linux GCC 12.2.0 package
from release v0.0.4 with actual notices/expanded size and explicit new input-count/byte/
storage limits, then pursue configured Linux analysis in a fresh bounded stage.
No background continuation starts; this handoff is not a live provider instruction.

Read [AGENTS.md](../../AGENTS.md), [constitution](../../.specify/memory/constitution.md),
[original handoff](000-to-001.md), [Ferrocene handoff](011-session-20261005.md),
active [spec](../../specs/011-change-impact-and-freshness/spec.md),
[plan](../../specs/011-change-impact-and-freshness/plan.md),
[tasks](../../specs/011-change-impact-and-freshness/tasks.md),
[acceptance](../../specs/011-change-impact-and-freshness/acceptance.md), and
[complete sealed report](../../specs/011-change-impact-and-freshness/evidence/t033-coreutils-linux/review-report.md).
Preserve the dirty workspace, original brief, every old handoff, sealed packets and
reviewed subjects. T032/T033 human task markers stay unchecked.

## Latest measured result

Packet: `specs/011-change-impact-and-freshness/evidence/t033-coreutils-linux`.
Manifest SHA-256:
`9aa333cac947e861d4a8041daf27861f28c5e1f0e86103da34ba101f8001558d`.
It binds 97 files. Large exact inputs remain on their bound SSD workspace with
path/hash/size refs; actual Coreutils inventory/license, source/HTTP receipts, operators
and complete native outputs are retained in the packet.

The exact Linux Coreutils 0.1.0 archive was acquired in 4,819,217 bytes against native
SHA-256 `463648347b1fc337414a864bda960c9cbd1bd4a540f344c010ff5bb35199e6d7`.
The release API provides no asset digest; that field stays null. Native checksum binding
comes from original registry/module/wrapper bytes. The archive contains four entries,
13,102,983 expanded bytes and one retained actual license. Source license is separately
Git-blob/SHA-256-bound to tag commit `18b963ed6f612ac30ebca92426280cf4c1451f6a`.
No licensing/tool qualification or independent binary-build reproduction is accepted.
All 32 prepared inputs total 394,036,927 bytes. Existing Ferrocene/Buf/source inputs
are inherited by exact hashes without remote reacquisition.

One real isolated configured five-label cquery exited 1 in 12.252 seconds. All 68
metadata and 28 asset responses completed with no metadata misses, serving 400,435,242
bytes. It failed at GCC before completing Coreutils and made no Coreutils mirror request.
Do not treat changed failure ordering as Coreutils extraction. A separate unconfigured
query of `@@aspect_bazel_lib++toolchains+coreutils_linux_amd64//:coreutils_toolchain`
then passed in 2.221 seconds, consumed the verified content-addressed archive with zero
mirror requests, and completed the repository marker. Extracted executable hash/mode
match the archive. This separate query added no input and was not a configured retry.
No further configured attempt followed the out-of-scope GCC failure.

Native source/locks remain unchanged. No Coreutils execution, native compilation/test,
SDK, QNX variant, credentials or provider request is observed/requested. External
networking is denied and the loopback mirror serves only exact listed bytes. The
score_tooling version warning remains retained and enabled. Human engineering
acceptance stays pending offline; native query success does not establish readiness.

Frozen sync, Specify 1.0.12 version/prerequisites, foundation, package build, final control
whitespace and trace checks pass. Prior 223 tests/Ruff/mypy over 152 source files are
carried by 310 unchanged source/test subjects; no new source tests/static analysis were
run. All 740 native originals, 3,484 runtime files, 405 historical cache markers, twenty
T032 subjects and 24 old packets (5,825 subjects) remain unchanged. Including this packet,
the chain contains 25 packets and 5,922 subjects. Owned probes/mirrors close, with no
private/provider server or background continuation. Recorded tasks are 136/138 with
human markers preserved; this is not a whole-mission completion percentage.

## Next exact GCC prerequisite

[GCC readiness](../../specs/011-change-impact-and-freshness/evidence/t033-coreutils-linux/gcc-readiness.json)
binds exact original native lock, registry, module archive, wrapper/BUILD and license:

- URL: `https://github.com/eclipse-score/toolchains_gcc_packages/releases/download/v0.0.4/x86_64-unknown-linux-gnu_gcc12.tar.gz`
- SHA-256: `e9b9a7a63a5f8271b76d6e2057906b95c7a244e4931a8e10edeaa241e9f7c11e`
- Strip prefix: `x86_64-unknown-linux-gnu`
- Original lock extension: `@@score_bazel_cpp_toolchains+//extensions:gcc.bzl%gcc`
- Generated package repository: `score_gcc_x86_64_toolchain_pkg`
- Native toolchain identifier: `gcc_12.2.0`; native version: `12.2.0`; native OS: `linux`.
- Release-reported bytes: 157,834,687; release digest matches the original lock.

The exact archive is absent from the inspected historical content-addressed cache;
this is not a machine-wide absence claim. No GCC payload was acquired/imported or
executed. Actual notices, expanded size, compatibility and tool qualification remain
unmeasured/unaccepted. The native toolchain's inherited QNX license-path attribute
is source metadata only; no SDK/credentials/license file was read and no QNX request
is implied. Keep QNX skipped because the owner has no license; do not ask again.

Adding this one payload would create 33 inputs / 551,871,614 reported bytes. That
exceeds US39's 32-input, 512 MiB aggregate and 64 MiB new-payload bounds. Do not silently
widen this sealed stage or use its unused attempts. A successor must explicitly
measure/preserve public source, actual payload SHA-256, inventory/notices and expanded
size, select fresh storage, and declare finite input-count/byte/extraction/acquisition/
analysis limits before execution. Do not substitute host GCC, alter native source/locks,
select another platform or infer accepted licensing from wrapper notices. The original
lock bound used here remains authoritative even if public upstream releases changed.

## Workspace/tool recovery

Use `score-fabric storage` / `score_sw_fabric.storage` for every fresh workspace/cache.
The registered mounted 1 TiB ext4 image is at
`/media/jefferson/11c42dee-73a3-4c2b-ab42-a0440011d9e0`; external SSD UUID `002B-CE31`.
The underlying SSD is exfat. The owner authorized mounting and confirmed 1 TiB in the
preceding stage; capacity registration is reconciled, with no reformat/resize/repair.
Current workspace:
`/media/jefferson/11c42dee-73a3-4c2b-ab42-a0440011d9e0/.s-core-build/runs/score-fabric-jeiv1tqk`.
Its current device binding is 1819. Older 1818-bound workspaces stay unchanged; their
historical input files are independently re-bound read-only on the same UUID-verified
volume. No queue/server/global tool storage migration occurs. Stop on disconnection.

US39 allowed 32 inputs, 256 MiB/inherited input, 64 MiB/new payload, 512 MiB aggregate,
one 120-second payload request, sixteen 2 MiB metadata responses, 512 MiB expanded new
archive bytes, 10,000 members, 16 MiB/notice, 32 MiB/archive notice bytes, 20 GiB free
reserve, and three 120-second native attempts. Two distinct probes were used. No
unchanged configured retries after GCC or acquisition retries occur. These controls
and archived operators describe the sealed stage; adapt copies with new exact bindings.
The loopback mirrors run inside bwrap, deny external networking and hide real home;
only fresh bound scratch is writable. Credentials/private state stay internal.

Use Python >=3.12; `.venv` and the retained read-only mirror runtime use 3.12.14, and
host Python 3.10 must not run fabric helpers. Verify all 3,484 runtime hashes/storage
bindings before reuse; set PYTHONDONTWRITEBYTECODE=1. Bazel stays 8.7.0, SHA-256
`d7606e679b78067c811096fb3d6cf135225b528835ca396e3a4dddf957859544`.
Original source baseline: `7d1d7bec81d96752b5a9a235044d2dfc3ecd259b`; source archive:
`19dbc09f9424ff9d52a9f7ec8b64715c79cba32b4c063e0d41c158d657c5368c`.
Pinned Specify 1.0.12 lives on the recorded SSD tool workspace; set
`SPECIFY_FEATURE_DIRECTORY=/home/jefferson/s-core_sw_fabric/specs/011-change-impact-and-freshness`
explicitly. No Spec Kit extension hooks are registered. Preserve unchanged source-bound
prior tests and use appropriate current frozen/foundation/package/trace checks.

Human review stays offline outside Fabro workflows, with no human/wait-for-approval
nodes or synthetic decisions. Preserve the exact historical T032/lifecycle #704 owner
subjects and decisions. Full native expected-check denominator, transitive impact/work
products, review roles, tool qualification and live B1–B5/T033 acceptance remain pending.
QNX omission accepts neither applicability nor platform qualification. PR publication
stays deferred and the approved local contribution destination remains unchanged.
This stage made zero paid requests; historical DeepSeek exceptions are not general
spending or successor live-stage authority. Fabro owns execution/run state; Spec Kit
owns fabric development; native S-CORE artifacts own engineering semantics.

[Machine-readable snapshot](011-session-20261005-coreutils.json) binds current controls,
source/reviewed subjects, packet chain, workspace and measured GCC prerequisite.
Recommended model: **gpt-6.1-sol (high)** for bounded GCC package/provenance inspection
and native dependency diagnosis; this recommendation does not switch the session.
