# Rust workflow / communication #1265 — paused handoff

Paused by the user's request to turn off the PC, recorded 2026-10-06 05:25 UTC.
No automatic continuation. Resume only when the user resumes this task.

## Objective and authority

The generic S-CORE Rust workflow is implemented and installed:
`.agents/skills/score-rust-workflow/SKILL.md`, exposed through
`/home/jefferson/.codex/skills/score-rust-workflow`. Use `$score-rust-workflow`.
Its sealed Spec Kit artifacts remain in
`specs/011-change-impact-and-freshness/rust-workflow/`.

Finish supervised native verification of the assessment for
https://github.com/eclipse-score/communication/issues/1265 and retain the local
contribution. The user said “go” after the previous exhausted run, authorizing a
fresh recovery with a maximum of three corrective fixes. **Recovery: 1/3 used,
two remaining.** The original run's separate 3/3 record remains historical.
Resuming this pause does not reset the recovery budget.

Supervisor: `/root/rust_issue_supervisor`, read-only; completed its latest review.
Reactivate it for configuration/provenance and terminal-results review. No paid
provider calls, publishing, merge, deployment or engineering acceptance are authorized.
Human review remains offline. Preserve dirty user work, original briefs and all
historical packets. No foundation/runtime source implementation was changed.

## Verified state

- Communication baseline and observed HEAD:
  `e3d126c2d7569345cf5f790310702eb00cd86b06`; issue observed open.
- Patch SHA-256:
  `eb687c1a36b054315970fdbb2a4833cbb5e9470fb30eb06e67a446ca87951c19`.
  Only the Rust README and a new identifier-pasting assessment change; all 2,879
  candidate hashes match. Production Rust, locks and policies are unchanged.
- Original contribution:
  `/home/jefferson/eclipse_sdv_hackathon_2026/contributions/issues/eclipse-score/communication/1265`.
  All 175 sealed subjects remain unchanged; manifest SHA-256
  `d455bbafc5b5a79df6f1786b0a7aa9a7b76558521ebc308a4c21a414c9600d92`.
- Recovery workspace:
  `/media/jefferson/11c42dee-73a3-4c2b-ab42-a0440011d9e0/.s-core-build/runs/score-fabric-pste_44o`.
- Paused recovery packet: the original contribution's
  `verification-recovery/score-fabric-pste_44o/`; 253 bound files, manifest SHA-256
  `2f60752a659f364ec7e0cafbeaa39dc99c16677a3aaac8b6155ddf9f4282df4a`.
  Includes original packet, native logs/configuration, partial preparation scripts,
  `pause-state.json`, `archive-identity.json` and `correction-ledger.json`.
- Fresh Fabro run `01M47SYF7DSPAQDMTYWVD31Q40`, version
  `62d474b32fb6f50a19b7c62dbceeb4f0402b62af7dc0e0e8adfe29542a8bc012`.
  Worker preflight succeeded: PATH includes sbin and storage validation resolves
  `losetup`. Native analysis failed after 448.085 seconds on GitLab HTTP 502 for
  locked `download_utils` 1.2.2, through the `acl-deb` dependency. **No tests ran.**
  `verify` and `export` have failed status; export wrote the failure evidence and
  deliberately returned failure. Native lifecycle correctly reports failed.
- Owned server stopped, PID 996675 absent; owned Bazel/Fabro/native process scan
  found none. Supervisor has no running turn. No owned job needs shutdown.
  Private credentials/state remain internal; never copy them into a build root.

## Exact blocker and partial preparation

The first cache seed copied SHA-256 payloads only. The missing module uses SHA-512.
The exact archive was found in the legacy immutable public cache and independently
verified against source metadata whose SHA-256 matches the selected native root lock:

- Registry source URL: `https://bcr.bazel.build/modules/download_utils/1.2.2/source.json`.
- Source metadata SHA-256:
  `c88be2bc48c98371d35665b805f307a647c98c83327345c918d9088822d77928`.
- Archive URL: `https://gitlab.arm.com/bazel/download_utils/-/releases/v1.2.2/downloads/src.tar.gz`.
- Archive SHA-512:
  `cfbe365053e74105a5b6abc75ad866a740128f0bcfe9bd1c9022791466c28d554dee5231051f7dfc0814d2e98e765e16c20291f17ea841bd5775abe3d9a217d6`.
- Archive actual SHA-256:
  `178175d89dcfa355a18d884304d342fb178c98e6f4b7f7fbe00c7d65ddf7b411`.

Correction 1 fixed the acquisition helper's unjustified SHA-256-only assumption;
its refusal is preserved. `download-utils-acquisition.json` still has misleading
SHA-256 field labels for SHA-512 values. The original is retained and
`archive-identity.json` provides a verified corrected supplement.

`prepare_correction2.py` failed before creating a new binding/run: its canonical-ID
marker guard assumes 64 hex digits; the observed SHA-512 cache marker has 128 digits
and zero bytes. The `correction2/` directory exists and is empty. A verified payload
copy may already exist in the owned SHA-512 cache. Do not blindly rerun the script:
its unconditional `trial.mkdir()` also needs to handle this verified empty directory.
No correction 2 has been recorded or launched. Preserve this preparation refusal.

Inspect **pinned Bazel 8.7.0 `DownloadCache.java`** before correcting the marker
guard. `Bazel-8.7.0-RepositoryCache.java` was fetched and retained; that class
delegates download-cache behavior. Do not invent a canonical-ID algorithm or bypass
checksums. Completing this cache remedy is planned correction 2, leaving one further
fix. Copy only independently hash-verified immutable public payloads/metadata; never
migrate queues/private state or alter global caches. Native source/locks remain pinned.

## Storage after shutdown and resume sequence

Workspace storage record binds backing UUID `002B-CE31`, registered ext4 image UUID
`11c42dee-73a3-4c2b-ab42-a0440011d9e0`, and mount device 1819. Use
`score_sw_fabric.storage` / `score-fabric storage`. Prefer the measured external
Linux volume and validate before every stage. **Reboot/remount may change the device.**
If the old guard fails, do not rewrite its record or resume an old queue. Allocate
a new measured root and import only hash-verified immutable source/cache inputs,
with explicit carried-evidence labels. Retain the failed root and private state as
history; never silently relocate active work or reformat a disk.

1. Read AGENTS.md, constitution, active 011 artifacts, this handoff and
   `pause-state.json`; verify both manifests and the candidate/tool bindings.
2. Validate storage, then resolve the source-verified SHA-512 marker/cache preparation
   and acquisition-label gap. Record correction 2 only when concretely applied.
3. Preserve first recovery run's bound files. Use separately named correction programs,
   output namespace, immutable workflow version and new private Fabro run; no automatic
   retry or human/approval nodes. Supervisor audits the exact new binding.
4. Run the selected native concept/macro unit/manual doctest checks, retain per-target
   results and full logs, and copyright if reached. Stop on exhausted budget or repeated
   unchanged failure; do not change dependency/toolchain/policy to manufacture success.
5. Complete the portable recovery record and supervisor review, then update the
   contribution registry/latest record only to the actual measured status and run the
   contribution verifier. **Registry promotion is currently pending**; it still selects
   the original 175-file failed attempt. Do not check off human acceptance.

Qualification/adoption/compiler AoU, unavailable QNX and full CI remain explicit
obligations. Tests or runtime termination cannot grant engineering acceptance.

Copy-ready resume request:
“Resume docs/handoff/011-session-20261006-rust-paused.md. Continue the same supervised
Rust verification recovery with 1/3 fixes used and two remaining. Validate storage
after reboot, preserve old packets, complete source-verified correction 2, and export
the measured contribution. No paid calls or publishing.”

Next step: resume the same budget and inspect pinned DownloadCache canonical-ID behavior.
Recommended model: gpt-6.1-sol (high) — diagnose native cache provenance and verify evidence.
