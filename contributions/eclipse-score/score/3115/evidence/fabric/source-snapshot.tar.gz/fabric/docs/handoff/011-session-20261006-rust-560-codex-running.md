# #560 Codex correction allowance — running

User authority: “ok, keep it in 3 corrections done by codex, if it exceed, then stop”.
This authorizes at most three new Codex source correction attempts. Previous three
remain historical, giving an explicit maximum of six lifetime attempts for #560.
Do not reset the new allowance or change any other issue budget. Codex attempt 1
was reserved before source changes; two further attempts remain if checks fail.

Bound run root:
`/media/jefferson/11c42dee-73a3-4c2b-ab42-a0440011d9e0/.s-core-build/runs/score-rust-560-codex-eppa905r`.
Fresh disposable clone verified against all 2190 incoming native source subjects.
SSD/Linux-image binding was validated using shared storage. Native builds use a
new bound archive cache and fresh output tree; prior workspace/packets/global caches
remain unchanged. Credentials and private server state remain internal.

Attempt 1 edits only the new subscription_state_apis package's Rust binary and BUILD:
builder annotations, successful provider exit requirement, owned-child cleanup on
wait failure, and three native subprocess tests. These helper tests are separate
from the five real-LoLa production integration cases.

Fabro owns deterministic verification/export through a command-only graph:
`01M49A1PAGCVD0BTQPQ6RDPF3F`, private localhost instance on port 36739.
Graph contains zero model agent stages. No DeepSeek source correction/model request
is made by this graph; Codex is the source editor. An independent existing Codex
supervisor reviews statically outside the graph, writing only its report. No human
approval/wait node, acceptance, publishing or issue closure is implied.

Expected native groups: Linux binary build; three subprocess helper tests; five
production cases plus sync/async regressions; native Clippy; explicit labels query.
Source vectors and complete native logs/results are bound for each attempt. Failure
routes to export, so lifecycle success must not be confused with passing verification.
Stop after a failed third Codex correction, on bound storage disconnection, or unknown
native state; never resend a create/start or signal an unverified/stale PID.

Earlier budgets, exclusions, qualification and acceptance obligations remain as in
[the final integration handoff](011-session-20261006-rust-560-integration-results.md).
The preceding [Codex review](011-session-20261006-rust-560-codex-review.md) and immutable
primary contribution remain intact. Current status is running, not verified passing.
