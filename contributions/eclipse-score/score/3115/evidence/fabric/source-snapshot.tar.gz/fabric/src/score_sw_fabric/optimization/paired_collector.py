"""Fresh candidate-bound commands and raw outputs, without provider transport."""

from __future__ import annotations

import hashlib
import os
import re
import shutil
import signal
import subprocess
import tarfile
import time
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

from score_sw_fabric.optimization.activation import private_file
from score_sw_fabric.optimization.common import (
    OptimizationError,
    canonical,
    checked,
    json_object,
    record,
    safe_file,
)
from score_sw_fabric.optimization.paired_runtime import (
    PairedWorker,
    file_hash,
    file_set_digest,
    write_private,
)
from score_sw_fabric.storage import build_environment


def _execute(
    worker: PairedWorker,
    cwd: Path,
    argv: list[str],
    log: Path,
    timeout: int,
) -> dict[str, Any]:
    environment = build_environment(worker.root)
    # Deliberately omit provider/server credentials and the caller's private HOME.
    home = worker.root / "collector-home"
    home.mkdir(exist_ok=True)
    environment.update(HOME=str(home), PATH=os.defpath, LANG="C.UTF-8")
    start = time.monotonic()
    reason = None
    with log.open("xb") as stream:
        process = subprocess.Popen(
            argv,
            cwd=cwd,
            env=environment,
            stdout=stream,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )
        try:
            while process.poll() is None:
                worker.validate()
                if time.monotonic() - start > timeout:
                    reason = "COLLECTOR_TIMEOUT"
                    break
                time.sleep(0.25)
        except BaseException:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            raise
        if reason:
            os.killpg(process.pid, signal.SIGKILL)
        process.wait()
    worker.validate()
    return {
        "argv": argv,
        "exit_code": process.returncode,
        "reason": reason,
        "seconds": time.monotonic() - start,
        "log_sha256": file_hash(log),
    }


def xml_cases(raw: bytes) -> dict[str, int]:
    """Count actual cases, not duplicated aggregate counters; unsafe XML is refused."""
    if len(raw) > 8 * 1024 * 1024 or b"<!DOCTYPE" in raw or b"<!ENTITY" in raw:
        raise OptimizationError("UNSAFE_TEST_XML")
    try:
        root = ET.fromstring(raw)
    except ET.ParseError as exc:
        raise OptimizationError("MALFORMED_TEST_XML") from exc
    counts = {"passed": 0, "failed": 0, "errors": 0, "skipped": 0, "total": 0}
    for case in root.iter("testcase"):
        counts["total"] += 1
        category = (
            "errors"
            if case.find("error") is not None
            else "failed"
            if case.find("failure") is not None
            else "skipped"
            if case.find("skipped") is not None
            else "passed"
        )
        counts[category] += 1
    return counts


def _artifact(root: Path, source: Path, relative: str) -> Path:
    # Bazel creates output/runfile symlinks. Resolve only into the bound disposable
    # volume, not arbitrary host inputs; traversal in the plan is still forbidden.
    if (
        not relative
        or relative.startswith("/")
        or "\\" in relative
        or any(part in {"", ".", ".."} for part in relative.split("/"))
    ):
        raise OptimizationError("COLLECTOR_OUTPUT_PATH")
    path = (source / relative).resolve(strict=True)
    if not path.is_relative_to(root):
        raise OptimizationError("COLLECTOR_OUTPUT_ESCAPE")
    if not path.is_file() or path.stat().st_size > 128 * 1024 * 1024:
        raise OptimizationError("COLLECTOR_OUTPUT_SIZE")
    return path


def _source_inventory(source: Path, workspace: Path) -> dict[str, str]:
    """Exclude only Bazel's four top-level links, checking where they resolve."""
    result = {}
    pending = [source]
    outputs = {"bazel-bin", "bazel-out", "bazel-testlogs", "bazel-" + source.name}
    while pending:
        directory = pending.pop()
        for path in directory.iterdir():
            if path.is_symlink():
                if (
                    directory != source
                    or path.name not in outputs
                    or not path.resolve(strict=True).is_relative_to(workspace)
                ):
                    raise OptimizationError("COLLECTOR_SOURCE_DRIFT")
            elif path.is_dir():
                pending.append(path)
            elif path.is_file():
                result[path.relative_to(source).as_posix()] = file_hash(path)
            else:
                raise OptimizationError("COLLECTOR_SOURCE_DRIFT")
    return result


def collect(
    worker: PairedWorker,
    context: dict[str, Any],
    cwd: Path,
    plan_path: Path,
    plan_pin: str,
) -> dict[str, Any]:
    """Measure once per applied stage; never accept raw XML supplied by the agent."""
    worker.identity(context, cwd)
    raw = private_file(plan_path)
    if plan_path.parent != worker.path.parent or hashlib.sha256(raw).hexdigest() != plan_pin:
        raise OptimizationError("COLLECTOR_PLAN_DRIFT")
    plan = checked(json_object(raw), "paired_collector_plan")
    if plan["binding"] != worker.pin:
        raise OptimizationError("COLLECTOR_BINDING")
    implementation_path = Path(__file__)
    implementation_pin = file_hash(implementation_path)
    with worker.state() as state:
        worker.verify_source(state)
        if not state["applied"] or len(state["checks"]) >= len(state["applied"]):
            raise OptimizationError("COLLECTOR_REPLAY_OR_ORDER")
        command_ids = [item["id"] for item in plan["commands"]]
        output_ids = [item["id"] for item in plan["outputs"]]
        if (
            not command_ids
            or len(command_ids) > 10
            or len(output_ids) > 30
            or len(set(command_ids)) != len(command_ids)
            or len(set(output_ids)) != len(output_ids)
            or any(not re.fullmatch(r"[a-z0-9_-]+", name) for name in command_ids + output_ids)
        ):
            raise OptimizationError("COLLECTOR_PLAN_SCOPE")
        for command in plan["commands"]:
            argv = command["argv"]
            if (
                not isinstance(argv, list)
                or not argv
                or len(argv) > 50
                or any(not isinstance(arg, str) or not arg or "\x00" in arg for arg in argv)
                or type(command["timeout_seconds"]) is not int
                or not 1 <= command["timeout_seconds"] <= 1800
                or file_hash(Path(argv[0])) != command["tool_sha256"]
            ):
                raise OptimizationError("COLLECTOR_COMMAND_BINDING")
        for relative, pin in plan.get("input_files", {}).items():
            if file_hash(safe_file(worker.root, relative)) != pin:
                raise OptimizationError("COLLECTOR_INPUT_DRIFT")
        directory = (
            worker.root
            / "collectors"
            / worker.binding["arm"]
            / worker.pin
            / str(len(state["checks"]))
        )
        directory.mkdir(parents=True, exist_ok=False)
        source = directory / "source"
        source.mkdir()
        for name in state["source_files"]:
            target = safe_file(source, name, must_exist=False)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(safe_file(worker.worker, name), target)
        state["stopped"] = True
        write_private(worker.state_path, state)
        commands = []
        failed_commands: set[str] = set()
        for command in plan["commands"]:
            # Worker content and executable pins are rechecked before every command.
            worker.verify_source(state)
            for relative, pin in plan.get("input_files", {}).items():
                if file_hash(safe_file(worker.root, relative)) != pin:
                    raise OptimizationError("COLLECTOR_INPUT_DRIFT")
            if file_hash(Path(command["argv"][0])) != command["tool_sha256"]:
                raise OptimizationError("COLLECTOR_COMMAND_BINDING")
            measured = _execute(
                worker,
                source,
                [arg.replace("{source}", str(source)) for arg in command["argv"]],
                directory / (command["id"] + ".log"),
                command["timeout_seconds"],
            )
            measured["id"] = command["id"]
            if measured["exit_code"] != 0:
                failed_commands.add(command["id"])
            commands.append(measured)
        outputs = []
        with tarfile.open(worker.binding["archive"]) as archive:
            if file_hash(Path(worker.binding["archive"])) != worker.binding["archive_sha256"]:
                raise OptimizationError("SOURCE_ARCHIVE_DRIFT")
            for item in plan["outputs"]:
                selected: dict[str, Any] = {"id": item["id"], "kind": item["kind"]}
                if item["command"] not in command_ids:
                    raise OptimizationError("COLLECTOR_OUTPUT_COMMAND")
                selected["command_failed"] = item["command"] in failed_commands
                try:
                    artifact = _artifact(worker.root, source, item["path"])
                    data = artifact.read_bytes()
                    copied = directory / (item["id"] + ".raw")
                    copied.write_bytes(data)
                    selected.update(
                        path=str(copied.relative_to(worker.root)),
                        sha256=hashlib.sha256(data).hexdigest(),
                        bytes=len(data),
                    )
                    if item["kind"] == "test_xml":
                        counts = xml_cases(data)
                        selected.update(counts)
                        selected["status"] = (
                            "missing"
                            if not counts["total"]
                            else "fail"
                            if counts["failed"] or counts["errors"]
                            else "skipped"
                            if counts["skipped"]
                            else "pass"
                        )
                    elif item["kind"] in {"configuration", "runfile", "package"}:
                        expected = archive.extractfile(item["original_path"])
                        if expected is None:
                            raise OptimizationError("ORIGINAL_PROFILE_MISSING")
                        with expected:
                            original = json_object(expected.read())
                        if item["kind"] == "package":
                            with tarfile.open(artifact) as package:
                                members = [m for m in package if m.name == item["member"]]
                                if len(members) != 1 or not members[0].isfile():
                                    raise OptimizationError("PACKAGE_MEMBER")
                                if members[0].size > 8 * 1024 * 1024:
                                    raise OptimizationError("PACKAGE_SIZE")
                                stream = package.extractfile(members[0])
                                if stream is None:
                                    raise OptimizationError("PACKAGE_MEMBER")
                                with stream:
                                    data = stream.read()
                        selected["status"] = (
                            "pass"
                            if canonical(json_object(data)) == canonical(original)
                            else "fail"
                        )
                    else:
                        raise OptimizationError("COLLECTOR_OUTPUT_KIND")
                except FileNotFoundError:
                    selected["status"] = "missing"
                except (OptimizationError, tarfile.TarError, KeyError) as exc:
                    selected.update(status="fail", reason=getattr(exc, "code", "OUTPUT_MALFORMED"))
                outputs.append(selected)
        worker.verify_source(state)
        for relative, pin in plan.get("input_files", {}).items():
            if file_hash(safe_file(worker.root, relative)) != pin:
                raise OptimizationError("COLLECTOR_INPUT_DRIFT")
        # Selected output artifacts are kept separate from the source inventory.
        expected_files = state["source_files"]
        actual_files = _source_inventory(source, worker.root)
        # The operator may select collector output files under the source cwd.
        # Native Bazel outputs use the validated links and aren't source entries.
        direct_outputs = {
            item["path"]
            for item in plan["outputs"]
            if item["path"] not in expected_files
            and not item["path"].split("/")[0].startswith("bazel-")
        }
        for name in direct_outputs:
            actual_files.pop(name, None)
        if actual_files != expected_files:
            raise OptimizationError("COLLECTOR_SOURCE_DRIFT")
        if file_hash(implementation_path) != implementation_pin:
            raise OptimizationError("COLLECTOR_IMPLEMENTATION_DRIFT")
        result = record(
            "paired_fresh_checks",
            binding=worker.pin,
            candidate=state["candidate"]["digest"],
            source_digest=file_set_digest(state["source_files"]),
            plan_sha256=plan_pin,
            collector_implementation_sha256=implementation_pin,
            status="pass"
            if not failed_commands and outputs and all(item["status"] == "pass" for item in outputs)
            else "fail",
            commands=commands,
            outputs=outputs,
            origin="protected_local_measurement",
            engineering_acceptance="pending",
            native_expected_set="unresolved",
            provider_calls=0,
        )
        (directory / "result.json").write_bytes(canonical(result))
        state["checks"].append(
            {
                "status": result["status"],
                "digest": result["digest"],
                "result_path": str((directory / "result.json").relative_to(worker.root)),
                "result_sha256": file_hash(directory / "result.json"),
            }
        )
        state["stopped"] = False
        write_private(worker.state_path, state)
        return result
