/********************************************************************************
 * Copyright (c) 2025 Contributors to the Eclipse Foundation
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Apache License Version 2.0 which is available at
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * SPDX-License-Identifier: Apache-2.0
 ********************************************************************************/
#include <fstream>
#include <iostream>

int main()
{
    std::cout << "Hello!\n";
    // We create a file to signal to `main2.cpp` that it can continue.
    std::ofstream{"/tmp/Hello.txt"};
    return 0;
}
